# AI Company - 清晰架构设计

## 问题分析

当前架构混乱、嵌套严重：
- UnifiedDecision 和 Orchestrator 职责重叠
- 多处重复的资源查询逻辑
- 多次 AI 调用（决策、执行、审查）
- 流程不清晰，难以理解

---

## 新架构设计

### 核心原则

1. **单一职责**：每个模块只做一件事
2. **线性流程**：避免嵌套，保持扁平
3. **明确接口**：输入输出清晰
4. **可测试性**：每个步骤可独立测试

### 清晰的三阶段流程

```
输入 → Analyze → Execute → Verify → 输出
```

---

## 模块设计

### 1. Analyzer（分析器）

**职责**：分析需求，决定执行方案

```typescript
interface Analyzer {
  analyze(input: UserInput): AnalysisResult;
}

interface AnalysisResult {
  understood: string;        // AI 理解的需求
  resources: FoundResources;  // 找到的所有资源
  decision: ExecutionPlan;    // 执行计划
}

interface ExecutionPlan {
  action: 'run_cron' | 'run_script' | 'create_task' | 'answer';
  target: string;
  reason: string;
  confidence: number;
}
```

**流程**：
1. 接收用户输入
2. 查询所有资源（一次查询，所有资源）
3. 调用 AI 决定执行方案
4. 返回决策结果

---

### 2. Executor（执行器）

**职责**：执行决策，产出结果

```typescript
interface Executor {
  execute(plan: ExecutionPlan): ExecutionResult;
}

interface ExecutionResult {
  success: boolean;
  output: string;
  artifacts?: string[];  // 产出的文件
}
```

**流程**：
1. 接收执行计划
2. 根据 action 执行对应操作
3. 返回执行结果

---

### 3. Verifier（验收器）

**职责**：验证结果质量

```typescript
interface Verifier {
  verify(input: UserInput, result: ExecutionResult): VerificationResult;
}

interface VerificationResult {
  passed: boolean;
  score: number;
  feedback: string;
}
```

**流程**：
1. 接收原始需求和执行结果
2. 检查结果是否满足需求
3. 返回验收结论

---

## 完整流程

```typescript
// 主流程
async function processUserInput(input: string): Promise<FinalResult> {
  // 阶段 1: 分析
  const analysis = await analyzer.analyze(input);

  // 阶段 2: 执行
  const execution = await executor.execute(analysis.decision);

  // 阶段 3: 验收
  const verification = await verifier.verify(input, execution);

  return {
    analysis,
    execution,
    verification,
  };
}
```

---

## 文件结构

```
src/core/
├── workflow/
│   ├── Analyzer.ts      # 分析器
│   ├── Executor.ts      # 执行器
│   ├── Verifier.ts      # 验收器
│   └── Pipeline.ts      # 主流程编排
├── decision/
│   └── UnifiedDecision.ts  # 删除（合并到 Analyzer）
├── agents/
│   ├── Orchestrator.ts  # 删除（逻辑分散）
│   └── ReviewerAgent.ts # 重命名为 Verifier
└── resources/
    └── ResourceQuerier.ts  # 资源查询（独立模块）
```

---

## 优势对比

| 方面 | 当前架构 | 新架构 |
|------|----------|--------|
| 流程清晰度 | 嵌套、混乱 | 线性、清晰 |
| 职责划分 | 模糊 | 明确 |
| AI 调用次数 | 3次（决策、执行、审查） | 2次（分析、验收） |
| 资源查询 | 重复 | 一次 |
| 可测试性 | 困难 | 容易 |
| 可维护性 | 低 | 高 |

---

## 迁移计划

1. 创建新的 `workflow/` 目录
2. 实现 Analyzer（整合 UnifiedDecision 的逻辑）
3. 简化 Executor（移除嵌套）
4. 重命名 ReviewerAgent 为 Verifier
5. 实现 Pipeline（主流程）
6. 更新所有调用点
7. 删除旧代码
