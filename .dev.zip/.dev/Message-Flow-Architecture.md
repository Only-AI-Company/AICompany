# AI Company - 消息流程架构

> **日期**: 2026-02-25
> **版本**: 1.0
> **状态**: 设计中

## 1. 概述

AI Company 的消息流程采用**多渠道统一处理**的架构，支持 Telegram、CLI、Web、API 等多种输入来源，所有消息最终通过统一的服务层进行处理和存储。

### 1.1 核心原则

- **统一存储**: 所有消息存储在 `chat_messages` 表
- **事件驱动**: 通过 HookSystem 触发生命周期事件
- **解耦设计**: 输入层、处理层、存储层相互独立
- **异步处理**: 支持异步 Hook 和消息队列

---

## 2. 消息流向图

```
┌─────────────────────────────────────────────────────────────────────┐
│                           输入层 (Input Layer)                       │
├─────────────────────────────────────────────────────────────────────┤
│                                                                       │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌─────────┐ │
│  │   Telegram   │  │     CLI      │  │     Web      │  │   API   │ │
│  │      Bot     │  │  (用户命令)   │  │  (Web UI)    │  │ (外部)  │ │
│  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘  └────┬────┘ │
│         │                  │                  │                │      │
│         └──────────────────┼──────────────────┼────────────────┘      │
│                            │                  │                       │
│                     ┌──────▼──────┐                                   │
│                     │ InputService │                                   │
│                     │  (消息网关)   │                                   │
│                     └──────┬──────┘                                   │
└────────────────────────────┼───────────────────────────────────────────┘
                               │
                               ▼
┌─────────────────────────────────────────────────────────────────────┐
│                         处理层 (Process Layer)                       │
├─────────────────────────────────────────────────────────────────────┤
│                                                                       │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐              │
│  │ CommandRouter│  │ MessageRouter│  │  TaskExecutor│              │
│  │  (命令处理)   │  │  (消息路由)   │  │  (任务执行)   │              │
│  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘              │
│         │                  │                  │                       │
│         └──────────────────┼──────────────────┘                      │
│                            │                                         │
│                     ┌──────▼──────┐                                   │
│                     │ MessageService│                                  │
│                     │  (统一消息服务)│                                 │
│                     └──────┬──────┘                                   │
└────────────────────────────┼───────────────────────────────────────────┘
                               │
                               ▼
┌─────────────────────────────────────────────────────────────────────┐
│                         存储层 (Storage Layer)                       │
├─────────────────────────────────────────────────────────────────────┤
│                                                                       │
│  ┌──────────────────────────────────────────────────────────────┐   │
│  │                    chat_messages 表                            │   │
│  │  - id, session_id, content, source, direction                 │   │
│  │  - external_message_id, external_chat_id, external_user_id   │   │
│  │  - username, message_type, metadata_json, created_at          │   │
│  └──────────────────────────────────────────────────────────────┘   │
│                                                                       │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐              │
│  │  tasks 表     │  │ employees 表 │  │ execution_   │              │
│  │              │  │              │  │  states 表   │              │
│  └──────────────┘  └──────────────┘  └──────────────┘              │
└─────────────────────────────────────────────────────────────────────┘
                               │
                               ▼
┌─────────────────────────────────────────────────────────────────────┐
│                       事件层 (Event Layer)                          │
├─────────────────────────────────────────────────────────────────────┤
│                                                                       │
│  ┌─────────────────────────────────────────────────────────────┐    │
│  │                     HookSystem (EventBus)                     │    │
│  │  - task:before_create, task:after_create, ...               │    │
│  │  - claude:before_prompt, claude:after_response, ...          │    │
│  │  - execution:start, execution:step, execution:complete, ...  │    │
│  └─────────────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────────────┘
```

---

## 3. 详细流程说明

### 3.1 Telegram 消息流程

```
用户发送消息
    │
    ▼
Telegram Bot 接收
    │
    ├─► /命令 → CommandRouter → 执行系统命令
    │         │
    │         ├─► /start, /help, /status 等
    │         └─► /run, /recruit, /talk 等
    │
    ├─► 按钮点击 → CallbackQuery 处理
    │         │
    │         └─► 更新交互状态 → 触发后续操作
    │
    └─► 普通消息 → 聊天处理
              │
              ├─► CEO 模式 → 直接与 CEO 对话
              │         │
              │         ├─► MessageService.saveUserMessage()
              │         ├─► AI Provider 处理
              │         └─► MessageService.saveCompanyResponse()
              │
              └─► 员工模式 → 与指定员工对话
                        │
                        ├─► 获取员工信息
                        ├─► 构建对话上下文
                        └─► 返回员工响应
```

### 3.2 CLI 消息流程

```
用户执行命令
    │
    ▼
CLI 解析
    │
    ├─► ai-company run "<需求>"
    │         │
    │         ├─► 创建 Task
    │         ├─► TaskExecutor.execute()
    │         │         │
    │         │         ├─► Hook: task:before_execute
    │         │         ├─► AutonomousLoopExecutor.execute()
    │         │         │         │
    │         │         │         ├─► 分析 → 计划 → 执行 → 检查 → 改进
    │         │         │         │         (循环直到完成)
    │         │         │         │
    │         │         │         └─► Hook: execution:iteration
    │         │         │
    │         │         └─► Hook: task:after_execute
    │         │
    │         └─► 输出结果
    │
    ├─► ai-company status
    │         │
    │         └─► 查询数据库 → 显示状态
    │
    └─► ai-company db:seed humans
              │
              └─► 执行 Seed 脚本 → 插入数据
```

### 3.3 任务执行流程 (AutonomousLoopExecutor)

```
TaskExecutor.execute(taskId)
    │
    ▼
更新任务状态 → planning
    │
    ▼
Hook: task:before_execute
    │
    ▼
AutonomousLoopExecutor.execute(config)
    │
    ├─► 开始循环
    │         │
    │         ├─► iteration 1: 分析任务
    │         │         │
    │         │         ├─► Claude CLI 调用
    │         │         ├─► 解析 AI 决策
    │         │         └─► 记录迭代结果
    │         │
    │         ├─► iteration 2: 制定计划
    │         │         │
    │         │         ├─► Claude CLI 调用
    │         │         ├─► 解析 AI 决策
    │         │         └─► 记录迭代结果
    │         │
    │         ├─► iteration 3-N: 执行 → 检查 → 改进
    │         │         │
    │         │         └─► 循环直到完成或超时
    │         │
    │         └─► 返回执行结果
    │
    ▼
更新任务状态 → completed/failed
    │
    ▼
Hook: task:after_execute
    │
    ▼
返回结果给用户
```

---

## 4. 消息存储结构

### 4.1 chat_messages 表

| 字段 | 类型 | 说明 |
|------|------|------|
| id | number | 主键 |
| session_id | string | 会话 ID（可选） |
| content | string | 消息内容 |
| source | string | 来源: tg/web/cli/api/other |
| direction | string | 方向: user/company |
| external_message_id | string | 外部消息 ID |
| external_chat_id | string | 外部聊天 ID |
| external_user_id | string | 外部用户 ID |
| username | string | 用户名 |
| message_type | string | 消息类型 |
| metadata_json | string | 元数据 JSON |
| created_at | number | 创建时间戳 |

### 4.2 MessageService 方法

```typescript
class MessageService {
  // 保存用户消息
  saveUserMessage(params: {
    content: string;
    source: ChatSource;
    chatId?: string;
    userId?: string;
    username?: string;
    externalMessageId?: string;
    sessionId?: string;
    metadata?: Record<string, unknown>;
  }): void;

  // 保存公司响应
  saveCompanyResponse(params: {
    content: string;
    source: ChatSource;
    chatId?: string;
    sessionId?: string;
    metadata?: Record<string, unknown>;
  }): void;

  // 获取聊天历史
  getChatHistory(params: {
    source?: ChatSource;
    chatId?: string;
    sessionId?: string;
    limit?: number;
  }): any[];

  // 清理旧消息
  cleanup(daysToKeep: number): number;
}
```

---

## 5. Hook 事件系统

### 5.1 任务生命周期事件

| 事件名称 | 数据 | 触发时机 |
|---------|------|---------|
| task:before_create | { taskData } | 创建任务前 |
| task:after_create | { task } | 创建任务后 |
| task:before_execute | { taskId, employeeId? } | 执行任务前 |
| task:after_execute | { taskId, employeeId?, result } | 执行任务后 |
| task:on_progress | { taskId, progress } | 任务进度更新 |
| task:on_complete | { taskId, result } | 任务完成 |
| task:on_failed | { taskId, error } | 任务失败 |
| task:on_cancel | { taskId, reason } | 任务取消 |

### 5.2 Claude 执行事件

| 事件名称 | 数据 | 触发时机 |
|---------|------|---------|
| claude:before_prompt | { prompt, model? } | 发送提示前 |
| claude:after_response | { response, usage? } | 收到响应后 |
| claude:stream_chunk | { chunk, index } | 流式输出块 |
| claude:on_tool_use | { toolName, toolInput } | 工具调用 |
| claude:on_error | { error, phase } | 执行错误 |
| claude:on_start | { prompt, model } | 开始执行 |
| claude:on_complete | { response, duration } | 执行完成 |

### 5.3 执行追踪事件

| 事件名称 | 数据 | 触发时机 |
|---------|------|---------|
| execution:start | { executionId, taskId } | 开始执行 |
| execution:step | { executionId, step } | 执行步骤 |
| execution:progress | { executionId, progress } | 进度更新 |
| execution:complete | { executionId, result } | 执行完成 |
| execution:failed | { executionId, error } | 执行失败 |
| execution:timeout | { taskId, duration, message } | 执行超时 |
| execution:iteration | { iteration, state, timestamp, duration, aiDecision } | 迭代完成 |

---

## 6. 关键组件说明

### 6.1 InputService

- **位置**: `src/interfaces/gateway/InputService.ts`
- **职责**: 输入消息网关，管理 Telegram Bot 启动
- **特点**: Telegram Bot 自己处理消息，不经过 Intent Agent

### 6.2 MessageService

- **位置**: `src/core/messages/MessageService.ts`
- **职责**: 统一消息持久化服务
- **特点**: 所有来源的消息都通过此服务保存

### 6.3 HookSystem

- **位置**: `src/core/runtime/HookSystem.ts`
- **职责**: 生命周期钩子系统，基于 EventBus
- **特点**: 支持同步/异步触发，支持一次性 Hook

### 6.4 TaskExecutor

- **位置**: `src/application/services/TaskExecutor.ts`
- **职责**: 任务执行服务，调用 AutonomousLoopExecutor
- **特点**: 触发任务生命周期 Hook，更新任务状态

### 6.5 AutonomousLoopExecutor

- **位置**: `src/core/swarm/AutonomousLoopExecutor.ts`
- **职责**: 自主循环执行器
- **特点**: AI 自主分析、执行、检查、改进

---

## 7. 数据流向总结

```
用户输入
    ↓
Telegram Bot / CLI
    ↓
CommandRouter / MessageRouter
    ↓
业务处理 (创建任务、执行命令等)
    ↓
MessageService.saveUserMessage()
    ↓
chat_messages 表 (direction = 'user')
    ↓
AI 处理 (Claude CLI / API)
    ↓
MessageService.saveCompanyResponse()
    ↓
chat_messages 表 (direction = 'company')
    ↓
返回给用户 (Telegram 发送 / CLI 输出)
```

---

## 8. 配置和启动

### 8.1 启动流程

```typescript
// 1. 启动 Input Service (包含 Telegram Bot)
const { kill } = await startInputService();

// 2. 注册消息处理器（可选）
registerMessageHandler(async (message) => {
  // 处理消息
});

// 3. 停止服务
await kill();
```

### 8.2 Telegram 配置

```bash
# 设置 Telegram Bot Token
ai-company config set telegram.bot_token <token>

# 查看配置
ai-company config get telegram.bot_token
```

---

## 9. 注意事项

1. **Telegram Bot 独立处理**: Telegram Bot 自己处理消息，不经过 InputService 的消息队列
2. **Hook 异步处理**: 使用 `emitAsync` 触发 Hook 时需要等待所有处理器完成
3. **消息历史限制**: Session 中只保留最近 30 条聊天消息
4. **会话超时**: 用户会话 30 分钟无活动后自动清理
5. **数据库设计规范**: employees 表只存储公司相关字段，人类属性通过 human_id 关联

---

## 10. 待优化项

- [ ] 添加消息重试机制
- [ ] 实现消息队列持久化
- [ ] 添加消息优先级处理
- [ ] 实现更细粒度的权限控制
- [ ] 添加消息审计日志
