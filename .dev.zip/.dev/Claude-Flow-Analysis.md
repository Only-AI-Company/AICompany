# Claude Flow (Ruflo v3) 深度分析

## 项目概述

**仓库**: https://github.com/ruvnet/claude-flow
**作者**: ruvnet
**Star**: 14.3k
**Fork**: 1.7k
**定位**: 企业级 Claude Agent 编排平台（#1 in agent-based frameworks）

---

## 核心定位

Claude Flow 是一个**企业级多 Agent 编排平台**，专注于：
- 部署智能多 Agent 蜂群
- 协调自主工作流
- 构建对话式 AI 系统
- 企业级架构、分布式蜂群智能
- RAG 集成、原生 Claude Code MCP 支持

---

## 架构层次

```
┌─────────────────────────────────────────────────────────────┐
│                    用户层 (User Layer)                      │
│  Claude Code / CLI / Desktop / VS Code / Cursor / Windsurf  │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                编排层 (Orchestration Layer)                  │
│  MCP Server + Router + Hooks + Statusline                   │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│              智能层 (Intelligence Layer)                     │
│  SONA + MoE + HNSW + EWC++ + Flash Attention + LoRA        │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                蜂群层 (Swarm Layer)                          │
│  60+ Agents + 6 Topologies + 5 Consensus Protocols         │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│               提供商层 (Provider Layer)                      │
│  Anthropic / OpenAI / Google / xAI / Mistral / Ollama      │
└─────────────────────────────────────────────────────────────┘
```

---

## 核心技术栈

### 1. agentic-flow 集成

Claude Flow 深度集成 agentic-flow 作为核心 AI 基础设施：

| 组件 | 性能 | 说明 |
|------|------|------|
| **Agent Booster** | 352x faster | WASM 代码转换，跳过 LLM |
| **ReasoningBank** | 150x-12,500x faster | HNSW 索引的学习记忆 |
| **ONNX Embeddings** | 75x faster | 本地向量生成（3ms vs 230ms） |
| **Multi-Model Router** | 30-50% cost savings | 智能模型选择 |
| **QUIC Transport** | Ultra-low latency | 高性能传输 |

### 2. RuVector 智能层

高性能 Rust/WASM 智能层，提供：

| 能力 | 性能 | 说明 |
|------|------|------|
| **向量搜索** | ~61µs, 16,400 QPS | HNSW 索引 + SIMD 加速 |
| **Flash Attention** | 2.49x-7.47x speedup | 内存优化的注意力机制 |
| **SONA** | <0.05ms adaptation | 自优化神经网络架构 |
| **EWC++** | 95%+ knowledge preserved | 防止灾难性遗忘 |
| **LoRA/MicroLoRA** | 128x compress | 低秩适应，<3μs |
| **Int8 Quantization** | 3.92x memory reduction | 内存优化 |
| **Hyperbolic Embeddings** | Better hierarchy | Poincaré ball 嵌入 |
| **9 RL Algorithms** | PPO, A2C, DQN, Q-Learning, SARSA... | 强化学习 |

### 3. PostgreSQL Vector DB

77+ SQL 函数的企业级向量数据库：

| 特性 | 性能 |
|------|------|
| 搜索延迟 | ~61µs |
| 吞吐量 | 16,400 QPS |
| 注意力机制 | 39 types (self, multi-head, cross, flash, linear, sparse, graph...) |
| GNN 层 | 15 types (GCN, GAT, GraphSAGE, MPNN...) |
| 双曲嵌入 | Poincaré/Lorentz space |
| SIMD 优化 | AVX-512/AVX2/NEON (~2x faster) |

---

## 蜂群系统

### 6 种蜂群拓扑

| 拓扑 | 适用场景 | 执行时间 | 内存/Agent |
|------|----------|----------|------------|
| **Hierarchical** | 结构化任务，清晰权威链 | 0.20s | 256 MB |
| **Mesh** | 协作工作，高冗余 | 0.15s | 192 MB |
| **Ring** | 顺序处理管道 | 0.12s | 128 MB |
| **Star** | 中心化控制 | 0.14s | 180 MB |
| **Hybrid** | 复杂多域任务 | 0.18s | 320 MB |
| **Adaptive** | 动态负载，自动扩展 | Variable | Dynamic |

### Hive Mind (蜂群思维)

**Queen 类型**:
- **Strategic** (战略): 研究规划分析
- **Tactical** (战术): 直接任务管理
- **Adaptive** (自适应): 实时策略调整

**Worker 类型** (8种):
- researcher, coder, analyst, tester, architect, reviewer, optimizer, documenter

**共识协议** (5种):
- **Majority**: 简单民主
- **Weighted**: Queen 3x 权重
- **Byzantine**: 容错 f < n/3
- **Raft**: 领导者日志复制
- **Gossip**: 流言协议传播

**集体记忆类型** (8种):
- knowledge (永久), context (1h TTL), task (30min TTL)
- result (永久), error (24h TTL), metric (1h TTL)
- consensus (永久), system (永久)

---

## Agent Booster (WASM 加速)

### 352x 更快的代码转换

跳过 LLM，直接使用 WASM 处理简单代码转换：

| 操作 | LLM 耗时 | Agent Booster | 加速比 |
|------|----------|---------------|--------|
| 变量重命名 | 352ms | 1ms | **352x** |
| 添加导入 | 420ms | 1ms | **420x** |
| 函数签名 | 380ms | 1ms | **380x** |
| 代码格式化 | 290ms | 1ms | **290x** |
| **1000 文件** | 5.87 min | 1 second | **352x** |

**支持转换意图**:
- `var-to-const`: var/let → const
- `add-types`: 添加 TypeScript 类型
- `add-error-handling`: 包装 try/catch
- `async-await`: Promise → async/await
- `add-logging`: 添加 console.log
- `remove-console`: 移除 console.*

**ROI 示例**: 1000 edits/day 节省 $10/day + 5.86分钟 = **$3,650/year**

---

## 智能三层路由

### Token 优化策略

| 复杂度 | 处理器 | 延迟 | 成本 | 用例 |
|--------|--------|------|------|------|
| **1. Agent Booster** | WASM | <1ms | $0 | var→const, add-types |
| **2. Haiku/Sonnet** | LLM | 500ms-2s | $0.0002-$0.003 | Bug fixes, features |
| **3. Opus** | LLM | 2-5s | $0.015 | Architecture, security |

**节省效果**:
- **75% API 成本降低** (使用合适大小的模型)
- **2.5x Claude Max 扩展** (配额内更多任务)
- **352x 简单任务加速** (跳过 LLM)
- **零 token 浪费** (WASM 处理简单编辑)

---

## Hook 系统 (27 种)

### 工具生命周期 Hooks (6种)

| Hook | 触发时机 | 学习收益 |
|------|----------|----------|
| `pre-edit` | 文件编辑前 | 学习哪些文件需要额外验证 |
| `post-edit` | 文件编辑后 | 学习成功的编辑策略 |
| `pre-command` | Shell 命令前 | 学习哪些命令安全 |
| `post-command` | Shell 命令后 | 学习命令可靠性模式 |
| `pre-task` | 任务开始前 | 学习 task→agent 映射 |
| `post-task` | 任务完成后 | 学习什么让任务成功 |

### 智能与路由 Hooks (8种)

| Hook | 用途 |
|------|------|
| `route` | 选择最佳 agent |
| `explain` | 理解路由决策 |
| `pretrain` | 从代码库引导学习 |
| `build-agents` | 生成优化配置 |
| `transfer` | 跨项目模式导入 |
| `init` | 初始化 hooks |
| `metrics` | 查看学习仪表板 |
| `list` | 列出已注册 hooks |

### 会话管理 Hooks (4种)

| Hook | 用途 |
|------|------|
| `session-start` | 开始会话，加载上下文 |
| `session-end` | 结束会话，持久化状态 |
| `session-restore` | 恢复之前的会话 |
| `notify` | 跨 agent 通知 |

### 智能系统 Hooks (9种)

| Hook | 用途 |
|------|------|
| `intelligence` | 显示 SONA/MoE/HNSW/EWC++ 状态 |
| `intelligence-reset` | 清除学习模式（慎用！） |
| `trajectory-start` | 开始记录 actions 用于学习 |
| `trajectory-step` | 记录 action + reward signal |
| `trajectory-end` | 结束记录，触发学习 |
| `pattern-store` | 存储带 HNSW 索引的模式 |
| `pattern-search` | 查找相似模式 (150x faster) |
| `stats` | 智能诊断，置信度趋势 |
| `attention` | 计算注意力加权相似度 |

---

## 背景工作线程 (12种)

| Worker | 触发器 | 用途 |
|--------|--------|------|
| `ultralearn` | 新项目 | 深度知识获取 |
| `optimize` | 慢操作 | 性能建议 |
| `consolidate` | 会话结束 | 内存整合 |
| `audit` | 安全文件 | 安全漏洞扫描 |
| `map` | 新目录 | 代码库结构映射 |
| `preload` | 缓存未命中 | 资源预加载 |
| `deepdive` | 复杂编辑 | 深度代码分析 |
| `document` | 新代码 | 自动文档 |
| `refactor` | 代码异味 | 重构建议 |
| `benchmark` | 性能代码 | 性能基准 |
| `testgaps` | 无测试 | 测试覆盖率分析 |
| `predict` | 模式匹配 | 预加载可能资源 |

---

## 安全系统 (AIDefence)

### 威胁类别

| 类别 | 严重性 | 模式数 | 检测方法 |
|------|--------|--------|----------|
| **Instruction Override** | 🔴 Critical | 4+ | Keyword + context |
| **Jailbreak** | 🔴 Critical | 6+ | Multi-pattern |
| **Role Switching** | 🟠 High | 3+ | Identity analysis |
| **Context Manipulation** | 🔴 Critical | 6+ | Delimiter detection |
| **Encoding Attacks** | 🟡 Medium | 2+ | Obfuscation scan |
| **Social Engineering** | 🟢 Low-Med | 2+ | Framing analysis |
| **Prompt Injection** | 🔴 Critical | 10+ | Combined analysis |

### 性能

| 操作 | 目标 | 实际 | 吞吐量 |
|------|------|------|--------|
| **Threat Detection** | <10ms | **0.04ms** | 250x faster |
| **Quick Scan** | <5ms | **0.02ms** | Pattern-only |
| **PII Detection** | <3ms | **0.01ms** | Regex-based |
| **HNSW Search** | <1ms | **0.1ms** | With AgentDB |
| **Single-threaded** | - | - | >12,000 req/s |
| **With Learning** | - | - | >8,000 req/s |

---

## 60+ Agent 生态

### 核心开发 (5种)

| Agent | 作用 |
|-------|------|
| coder, reviewer, tester, planner, researcher | 日常开发任务 |

### V3 专业化 (10种)

| Agent | 作用 |
|-------|------|
| queen-coordinator, security-architect, memory-specialist... | 企业编排 |

### 蜂群协调 (5种)

| Agent | 作用 |
|-------|------|
| hierarchical-coordinator, mesh-coordinator, adaptive-coordinator... | 多 agent 模式 |

### 共识与分布式 (7种)

| Agent | 作用 |
|-------|------|
| byzantine-coordinator, raft-manager, gossip-coordinator... | 容错协调 |

### 性能 (5种)

| Agent | 作用 |
|-------|------|
| perf-analyzer, performance-benchmarker, task-orchestrator... | 优化监控 |

### GitHub 与仓库 (9种)

| Agent | 作用 |
|-------|------|
| pr-manager, code-review-swarm, issue-tracker, release-manager... | 仓库自动化 |

### SPARC 方法论 (6种)

| Agent | 作用 |
|-------|------|
| sparc-coord, specification, pseudocode, architecture... | 结构化开发 |

### 专业化开发 (8种)

| Agent | 作用 |
|-------|------|
| backend-dev, mobile-dev, ml-developer, cicd-engineer... | 领域专业知识 |

---

## 42 种预构建技能

### AgentDB & Memory (5种)

| 技能 | 用途 |
|------|------|
| agentdb-vector-search | 150x 更快的语义搜索 |
| agentdb-memory-patterns | 会话记忆，长期存储 |
| agentdb-learning | 9 种 RL 算法 |
| agentdb-optimization | 量化 (4-32x 内存减少) |
| agentdb-advanced | QUIC 同步，多数据库 |

### GitHub & DevOps (5种)

| 技能 | 用途 |
|------|------|
| github-code-review | 多 agent 代码审查 |
| github-project-management | 问题跟踪，项目板 |
| github-multi-repo | 跨仓库协调 |
| github-release-management | 自动化版本控制 |
| github-workflow-automation | CI/CD 管道优化 |

### Flow Nexus (3种)

| 技能 | 用途 |
|------|------|
| flow-nexus-platform | 认证，沙箱，应用 |
| flow-nexus-swarm | 云蜂群部署 |
| flow-nexus-neural | 分布式神经网络训练 |

### V3 实现 (9种)

| 技能 | 用途 |
|------|------|
| v3-ddd-architecture | 有界上下文，模块化设计 |
| v3-security-overhaul | CVE 修复 |
| v3-memory-unification | AgentDB + 150x 搜索 |
| v3-performance-optimization | 2.49x-7.47x 加速 |
| v3-swarm-coordination | 15-agent 分层网格 |
| v3-mcp-optimization | <100ms 响应 |
| v3-core-implementation | DDD 域，依赖注入 |
| v3-integration-deep | agentic-flow 深度集成 |
| v3-cli-modernization | 交互式提示 |

---

## MCP 集成

### 213+ MCP 工具

| 类别 | 工具数 | 示例 |
|------|--------|------|
| **Agent Booster** | 5 | agent_booster_edit_file, agent_booster_batch |
| **ReasoningBank** | 8 | reasoningbank_retrieve, reasoningbank_judge |
| **Embeddings** | 6 | embedding_generate, embedding_search |
| **Model Router** | 4 | router_route, router_stats |
| **Memory** | 10 | memory_store, memory_search, memory_consolidate |
| **Swarm** | 12 | swarm_init, agent_spawn, task_orchestrate |
| **Neural** | 8 | neural_train, neural_patterns, neural_predict |

### MCP 2025-11-25 规范完全兼容

| 特性 | 支持 |
|------|------|
| **Multiple Transports** | stdio, HTTP, WebSocket, in-process |
| **Resources** | list, read, subscribe with caching |
| **Prompts** | Templates with arguments and embedding |
| **Tasks** | Async operations with progress/cancel |
| **Tool Registry** | O(1) lookup, <10ms registration |
| **Connection Pooling** | Max 10 connections, configurable |
| **Session Management** | Timeout handling, authentication |

---

## 上下文自动巡航系统

### 解决上下文窗口限制

Claude Code 有 ~200K token 上下文限制，满时会压缩（丢弃细节）。

**解决方案**: 3 个 hooks 拦截压缩生命周期

| 阶段 | Hook | 动作 |
|------|------|------|
| Every Prompt | UserPromptSubmit | 增量归档到 SQLite (SHA-256 去重) |
| Context Full | PreCompact | 归档 + BLOCK 自动压缩 (exit code 2) |
| After Compact | SessionStart | 从归档恢复 (importance-ranked) |

### 优化阈值

| 区域 | 阈值 | 状态行 | 动作 |
|------|------|--------|------|
| OK | <70% | 🛡️ 43% 86.7K ⊘ (绿色) | 正常运行 |
| Warning | 70-85% | 🛡️ 72% 144K ⊘ (黄色) | 激进归档 |
| Optimize | 85%+ | 🛡️ 88% 176K ⟳2 (红色) | 修剪旧条目 |

### 存储层级

| 层级 | 后端 | 存储 | 特性 |
|------|------|------|------|
| 1 | **SQLite** (默认) | `.claude-flow/data/transcript-archive.db` | WAL, 索引查询, ACID, importance ranking |
| 2 | **RuVector PostgreSQL** | 可配置远程 | TB-scale, pgvector embeddings, GNN search |
| 3 | **AgentDB + HNSW** | 内存 + 持久化 | 150x-12,500x 语义搜索 |
| 4 | **JSON** (fallback) | `.claude-flow/data/transcript-archive.json` | 零依赖，总是工作 |

---

## Claims 系统 (工作协调)

### 生命周期

```
UNCLAIMED → CLAIMED → STEALABLE → HANDED OFF → COMPLETED
   ↑          ↓          ↓            ↓
   └────────────────────────────────┘
```

| 状态 | 说明 |
|------|------|
| **UNCLAIMED** | 开放认领 |
| **CLAIMED** | Agent 或 human 认领 |
| **STEALABLE** | 卡住或放弃 |
| **HANDED OFF** | 新 owner 继续 |
| **COMPLETED** | 完成 |

### CLI 命令

| 命令 | 说明 |
|------|------|
| `issues list` | 查看所有 issues |
| `issues claim` | 认领 issue |
| `issues release` | 释放认领 |
| `issues handoff` | 移交他人 |
| `issues status` | 更新进度 |
| `issues stealable` | 查看可偷取 |
| `issues steal` | 偷取 issue |
| `issues load` | 查看 agent 负载 |
| `issues rebalance` | 重新分配工作 |
| `issues board` | 可视化看板 |

---

## 插件系统

### 官方插件 (19种)

| 插件 | 版本 | 描述 |
|------|------|------|
| **@claude-flow/plugin-agentic-qe** | 3.0.0-alpha.2 | 质量工程，58 AI agents，TDD，覆盖率分析 |
| **@claude-flow/plugin-prime-radiant** | 0.1.4 | 数学 AI 可解释性，6 种引擎 |
| **@claude-flow/plugin-gastown-bridge** | 0.1.0 | Gas Town 编排，WASM 加速 |
| **@claude-flow/teammate-plugin** | 1.0.0-alpha.1 | TeammateTool 集成 |

### 领域特定插件

| 插件 | 用途 |
|------|------|
| **plugin-healthcare-clinical** | HIPAA 合规临床决策支持 |
| **plugin-financial-risk** | PCI-DSS/SOX 合规金融风险分析 |
| **plugin-legal-contracts** | 律师-客户特权保护合同分析 |
| **plugin-code-intelligence** | GNN 模式识别代码分析 |
| **plugin-test-intelligence** | AI 测试生成优化 |
| **plugin-perf-optimizer** | 性能分析 |
| **plugin-neural-coordination** | SONA 多 agent 学习 |
| **plugin-cognitive-kernel** | 工作记忆，注意力控制 |
| **plugin-quantum-optimizer** | 量子优化 |
| **plugin-hyperbolic-reasoning** | 双曲几何推理 |

---

## 性能基准

### V3 性能目标

| 类别 | 指标 | 目标 | 实际 |
|------|------|------|------|
| **Startup** | CLI 冷启动 | <500ms | ✅ 380ms |
| **Startup** | MCP 服务器初始化 | <400ms | ✅ 320ms |
| **Startup** | Agent 生成 | <200ms | ✅ 150ms |
| **Memory** | 向量搜索 | <1ms | ✅ 0.4ms |
| **Memory** | HNSW 索引 | <10ms | ✅ 6ms |
| **Memory** | 内存写入 | <5ms | ✅ 2.1ms |
| **Swarm** | Agent 协调 | <50ms | ✅ 38ms |
| **Swarm** | 共识延迟 | <100ms | ✅ 75ms |
| **Neural** | SONA 适应 | <0.05ms | ✅ 0.03ms |
| **Graph** | 构建 (1k nodes) | <200ms | ✅ 2.78ms (71.9x headroom) |
| **Graph** | PageRank (1k nodes) | <100ms | ✅ 12.21ms (8.2x headroom) |
| **Learning** | 洞察记录 | <5ms | ✅ 0.12ms (41x headroom) |
| **Learning** | 整合 | <500ms | ✅ 0.26ms (1,955x headroom) |

---

## 对比分析

### Claude Flow vs SwarmSDK

| 方面 | Claude Flow | SwarmSDK |
|------|-------------|----------|
| **语言** | TypeScript | Ruby |
| **Star** | 14.3k | ~100+ |
| **架构** | 企业级分布式 | 单进程 |
| **智能层** | SONA + 9 RL algorithms | 无 |
| **向量搜索** | HNSW 150x faster | 无 |
| **WASM 加速** | Agent Booster 352x | 无 |
| **共识协议** | 5 种 (Raft, BFT, Gossip...) | 无 |
| **Hive Mind** | Queen-led 3 types | 无 |
| **MCP 工具** | 213+ | 无 |
| **插件** | 19 官方 + WASM 50 | 无 |
| **PostgreSQL** | 77+ SQL 函数 | 无 |
| **成本优化** | 3 层路由 75% 节省 | 无 |
| **背景工作** | 12 种 auto-triggered | 无 |

### Claude Flow vs AI Company

| 方面 | Claude Flow | AI Company (当前) |
|------|-------------|-------------------|
| **定位** | 企业编排平台 | AI 自主公司 |
| **Agent 数** | 60+ | 12+ |
| **学习系统** | SONA + EWC++ + 9 RL | 基础 hooks |
| **向量搜索** | HNSW 150x | 无 |
| **共识协议** | 5 种 | 无 |
| **成本优化** | Agent Booster 352x | 无 |
| **背景工作** | 12 种 workers | 无 |
| **MCP 工具** | 213+ | 基础集成 |
| **Claims 系统** | 完整工作协调 | 基础状态 |
| **Context Autopilot** | 无限上下文 | 无 |
| **性能基准** | 全面覆盖 | 无 |

---

## 核心借鉴点

### 1. WASM 加速机制

**当前**: 所有代码转换都调用 LLM
**借鉴**: Agent Booster 跳过 LLM，352x 更快

```typescript
// 简单转换意图检测
const intents = ['var-to-const', 'add-types', 'add-error-handling',
                 'async-await', 'add-logging', 'remove-console'];

// 如果匹配简单意图，使用 Edit 工具直接处理
if (matchesSimpleIntent(task)) {
  return editDirectly(task);  // <1ms
}
```

### 2. 三层模型路由

**当前**: 统一使用 Claude 模型
**借鉴**: 复杂度分层路由

| 复杂度 | 模型 | 节省 |
|--------|------|------|
| 简单 | 跳过 LLM (WASM) | 100% |
| 低 | Haiku | 85% |
| 中 | Sonnet | 50% |
| 高 | Opus | 0% |

### 3. HNSW 向量索引

**当前**: 简单 SQL 查询
**借鉴**: HNSW 索引，150x-12,500x 更快

```typescript
// 添加 hnsw-swarm 库
import { HNSW } from 'hnsw-swarm';

const index = new HNSW(384, { m: 16, efConstruction: 200 });

// 搜索
const results = index.search(queryVector, 10);  // <1ms
```

### 4. 学习管道

**当前**: 基础 hooks
**借鉴**: 4 步学习循环

```
RETRIEVE → JUDGE → DISTILL → CONSOLIDATE
  HNSW      Verdict   LoRA      EWC++
```

### 5. Claims 工作协调

**当前**: 基础状态追踪
**借鉴**: 完整工作生命周期管理

```typescript
interface Claim {
  issueId: string;
  status: 'unclaimed' | 'claimed' | 'stealable' | 'handed_off' | 'completed';
  claimedBy?: string;
  claimedAt?: number;
  progress?: number;
}
```

### 6. Context Autopilot

**当前**: 有限上下文管理
**借鉴**: 无限上下文系统

```typescript
// PreCompact hook
function onPreCompact() {
  // Archive to SQLite
  archiveToSQLite();

  // Block auto-compact
  return { exitCode: 2 };
}

// SessionStart hook
function onSessionStart() {
  // Restore from archive
  const archived = loadFromArchive();

  // Inject to context
  return { additionalContext: archived };
}
```

---

## 结论

Claude Flow 是一个**生产级企业平台**，远超当前项目规模。核心借鉴价值：

1. **WASM 加速** - 简单任务跳过 LLM，352x 更快
2. **三层路由** - 成本优化 75%
3. **HNSW 索引** - 向量搜索 150x 更快
4. **学习管道** - RETRIEVE→JUDGE→DISTILL→CONSOLIDATE
5. **Claims 系统** - 完整工作协调
6. **Context Autopilot** - 无限上下文

**但核心差异保持**:
- AI Company = **自主公司**（管理层 + 记忆 + 调度）
- Claude Flow = **编排平台**（Agent 管理 + 学习 + 性能）

AI Company 可以**集成 Claude Flow 作为执行层**，专注管理层价值。
