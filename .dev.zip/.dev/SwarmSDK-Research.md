# SwarmSDK 调研分析

## 项目概述

**仓库**: https://github.com/parruda/swarm
**语言**: Ruby
**架构**: 单进程多 Agent 协作框架

---

## 核心架构

### 1. SwarmMemory - 持久化记忆系统

```ruby
# 特性
- 持久化记忆存储
- 语义搜索（向量嵌入）
- 消息历史管理
- 上下文检索
```

**关键能力**:
- 将对话和工作成果持久化到数据库
- 支持语义搜索查找相关历史记录
- 自动管理上下文窗口大小

---

### 2. Hook 系统 - 12 种事件类型

```ruby
# 事件类型
on_message_added      # 消息添加时
on_message_error      # 消息错误时
on_tool_call          # 工具调用时
on_tool_error         # 工具错误时
on_select_agent       # 选择 Agent 时
on_agent_error        # Agent 错误时
on_run_start          # 运行开始时
on_run_end            # 运行结束时
on_run_error          # 运行错误时
on_validation_error   # 验证错误时
on_delegation_start   # 委托开始时
on_delegation_end     # 委托结束时
```

**Hook 类型**: 每个事件都有 `on_*` 和 `before_*` 两类钩子

---

### 3. 操作系统 - 6 种核心操作

```ruby
# 操作类型
run           # 运行 Agent
handover      # 交接给其他 Agent
assistant     # 创建助手 Agent
context       # 修改上下文
tool          # 调用工具
terminate     # 终止执行
```

---

### 4. 配置系统

**YAML 配置**:
```yaml
swarm:
  agents:
    - name: researcher
      role: "Research specialist"
      instructions: "..."

    - name: writer
      role: "Content writer"
      instructions: "..."

  flows:
    - name: research_and_write
      agents: [researcher, writer]
```

**Ruby DSL**:
```ruby
Swarm.define do
  agent :researcher do
    role "Research specialist"
    instructions "..."
  end

  flow :research_and_write do
    run :researcher
    handover :writer
  end
end
```

---

### 5. 成本追踪

```ruby
# 特性
- Token 使用统计
- 成本计算（按模型定价）
- 预算管理
- 成本报告
```

---

### 6. 日志系统

```ruby
# 日志级别
- DEBUG: 详细调试信息
- INFO: 一般信息
- WARN: 警告信息
- ERROR: 错误信息
```

---

## 技术特点

### 优势

| 特性 | 说明 |
|------|------|
| **解耦设计** | 完全独立于 Claude Code，自主架构 |
| **语义搜索** | 向量嵌入支持智能检索 |
| **事件驱动** | 12 种事件提供完整可观测性 |
| **声明式配置** | YAML/DSL 支持灵活定义 |
| **成本意识** | 内置成本追踪和预算管理 |
| **多 LLM 支持** | 通过 RubyLLM 支持多家提供商 |

### 局限

| 局限 | 说明 |
|------|------|
| **Ruby 生态** | 相比 Python/TypeScript 生态较小 |
| **单进程** | 无法水平扩展 |
| **无原生并发** | Agent 间串行执行 |
| **学习曲线** | Ruby DSL 需要学习成本 |

---

## 与 AI Company 的对比

| 方面 | SwarmSDK | AI Company |
|------|----------|------------|
| 语言 | Ruby | TypeScript |
| 架构 | 单进程 | 可扩展（队列/多进程）|
| 记忆 | 语义搜索 | SQL 查询 |
| Hook | 12 事件 | 6 事件 |
| 配置 | YAML/DSL | 代码 |
| Claude 集成 | 独立 | 深度集成 Claude Code |
| 成本追踪 | ✅ | ❌ |

---

## 可借鉴的设计模式

### 1. 语义记忆搜索

**当前**: 简单 SQL 查询
**建议**: 添加向量嵌入 + 语义搜索

```typescript
interface SemanticMemory {
  // 存储时生成嵌入
  store(message: string, embedding: number[]): void;

  // 语义搜索相似记录
  semanticSearch(query: string, limit: number): Result[];
}
```

### 2. 扩展 Hook 事件

**当前**: 6 种基础事件
**建议**: 扩展到 12+ 种事件

```typescript
interface SwarmHooks {
  // 新增事件
  onAssignmentCreated?(assignment: TaskAssignment): void;
  onAssignmentCompleted?(assignment: TaskAssignment): void;
  onExecutionPaused?(execution: SwarmExecution): void;
  onExecutionResumed?(execution: SwarmExecution): void;
  onTeammateIdle?(teammateId: string): void;
  onBudgetExceeded?(execution: SwarmExecution): void;
}
```

### 3. 成本追踪

**当前**: 无
**建议**: 添加成本记录

```typescript
interface CostTracker {
  trackTokenUsage(model: string, inputTokens: number, outputTokens: number): number;
  getExecutionCost(executionId: string): CostReport;
  getTeammateCost(teammateId: string): CostReport;
}
```

### 4. YAML 团队配置

**当前**: 代码配置
**建议**: 支持 YAML 定义

```yaml
# teams/research-team.yaml
name: "Research Team"
members:
  - id: researcher
    name: "Research Specialist"
    role: developer
    description: "负责信息收集和分析"
    system_prompt: |
      你是一个专业的研究员...
```

---

## 结论

SwarmSDK 是一个成熟的多 Agent 框架，其核心价值在于：

1. **语义记忆**: 让系统"记住"历史并智能检索
2. **事件驱动**: 提供完整的可观测性和扩展点
3. **成本意识**: 支持预算管理和成本优化
4. **声明式配置**: 降低使用门槛

**AI Company 可以借鉴**:
- 语义搜索能力（用于智能执行历史查询）
- 扩展 Hook 系统（增强可观测性）
- 成本追踪机制（预算管理）
- YAML 配置（降低团队定义门槛）

**但保持核心差异**:
- TypeScript 生态 vs Ruby
- 深度 Claude Code 集成 vs 独立架构
- 可扩展队列系统 vs 单进程
