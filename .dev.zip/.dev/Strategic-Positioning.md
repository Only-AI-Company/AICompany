# AI Company - 战略定位重新思考

## 核心问题

Claude Code 蜂群模式已经支持：
- 多 Agent 协作
- 自行生产、审核、交付

那 AI Company 还有什么存在价值？

---

## 定位：我们不是"外包"，是"管理层"

### 蜂群模式解决的是"如何做"
我们解决的是"做什么、何时做、做了之后怎么办"

---

## 三大核心价值

### 1. 统一入口 (Orchestration Layer)

```
┌─────────────────────────────────────────────────────────┐
│                   用户交互层                             │
├─────────────┬─────────────┬─────────────┬──────────────┤
│  Telegram   │     CLI     │  Scheduler  │     API      │
└─────────────┴─────────────┴─────────────┴──────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────┐
│              AI Company 统一管理层                        │
│  - 理解意图（所有渠道）                                   │
│  - 调度执行（何时、用什么方式）                            │
│  - 追踪结果（成功了、失败了、 retry）                      │
└─────────────────────────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────┐
│            Claude Code 蜂群（执行层）                     │
│  - 实际干活                                               │
│  - 生产代码                                               │
│  - 交付结果                                               │
└─────────────────────────────────────────────────────────┘
```

**价值**：用户不需要知道底下是 Claude 蜂群，他们只关心结果

---

### 2. 长期记忆 (Corporate Memory)

Claude Code 的局限：
- 会话结束，记忆丢失
- 不知道上次做了什么
- 不知道有哪些资源可复用

我们的价值：

```typescript
// 用户："继续上次的数据分析"
// Claude Code: "上次？什么上次？"
// AI Company: "好的，我来查看历史..."

interface CorporateMemory {
  // 历史任务
  tasks: Task[];

  // 产出的资源
  resources: {
    scripts: Script[];
    cronJobs: CronJob[];
    documents: Document[];
  };

  // 知识积累
  knowledge: {
    patterns: Pattern[];      // 发现的模式
    solutions: Solution[];    // 解决方案
    mistakes: Mistake[];      // 避免的坑
  };
}
```

**价值**：越用越聪明，积累组织知识

---

### 3. 自主管理 (Autonomous Management)

Claude Code 需要：
- 用户手动启动
- 用户监控进度
- 用户处理失败

我们的价值：

```typescript
// 用户："每周一早上备份数据库"
// AI Company: "好的，我已设置定时任务，会自动执行并监控"

interface AutonomousManager {
  // 调度
  schedule: {
    cron: CronJob[];
    triggers: Trigger[];
  };

  // 监控
  monitor: {
    onSuccess: (result) => void;
    onFailure: (error) => RetryStrategy;
  };

  // 恢复
  recovery: {
    maxRetries: number;
    fallbackPlans: Plan[];
  };
}
```

**价值**：设置后自动运行，不需要人工干预

---

## 架构重新设计

```
┌──────────────────────────────────────────────────────────────┐
│                        用户层                                 │
│  Telegram / CLI / API / Scheduler                            │
└──────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌──────────────────────────────────────────────────────────────┐
│                    AI Company Core                            │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐       │
│  │  Intention   │  │  Memory      │  │  Scheduler   │       │
│  │  Analyzer    │  │  Manager     │  │  & Monitor   │       │
│  └──────────────┘  └──────────────┘  └──────────────┘       │
└──────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌──────────────────────────────────────────────────────────────┐
│              Claude Code Team (Teammates)                    │
│  Developer + Reviewer + Architect + ...                      │
└──────────────────────────────────────────────────────────────┘
```

---

## 具体差异

| 场景 | 直接用 Claude Code | 用 AI Company |
|------|-------------------|---------------|
| 一次性任务 | 直接调用 | 统一入口 |
| 重复任务 | 每次重新输入 | 自动调度 |
| 失败恢复 | 人工重试 | 自动重试+降级 |
| 资源复用 | 不记得上次 | 查找历史资源 |
| 跨渠道 | 各自独立 | 统一管理 |
| 长期追踪 | 无 | 完整历史 |

---

## 新的产品定义

### AI Company 是什么？

**不是**：替代 Claude Code 的代码生成工具
**而是**：管理 Claude Code 蜂群的智能管理层

### 核心能力

1. **意图理解**（所有渠道统一入口）
2. **资源管理**（长期记忆、知识积累）
3. **任务调度**（定时、触发、依赖）
4. **监控恢复**（自动重试、降级策略）
5. **结果追踪**（历史记录、审计日志）

---

## 技术实现方向

### 1. 简化的核心

```typescript
// 精简到本质
interface AICore {
  // 理解意图，决定执行方式
  analyze(input: UserInput): ExecutionPlan;

  // 调用 Claude Team 执行
  execute(plan: ExecutionPlan): ExecutionResult;

  // 记录结果到记忆
  remember(result: ExecutionResult): void;
}
```

### 2. 与 Claude Team 的集成

```typescript
// 不是重复造轮子，而是直接使用
interface ClaudeTeamClient {
  // 创建团队
  createTeam(members: Teammate[]): Team;

  // 分配任务
  assignTask(team: Team, task: Task): Promise<Result>;

  // 监控进度
  monitor(team: Team): Progress;
}
```

### 3. 记忆系统

```typescript
// 简单但强大
interface Memory {
  // 存储任务
  saveTask(task: Task): void;

  // 查找相似任务
  findSimilar(input: string): Task[];

  // 存储资源
  saveResource(resource: Resource): void;

  // 查找可用资源
  findResources(requirement: string): Resource[];
}
```

---

## 总结

| 方面 | 定位 |
|------|------|
| **本质** | Claude Team 的管理层 |
| **价值** | 统一入口、长期记忆、自主管理 |
| **不做什么** | 重复造轮子（代码生成、审查）|
| **做什么** | 管理 Claude Team 做事 |
| **目标** | 设置后自动运行的公司 |

AI Company = **管理层** + **记忆系统** + **调度器**

Claude Code Team = **执行层**
