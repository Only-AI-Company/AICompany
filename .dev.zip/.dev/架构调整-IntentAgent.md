# 架构调整 - Intent Agent

## 概述

新的架构将 CLI 命令、Skills 和 Intent Agent 整合在一起，实现了清晰的分层：

```
┌─────────────────────────────────────────────────────────────────┐
│                        用户输入                                  │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐         │
│  │     CLI      │  │   Telegram   │  │     Web      │         │
│  │  直接调用     │  │  Intent Agent│  │  Intent Agent│         │
│  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘         │
│         │                  │                  │                  │
│         ▼                  ▼                  ▼                  │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │                    内部命令 (Skills)                     │   │
│  │  - task.run, task.status, task.stop                     │   │
│  │  - employee.list, employee.recruit                      │   │
│  │  - script.build, cron.list, config.set                  │   │
│  │  - report.generate                                      │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                  │
│  未匹配 → ┌─────────────────────────────────────────────────┐   │
│           │              Task 队列                          │   │
│           │  - 提交需求                                     │   │
│           │  - CEO Agent 规划                              │   │
│           │  - 分配员工执行                                 │   │
│           └─────────────────────────────────────────────────┘   │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

## 核心组件

### 1. Skill Definition (`src/core/skills/SkillDefinition.ts`)

定义 Skill 接口：

```typescript
interface Skill {
  id: string;              // 唯一标识
  name: string;            // 名称（给 LLM 看）
  description: string;     // 描述（给 LLM 看）
  parameters: SkillParameter[];
  execute: (params, context) => Promise<SkillResult>;
}
```

### 2. Internal Command Skills (`src/core/skills/InternalCommandSkills.ts`)

将 CLI 命令封装成 Skills：

- `task.run` - 提交任务
- `task.status` - 查看状态
- `task.stop` - 停止任务
- `script.build` - 构建脚本
- `employee.list` - 查看员工
- `employee.recruit` - 招募员工
- `config.get/set` - 配置管理
- `cron.list/enable/disable` - 定时任务
- `report.generate` - 工作报告

### 3. Intent Agent (`src/core/agents/IntentAgent.ts`)

意图识别 Agent：

```typescript
// 识别用户输入意图
const result = await intentAgent.recognizeIntent(input);

// 结果：
// - matched: true → 执行匹配的 Skill
// - isUserRequest: true → 创建 Task
```

### 4. Input Service (`src/gateway/InputService.ts`)

处理 Web/TG 输入：

```typescript
await handleInput({
  source: 'telegram',
  content: '当前状态',
});
```

## 流程示例

### CLI 直接调用（绕过 LLM）

```bash
# 用户直接执行 CLI 命令
ai-company status

# 内部直接调用 CEOAgent.getStatus()
# 不经过 Intent Agent
```

### Intent Agent 匹配

```typescript
// 用户在 Telegram 发送：当前状态

// 1. Input Service 接收消息
// 2. Intent Agent 识别意图
const result = {
  matched: true,
  matches: [{
    skillId: 'task.status',
    parameters: {},
    confidence: 0.98,
  }]
};

// 3. 执行 Skill
await skill.execute({}, context);
// 返回：{ success: true, output: "当前状态..." }
```

### 未匹配 → 创建 Task

```typescript
// 用户在 Telegram 发送：开发一个用户管理系统

// 1. Intent Agent 识别
const result = {
  matched: false,
  isUserRequest: true,
  extractedRequest: '开发一个用户管理系统',
};

// 2. 创建 Task
const taskId = await createTask(result.extractedRequest);
// Task 进入 Scheduler，由 CEO Agent 处理
```

## 文件结构

```
src/
├── core/
│   ├── skills/
│   │   ├── SkillDefinition.ts         # Skill 接口定义
│   │   ├── InternalCommandSkills.ts   # 内部命令封装
│   │   ├── BuiltinSkills.ts           # 原有 Skills（兼容）
│   │   └── index.ts
│   └── agents/
│       ├── IntentAgent.ts             # 意图识别 Agent
│       └── index.ts
└── gateway/
    ├── InputService.ts                # 输入处理（集成 Intent Agent）
    ├── SchedulerService.ts            # Task 调度
    ├── CronService.ts                 # Cron 执行
    └── index.ts
```

## 使用方法

### 测试 Intent Agent

```bash
node scripts/test-intent-agent.mjs
```

### 启动 Gateway

```bash
ai-company gateway
```

### 集成到 Telegram Bot

```typescript
import { handleInput } from './gateway/InputService.js';

// Telegram 收到消息
bot.on('message', async (msg) => {
  const result = await handleInput({
    source: 'telegram',
    userId: msg.from.id.toString(),
    content: msg.text,
    messageId: msg.message_id.toString(),
  });

  // 回复用户
  bot.sendMessage(msg.chat.id, result.message);
});
```

## 架构优势

1. **清晰的分层**：CLI 直接调用，Intent Agent 处理自然语言
2. **LLM 友好**：Skills 有清晰的 description 和 parameters
3. **可扩展**：新增 Skill 只需添加定义，无需修改核心逻辑
4. **统一入口**：Web/TG 输入都通过 Intent Agent 处理
5. **兼容现有**：保留原有 BuiltinSkills
