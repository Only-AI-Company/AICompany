# Claude CLI 全面研究文档

> **创建时间**: 2026-02-19
> **目的**: 全面理解和管理 Claude CLI 的所有能力

---

## 1. Claude CLI 基础命令

### 1.1 核心选项

| 选项 | 说明 |
|------|------|
| `-p, --print` | 非交互模式，直接输出结果 |
| `-c, --continue` | 继续最近的对话 |
| `-r, --resume [id]` | 恢复指定会话 |
| `--model <model>` | 指定模型 (sonnet, opus, 或完整名称) |
| `--agent <agent>` | 使用指定的 agent |
| `--agents <json>` | 自定义 agents |
| `--tools <tools>` | 可用工具列表 |
| `--system-prompt <prompt>` | 自定义系统提示词 |
| `--json-schema <schema>` | JSON Schema 验证 |
| `--effort <level>` | 努力级别 |

### 1.2 工具管理

| 选项 | 说明 |
|------|------|
| `--allowedTools` | 允许的工具 |
| `--disallowedTools` | 禁止的工具 |
| `--tools ""` | 禁用所有工具 |
| `--tools default` | 使用所有默认工具 |
| `--tools Bash,Edit,Read` | 指定工具列表 |

### 1.3 权限管理

| 选项 | 说明 |
|------|------|
| `--permission-mode` | 权限模式: acceptEdits, bypassPermissions, default, dontAsk, plan |
| `--add-dir <dirs>` | 允许工具访问的目录 |

---

## 2. Plugin（技能）系统

### 2.1 Plugin 命令

```bash
# 列出已安装的插件
claude plugin list

# 安装插件
claude plugin install <plugin>@<marketplace>
claude plugin install -s user <plugin>
claude plugin install -s project <plugin>

# 启用/禁用插件
claude plugin enable <plugin>
claude plugin disable <plugin>

# 卸载插件
claude plugin uninstall <plugin>

# 更新插件
claude plugin update <plugin>

# 管理市场
claude plugin marketplace list
claude plugin marketplace add <source>
```

### 2.2 已配置的市场

| 市场 | 来源 | 描述 |
|------|------|------|
| `claude-plugins-official` | GitHub: anthropics/claude-plugins-official | 官方插件 |
| `claude-code-workflows` | GitHub: wshobson/agents | 工作流 |
| `claude-scientific-skills` | GitHub: K-Dense-AI/claude-scientific-skills | 科学技能 |

### 2.3 重要技能库

| 技能库 | 技能数量 | 描述 |
|--------|---------|------|
| **@skene/skills-directory** | 764 | 综合技能目录 |
| **obra/superpowers** | 22k+ stars | 超能力包 |
| **K-Dense-AI/claude-scientific-skills** | 140+ | 科学研究技能 |

---

## 3. MCP (Model Context Protocol) 服务器

### 3.1 MCP 命令

```bash
# 添加 MCP 服务器
claude mcp add <name> <commandOrUrl> [args...]

# 列出 MCP 服务器
claude mcp list

# 获取详情
claude mcp get <name>

# 移除 MCP 服务器
claude mcp remove <name>
```

### 3.2 MCP 传输类型

| 传输 | 说明 | 示例 |
|------|------|------|
| **stdio** | 标准输入输出 | `npx @modelcontextprotocol/server-filesystem` |
| **http** | HTTP 端点 | `https://mcp.sentry.dev/mcp` |
| **SSE** | Server-Sent Events | `https://app.corridor.dev/api/mcp` |

### 3.3 常用 MCP 服务器

| 名称 | 功能 |
|------|------|
| `@modelcontextprotocol/server-filesystem` | 文件系统访问 |
| `@modelcontextprotocol/server-github` | GitHub 集成 |
| `@modelcontextprotocol/server-postgres` | PostgreSQL 数据库 |

---

## 4. Agent 系统

### 4.1 Agent 定义

```json
{
  "reviewer": {
    "description": "Reviews code",
    "prompt": "You are a code reviewer..."
  }
}
```

### 4.2 使用 Agent

```bash
# 使用预定义 agent
claude --agent reviewer "Review this code"

# 自定义 agents
claude --agents '{"expert": {"description": "...", "prompt": "..."}}'
```

---

## 5. 输出格式

### 5.1 输出模式

| 格式 | 说明 | 用途 |
|------|------|------|
| `text` | 默认文本格式 | 人类阅读 |
| `json` | JSON 格式 | 脚本解析 |
| `stream-json` | 流式 JSON | 实时处理 |

### 5.2 使用示例

```bash
# 文本输出
claude -p "What is this file?"

# JSON 输出
claude -p --output-format json "What is 2+2?"

# 流式 JSON
claude -p --output-format stream-json "Tell me a story"
```

---

## 6. 高级功能

### 6.1 JSON Schema 验证

```bash
claude -p --json-schema '{"type":"object","properties":{"name":{"type":"string"}},"required":["name"]}}' \
  "Generate a person object"
```

### 6.2 自定义 System Prompt

```bash
claude --system-prompt "You are a helpful assistant who speaks like a pirate" \
  "Hello, how can I help?"
```

### 6.3 组合功能

```bash
# 使用自定义 agent + 指定工具 + JSON 输出
claude \
  --agents '{"analyst": {...}}' \
  --tools Bash,Read \
  --json-schema '{"type": "object"}' \
  -p --output-format json \
  "Analyze this project"
```

---

## 7. 实战示例

### 7.1 代码分析（带工具）

```bash
claude -p --tools Read,Edit,RunTests \
  "Analyze the test suite in this project"
```

### 7.2 JSON 输出（带 Schema）

```bash
claude -p \
  --json-schema '{"type":"array","items":{"type":"object","properties":{"name":{"type":"string"}}}}' \
  "List 5 programming languages"
```

### 7.3 使用特定 Agent

```bash
claude --agent code-review \
  -p "Review this PR: https://github.com/user/repo/pull/123"
```

---

## 8. 技能发现策略

### 8.1 官方技能

```bash
# 添加官方市场
claude plugin marketplace add anthropics/claude-code

# 安装文档处理技能
claude plugin install docx@claude-plugins-official
claude plugin install pdf@claude-plugins-official
claude plugin install pptx@claude-plugins-official
```

### 8.2 社区技能

```bash
# 安装科学技能
claude plugin marketplace add K-Dense-AI/claude-scientific-skills
claude plugin install bioinformatics@claude-scientific-skills

# 安装超能力包
claude plugin marketplace add obra/superpowers
```

---

## 9. 配置文件位置

| 配置 | 位置 |
|------|------|
| 用户配置 | `~/.claude/config.json` |
| 项目配置 | `<project>/.claude/config.json` |
| 技能目录 | `~/.claude/skills/` |
| 插件目录 | `~/.claude/plugins/` |
| MCP 配置 | `~/.claude/mcp.json` 或 `<project>/.mcp.json` |

---

## 10. 下一步行动

1. **创建 Claude CLI 管理模块**
   - `ClaudeCLI.ts` - CLI 封装
   - `SkillManager.ts` - 技能管理
   - `MCPManager.ts` - MCP 管理
   - `AgentManager.ts` - Agent 管理

2. **实现功能**
   - 技能搜索、安装、启用、禁用
   - MCP 服务器管理
   - Agent 创建和切换
   - 工具权限管理

3. **集成到 AI Company**
   - 员工装备技能
   - 使用 MCP 服务器扩展能力
   - 使用 Agent 完成特定任务

---

*更新时间：2026-02-19*
