#!/usr/bin/env python
"""
Agent System Test

测试 Agent 管理系统
"""
import asyncio
import sys
from pathlib import Path

# 添加项目根目录到路径
sys.path.insert(0, str(Path(__file__).parent.parent))

from src.core.agents import (
    ClaudeCodeAgentManager,
    AgentFactory,
    AgentColor,
    AgentLifecycle,
)
from src.core.engine.workspace import WorkspaceManager
from src.models.base import async_session_maker, init_db
from src.models.human import Human, HumanRole
from src.models.employee import Employee, EmployeeStatus
from src.models.project import Project, ProjectStatus


async def test_agent_manager():
    """测试 Agent 管理器"""
    print("=" * 60)
    print("Testing ClaudeCodeAgentManager")
    print("=" * 60)

    manager = ClaudeCodeAgentManager()

    # 测试创建 Agent
    print("\\n1. Creating test agent...")
    await manager.create_agent(
        name="test-agent",
        description="A test agent for demonstration",
        system_prompt="You are a test agent.",
        color=AgentColor.BLUE,
    )
    print("✅ Agent created: test-agent")

    # 测试获取 Agent
    print("\\n2. Getting agent info...")
    agent_info = await manager.get_agent("test-agent")
    if agent_info:
        print(f"✅ Agent found: {agent_info.name}")
        print(f"   Description: {agent_info.config.description[:50]}...")

    # 测试列出所有 Agent
    print("\\n3. Listing all agents...")
    agents = await manager.list_agents()
    print(f"✅ Found {len(agents)} agents")
    for agent in agents[:5]:  # 只显示前 5 个
        print(f"   - {agent.name} ({agent.config.color})")

    # 测试更新 Agent
    print("\\n4. Updating agent...")
    await manager.update_agent(
        name="test-agent",
        add_skills=["python", "testing"],
    )
    print("✅ Agent updated with new skills")

    # 清理
    print("\\n5. Cleaning up...")
    await manager.delete_agent("test-agent")
    print("✅ Test agent deleted")


async def test_workspace_manager():
    """测试工作空间管理器"""
    print("\\n" + "=" * 60)
    print("Testing WorkspaceManager")
    print("=" * 60)

    from uuid import uuid4

    ws_manager = WorkspaceManager()

    # 测试项目工作空间
    print("\\n1. Creating project workspace...")
    project_id = uuid4()
    project_ws = ws_manager.get_project_workspace(project_id)
    print(f"✅ Project workspace: {project_ws}")

    # 测试任务工作空间
    print("\\n2. Creating task workspace...")
    task_id = uuid4()
    task_ws = ws_manager.get_task_workspace(task_id, project_id)
    print(f"✅ Task workspace: {task_ws}")

    # 测试临时工作空间
    print("\\n3. Creating temp workspace...")
    temp_ws = ws_manager.get_temp_workspace("_test")
    print(f"✅ Temp workspace: {temp_ws}")

    # 测试工作空间信息
    print("\\n4. Getting workspace info...")
    info = ws_manager.get_workspace_info(project_ws)
    print(f"✅ Workspace info: {info}")

    # 清理
    print("\\n5. Cleaning up temp workspace...")
    ws_manager.cleanup_temp_workspace(temp_ws)
    print("✅ Temp workspace cleaned")


async def test_agent_factory_with_db():
    """测试 Agent 工厂（需要数据库）"""
    print("\\n" + "=" * 60)
    print("Testing AgentFactory with Database")
    print("=" * 60)

    # 初始化数据库
    await init_db()
    print("✅ Database initialized")

    from src.repositories.human_repository import HumanRepository
    from src.repositories.employee_repository import EmployeeRepository

    async with async_session_maker() as session:
        human_repo = HumanRepository(session)
        employee_repo = EmployeeRepository(session)

        manager = ClaudeCodeAgentManager()
        factory = AgentFactory(manager, human_repo, employee_repo)

        # 获取或创建测试用的 Human 和 Employee
        print("\\n1. Finding test employee...")

        # 查找 CEO
        employees = await employee_repo.find_by_role("ceo")
        if not employees:
            print("⚠️  No CEO employee found. Please run seed_data.py first.")
            return

        employee = employees[0]
        print(f"✅ Found employee: {employee.name}")

        # 测试确保 Agent 存在
        print("\\n2. Ensuring agent for employee...")
        agent_name = await factory.ensure_agent_for_employee(employee)
        print(f"✅ Agent ready: {agent_name}")

        # 测试添加技能
        print("\\n3. Adding skills to agent...")
        await factory.add_skills_to_agent(
            employee,
            new_skills=["strategic_planning", "team_management"],
        )
        print("✅ Skills added")

        # 测试获取活跃 Agent
        print("\\n4. Getting active agents...")
        active_agents = factory.get_active_agents()
        print(f"✅ Active agents: {len(active_agents)}")
        for agent_info in active_agents:
            print(f"   - {agent_info.agent_name} ({agent_info.lifecycle})")


async def main():
    """主测试函数"""
    print("\\n" + "=" * 60)
    print("Agent System Test Suite")
    print("=" * 60)

    try:
        # 测试 Agent 管理器
        await test_agent_manager()

        # 测试工作空间管理器
        await test_workspace_manager()

        # 测试 Agent 工厂（需要数据库）
        await test_agent_factory_with_db()

        print("\\n" + "=" * 60)
        print("🎉 All tests passed!")
        print("=" * 60)

    except Exception as e:
        print(f"\\n❌ Test failed: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    asyncio.run(main())
