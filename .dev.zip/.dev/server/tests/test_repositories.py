"""Repository tests"""
import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from src.models.base import get_async_session_maker
from src.repositories import EmployeeRepository, TaskRepository


async def test_repositories():
    """Test repository functionality"""
    print("\n🧪 Testing Repositories...\n")

    session_maker = get_async_session_maker()
    async with session_maker() as session:
        # Test EmployeeRepository
        emp_repo = EmployeeRepository(session)
        employees = await emp_repo.find_by_status("active")
        print(f"✓ EmployeeRepository.find_by_status('active'): {len(employees)} results")

        ceo = await emp_repo.find_by_role("ceo")
        print(f"✓ EmployeeRepository.find_by_role('ceo'): {len(ceo)} results")

        # Test TaskRepository
        task_repo = TaskRepository(session)
        pending = await task_repo.find_pending_tasks()
        print(f"✓ TaskRepository.find_pending_tasks(): {len(pending)} results")

        by_type = await task_repo.find_by_type("development")
        print(f"✓ TaskRepository.find_by_type('development'): {len(by_type)} results")

    print("\n✅ All repository tests passed!\n")


if __name__ == "__main__":
    asyncio.run(test_repositories())
