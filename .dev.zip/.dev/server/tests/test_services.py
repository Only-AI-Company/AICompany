"""Service tests"""
import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from src.models.base import get_async_session_maker
from src.services import EmployeeService, TaskService


async def test_services():
    """Test service functionality"""
    print("\n🧪 Testing Services...\n")

    session_maker = get_async_session_maker()
    async with session_maker() as session:
        # Test EmployeeService
        emp_service = EmployeeService(session)
        active = await emp_service.get_active_employees()
        print(f"✓ EmployeeService.get_active_employees(): {len(active)} results")

        ceo = await emp_service.get_ceo()
        print(f"✓ EmployeeService.get_ceo(): {ceo.name if ceo else 'None'}")

        ctos = await emp_service.get_by_role("cto")
        print(f"✓ EmployeeService.get_by_role('cto'): {len(ctos)} results")

        # Test TaskService
        task_service = TaskService(session)
        pending = await task_service.get_pending_tasks()
        print(f"✓ TaskService.get_pending_tasks(): {len(pending)} results")

        overdue = await task_service.get_overdue_tasks()
        print(f"✓ TaskService.get_overdue_tasks(): {len(overdue)} results")

    print("\n✅ All service tests passed!\n")


if __name__ == "__main__":
    asyncio.run(test_services())
