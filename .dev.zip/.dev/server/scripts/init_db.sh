#!/bin/bash
# Database Initialization Script

set -e

echo "=========================================="
echo "AI Company - Database Initialization"
echo "=========================================="
echo ""

# Get script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"

cd "$PROJECT_ROOT"

echo "📦 Installing dependencies..."
pip install -e . > /dev/null 2>&1 || pip3 install -e . > /dev/null 2>&1
echo "✅ Dependencies installed"
echo ""

echo "🔄 Running database migrations..."
python scripts/migrate.py up
echo ""

echo "🌱 Seeding initial data..."
python scripts/seed_data.py
echo ""

echo "=========================================="
echo "🎉 Database initialization complete!"
echo "=========================================="
echo ""
echo "To start the server:"
echo "  cd $PROJECT_ROOT"
echo "  uvicorn src.main:app --reload"
