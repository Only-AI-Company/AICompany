#!/usr/bin/env python3
"""
Database CLI

简单的数据库命令行工具
"""
import asyncio
import sys
from pathlib import Path

# 添加项目根目录到 Python 路径
sys.path.insert(0, str(Path(__file__).parent.parent))

from sqlalchemy import select, func

from src.models.base import get_async_session_maker
from src.models import (
    Human,
    Employee,
    EmployeeStatus,
    EmployeeRole,
    Task,
    TaskStatus,
    Goal,
    Memory,
    CompanyChat,
    Crontab,
)


async def show_status():
    """显示数据库状态"""
    print("\n📊 Database Status\n" + "=" * 50)

    session_maker = get_async_session_maker()
    async with session_maker() as session:
        # 统计各表数据量
        tables = [
            ("Humans", Human),
            ("Employees", Employee),
            ("Tasks", Task),
            ("Goals", Goal),
            ("Memories", Memory),
            ("Chats", CompanyChat),
            ("Crontab", Crontab),
        ]

        for name, model in tables:
            count = await session.execute(
                select(func.count()).select_from(model)
            )
            print(f"  {name:<15} {count.scalar()}")

        print("\n" + "=" * 50)

        # 显示活跃员工
        result = await session.execute(
            select(Employee)
            .where(Employee.status == EmployeeStatus.ACTIVE.value)
            .order_by(Employee.last_active.desc())
        )
        employees = result.scalars().all()

        if employees:
            print(f"\n👥 Active Employees ({len(employees)}):\n")
            for emp in employees:
                print(f"  - {emp.name} ({emp.role})")
                print(f"    Status: {emp.status}")
                print(f"    Level: {emp.level}")
                print(f"    Completed: {emp.completed_tasks} tasks")
                print()

        # 显示任务状态
        result = await session.execute(
            select(Task.status, func.count(Task.id))
            .group_by(Task.status)
        )
        task_stats = result.all()

        if task_stats:
            print("\n📋 Tasks by Status:\n")
            for status, count in task_stats:
                print(f"  {status:<20} {count}")


async def show_employees():
    """显示所有员工"""
    print("\n👥 All Employees\n" + "=" * 50)

    session_maker = get_async_session_maker()
    async with session_maker() as session:
        result = await session.execute(
            select(Employee).order_by(Employee.role, Employee.name)
        )
        employees = result.scalars().all()

        for emp in employees:
            print(f"\n  {emp.name}")
            print(f"  Role: {emp.role}")
            print(f"  Status: {emp.status}")
            print(f"  Level: {emp.level}")
            print(f"  Score: {emp.score}")
            print(f"  Completed: {emp.completed_tasks} | Failed: {emp.failed_tasks}")
            print(f"  Model: {emp.model}")


async def show_tasks(limit: int = 20):
    """显示最近的任务"""
    print(f"\n📋 Recent {limit} Tasks\n" + "=" * 50)

    session_maker = get_async_session_maker()
    async with session_maker() as session:
        result = await session.execute(
            select(Task)
            .order_by(Task.created_at.desc())
            .limit(limit)
        )
        tasks = result.scalars().all()

        if not tasks:
            print("  No tasks found.")
            return

        for task in tasks:
            print(f"\n  [{task.status.upper()}] {task.title}")
            print(f"  Type: {task.type} | Priority: {task.priority}")
            print(f"  Owner: {task.owner_id}")
            print(f"  Created: {task.created_at}")
            if task.due_date:
                print(f"  Due: {task.due_date}")


async def main():
    """主函数"""
    import argparse

    parser = argparse.ArgumentParser(description="Database CLI")
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # status 命令
    subparsers.add_parser("status", help="Show database status")

    # employees 命令
    subparsers.add_parser("employees", help="List all employees")

    # tasks 命令
    tasks_parser = subparsers.add_parser("tasks", help="List recent tasks")
    tasks_parser.add_argument("-n", "--limit", type=int, default=20, help="Number of tasks to show")

    args = parser.parse_args()

    if args.command == "status":
        await show_status()
    elif args.command == "employees":
        await show_employees()
    elif args.command == "tasks":
        await show_tasks(args.limit)
    else:
        parser.print_help()


if __name__ == "__main__":
    asyncio.run(main())
