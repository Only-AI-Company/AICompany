#!/usr/bin/env python
"""
Database Migration Script

简化 Alembic 迁移命令行工具
"""
import asyncio
import sys
from pathlib import Path

# 添加项目根目录到 Python 路径
sys.path.insert(0, str(Path(__file__).parent.parent))

import alembic.config
from alembic import command


def main():
    """主函数"""
    if len(sys.argv) < 2:
        print("Usage: python migrate.py <command>")
        print("")
        print("Commands:")
        print("  up          - Apply all pending migrations")
        print("  down        - Rollback last migration")
        print("  current     - Show current migration version")
        print("  history     - Show migration history")
        print("  revision    - Create new migration (usage: revision <message>)")
        print("")
        sys.exit(1)

    cmd = sys.argv[1]
    config = alembic.config.Config("alembic.ini")

    # 设置数据库 URL
    from src.config import get_settings
    settings = get_settings()
    config.set_main_option("sqlalchemy.url", settings.database_url_sync)

    try:
        if cmd == "up":
            print("🔄 Applying migrations...")
            command.upgrade(config, "head")
            print("✅ Migrations applied")

        elif cmd == "down":
            print("🔄 Rolling back migration...")
            command.downgrade(config, "-1")
            print("✅ Migration rolled back")

        elif cmd == "current":
            print("📍 Current migration version:")
            command.current(config)

        elif cmd == "history":
            print("📜 Migration history:")
            command.history(config)

        elif cmd == "revision":
            if len(sys.argv) < 3:
                print("❌ Error: revision command requires a message")
                print("Usage: python migrate.py revision <message>")
                sys.exit(1)

            message = sys.argv[2]
            print(f"📝 Creating new migration: {message}")
            command.revision(config, autogenerate=True, message=message)
            print("✅ Migration file created")

        else:
            print(f"❌ Unknown command: {cmd}")
            sys.exit(1)

    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
