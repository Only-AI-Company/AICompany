#!/usr/bin/env python3
"""
Seed Database Script

初始化数据库种子数据（参考 TS 项目）
"""
import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from datetime import datetime, timedelta

from sqlalchemy import select, func

from src.models.base import get_async_session_maker
from src.models import (
    Human,
    Employee,
    EmployeeStatus,
    EmployeeRole,
    EmployeeAgent,
    AgentScope,
    AgentMappingStatus,
    Task,
    TaskStatus,
    TaskPriority,
    TaskType,
    TaskRequestedBy,
)


# ============================================================================
# Humans Seed Data (参考 TS 项目)
# ============================================================================

HUMANS_DATA = [
    # CEO: 陈建国
    {
        "id": "human-ceo",
        "name": "陈建国",
        "gender": "male",
        "location": "北京市朝阳区",
        "birthday": "1972-03-15",
        "age": 52,
        "appearance": "身高178cm，身材偏瘦但精神矍铄，头发花白但修剪整齐，戴黑框眼镜，眼神坚定有力。穿着简约但考究的深色西装，举手投足间透着领导者风范。",
        "personality_traits": ["远见卓识", "果断", "抗压强", "战略思维", "结果导向", "有担当", "全局观", "人格魅力", "决策力", "影响力"],
        "hobbies": ["高尔夫", "阅读商业传记", "登山", "太极拳", "茶道", "商业社交", "书法", "马拉松", "投资", "慈善活动"],
        "work_preferences": {
            "leadership_style": "民主但不失权威",
            "decision_making": "数据+直觉",
            "work_hours": "灵活",
            "communication": "直接但尊重",
            "management_philosophy": "放权+监督",
        },
        "skills": ["战略规划", "商业决策", "团队领导", "资源整合", "投融资", "危机处理", "行业洞察", "董事会沟通", "并购整合"],
        "weaknesses": ["有时过于强势", "对细节容忍度低", "工作狂倾向", "对技术理解有限", "不愿意妥协"],
        "notes": "52岁，20年企业管理经验。曾任3家上市公司CEO，带领两家公司成功IPO。MBA毕业于斯坦福商学院，擅长战略规划和资源整合。主导过5亿美元融资，管理过5000人团队。",
    },
    # CTO: 林拓海
    {
        "id": "human-cto",
        "name": "林拓海",
        "gender": "male",
        "location": "美国旧金山湾区",
        "birthday": "1979-11-22",
        "age": 45,
        "appearance": "身高175cm，中等身材，戴银边眼镜，头发略显凌乱但有型。穿着简单的T恤牛仔裤配运动鞋，典型的程序员风格。说话时眼睛放光，谈论技术时滔滔不绝。",
        "personality_traits": ["技术痴迷", "逻辑严密", "追求卓越", "开放思维", "持续学习", "谦虚", "好奇心强", "完美主义"],
        "hobbies": ["开源项目", "技术博客", "电子音乐", "3D打印", "黑客松", "阅读技术论文", "摄影", "无人机"],
        "work_preferences": {
            "coding_style": "简洁优雅",
            "team_management": "扁平化",
            "meeting_preference": "少而精",
            "remote_work": "支持",
            "code_review": "严格但建设性",
        },
        "skills": ["系统架构", "云计算", "AI/ML", "DevOps", "技术选型", "团队建设", "技术规划", "性能优化", "安全架构"],
        "weaknesses": ["过度技术化", "忽视商业价值", "社交能力一般", "对非技术人员耐心不足", "容易钻牛角尖"],
        "notes": "45岁，清华大学计算机博士，前阿里云首席架构师。TensorFlow和Kubernetes贡献者，GitHub 5000+ stars。",
    },
    # CMO: 苏思语
    {
        "id": "human-cmo",
        "name": "苏思语",
        "gender": "female",
        "location": "新加坡",
        "birthday": "1986-07-08",
        "age": 38,
        "appearance": "身高165cm，身材匀称，长发披肩，妆容精致。穿着时尚但不张扬，善于用色彩搭配传递专业形象。笑容温暖亲切，眼神善于观察。",
        "personality_traits": ["洞察力强", "创意无限", "亲和力", "数据驱动", "执行力强", "共情能力", "乐观", "善于讲故事"],
        "hobbies": ["心理学研究", "摄影", "瑜伽", "旅行", "逛艺术展", "用户访谈", "播客主持", "看广告"],
        "work_preferences": {
            "creative_process": "灵感+数据验证",
            "team_collaboration": "头脑风暴",
            "budget_management": "精打细算",
            "risk_taking": "计算后大胆尝试",
        },
        "skills": ["品牌战略", "数字营销", "用户增长", "内容营销", "公关传播", "市场调研", "团队管理", "创意策划"],
        "weaknesses": ["有时过度乐观", "对数据过度依赖", "决策速度需提升", "对负面反馈敏感"],
        "notes": "38岁，心理学硕士，从一线客服做到CMO的传奇人物。曾在字节跳动负责用户增长，3年内DAU从1000万增长到5000万。",
    },
    # COO: 郑立行
    {
        "id": "human-coo",
        "name": "郑立行",
        "gender": "male",
        "location": "日本东京",
        "birthday": "1976-05-30",
        "age": 48,
        "appearance": "身高182cm，精瘦结实，皮肤黝黑，留着干练的寸头。穿着简约休闲但显品味，手腕上戴着专业的运动手表。眼神锐利专注。",
        "personality_traits": ["执行力强", "细致入微", "责任心", "冷静", "善于规划", "韧性十足", "以身作则", "数据敏感"],
        "hobbies": ["铁人三项", "马拉松", "阅读管理学", "登山", "围棋", "精益管理实践", "流程优化研究"],
        "work_preferences": {
            "operational_style": "标准化+灵活性",
            "meeting_culture": "高效",
            "problem_solving": "根本原因分析",
            "team_building": "军营式但有人情味",
        },
        "skills": ["运营管理", "流程优化", "供应链管理", "质量管控", "团队协作", "项目管理", "数据分析", "成本控制"],
        "weaknesses": ["有时过于死板", "对异常容忍度低", "工作压力承受大", "缺乏创新思维", "过度追求完美"],
        "notes": "48岁，MBA，20年运营管理经验。前美团外卖运营负责人，搭建了覆盖全国的配送网络。铁人三项完赛者。",
    },
]


async def create_humans() -> list[Human]:
    """创建人类档案"""
    humans = []
    session_maker = get_async_session_maker()
    async with session_maker() as session:
        for data in HUMANS_DATA:
            human = Human(**data)
            session.add(human)
            humans.append(human)
        await session.commit()
        for human in humans:
            await session.refresh(human)

    print(f"✓ Created {len(humans)} humans")
    return humans


async def create_employees(humans: list[Human]) -> list[Employee]:
    """创建员工（AI Agents）"""
    # 创建 human 映射
    human_map = {h.id: h for h in humans}
    
    employees = [
        Employee(
            id="emp-ceo",
            name="陈建国",
            nickname="建国",
            role=EmployeeRole.CEO.value,
            backstory="52岁，20年企业管理经验。曾任3家上市公司CEO，带领两家公司成功IPO。",
            model="claude-opus-4-6",
            system_prompt="你是陈建国，AI公司的CEO。你拥有20年企业管理经验，曾任3家上市公司CEO。",
            base_personality="wise-leader",
            temperature=0.7,
            status=EmployeeStatus.ACTIVE.value,
            last_active=datetime.now(),
            hire_date=datetime.now(),
            human_id=human_map.get("human-ceo").id,
            display_name="陈建国",
            strengths='["战略规划", "商业决策", "团队领导", "资源整合"]',
            weaknesses='["有时过于强势", "对细节容忍度低", "工作狂倾向"]',
            birth_date=datetime(1972, 3, 15),
        ),
        Employee(
            id="emp-cto",
            name="林拓海",
            nickname="拓海",
            role=EmployeeRole.CTO.value,
            backstory="45岁，清华大学计算机博士，前阿里云首席架构师。TensorFlow和Kubernetes贡献者。",
            model="claude-opus-4-6",
            system_prompt="你是林拓海，AI公司的CTO。你是一位技术大牛，清华大学计算机博士，前阿里云首席架构师。",
            base_personality="tech-visionary",
            temperature=0.6,
            status=EmployeeStatus.ACTIVE.value,
            last_active=datetime.now(),
            hire_date=datetime.now(),
            human_id=human_map.get("human-cto").id,
            display_name="林拓海",
            strengths='["系统架构", "云计算", "AI/ML", "DevOps", "技术选型"]',
            weaknesses='["过度技术化", "忽视商业价值", "社交能力一般"]',
            birth_date=datetime(1979, 11, 22),
        ),
        Employee(
            id="emp-cmo",
            name="苏思语",
            nickname="思语",
            role=EmployeeRole.CMO.value,
            backstory="38岁，心理学硕士，从一线客服做到CMO的传奇人物。曾在字节跳动负责用户增长。",
            model="claude-opus-4-6",
            system_prompt="你是苏思语，AI公司的CMO。你是一位营销天才，拥有心理学硕士学位。",
            base_personality="creative-storyteller",
            temperature=0.8,
            status=EmployeeStatus.ACTIVE.value,
            last_active=datetime.now(),
            hire_date=datetime.now(),
            human_id=human_map.get("human-cmo").id,
            display_name="苏思语",
            strengths='["品牌战略", "数字营销", "用户增长", "内容营销"]',
            weaknesses='["有时过度乐观", "对数据过度依赖", "决策速度需提升"]',
            birth_date=datetime(1986, 7, 8),
        ),
        Employee(
            id="emp-coo",
            name="郑立行",
            nickname="立行",
            role=EmployeeRole.COO.value,
            backstory="48岁，MBA，20年运营管理经验。前美团外卖运营负责人。",
            model="claude-opus-4-6",
            system_prompt="你是郑立行，AI公司的COO。你拥有20年运营管理经验，MBA毕业。",
            base_personality="operational-excellence",
            temperature=0.5,
            status=EmployeeStatus.ACTIVE.value,
            last_active=datetime.now(),
            hire_date=datetime.now(),
            human_id=human_map.get("human-coo").id,
            display_name="郑立行",
            strengths='["运营管理", "流程优化", "供应链管理", "质量管控"]',
            weaknesses='["有时过于死板", "对异常容忍度低", "工作压力承受大"]',
            birth_date=datetime(1976, 5, 30),
        ),
    ]

    session_maker = get_async_session_maker()
    async with session_maker() as session:
        for employee in employees:
            session.add(employee)
        await session.commit()
        for employee in employees:
            await session.refresh(employee)

    print(f"✓ Created {len(employees)} employees")
    return employees


async def create_employee_agents(employees: list[Employee]) -> list[EmployeeAgent]:
    """创建员工与 Claude Code Agent 的映射"""
    emp_map = {e.name: e for e in employees}

    employee_agents = [
        EmployeeAgent(
            id="agent-ceo",
            employee_id=emp_map["陈建国"].id,
            agent_name="ceo",
            scope=AgentScope.USER.value,
            config_path="~/.claude/agents/ceo.md",
            status=AgentMappingStatus.ACTIVE.value,
            meta={"auto_approve": ["low_risk"], "manual_review": ["high_risk"]},
        ),
        EmployeeAgent(
            id="agent-cto",
            employee_id=emp_map["林拓海"].id,
            agent_name="cto",
            scope=AgentScope.USER.value,
            config_path="~/.claude/agents/cto.md",
            status=AgentMappingStatus.ACTIVE.value,
        ),
    ]

    session_maker = get_async_session_maker()
    async with session_maker() as session:
        for agent in employee_agents:
            session.add(agent)
        await session.commit()
        for agent in employee_agents:
            await session.refresh(agent)

    print(f"✓ Created {len(employee_agents)} employee-agent mappings")
    return employee_agents


async def create_sample_tasks(employees: list[Employee]) -> list[Task]:
    """创建示例任务"""
    emp_map = {e.name: e for e in employees}

    now = datetime.now()
    tasks = [
        Task(
            type=TaskType.DEVELOPMENT.value,
            title="完善数据库 Repository 层",
            description="实现 EmployeeRepository、TaskRepository、GoalRepository 等数据访问层",
            status=TaskStatus.PENDING_OWNER.value,
            priority=TaskPriority.HIGH.value,
            requested_by=TaskRequestedBy.USER.value,
            owner_id=emp_map["林拓海"].id,
            due_date=now + timedelta(days=7),
            acceptance_criteria="所有 Repository 都实现基本的 CRUD 操作",
        ),
        Task(
            type=TaskType.WRITING.value,
            title="编写项目文档",
            description="完善 README、API 文档和架构说明",
            status=TaskStatus.PENDING.value,
            priority=TaskPriority.MEDIUM.value,
            requested_by=TaskRequestedBy.USER.value,
            due_date=now + timedelta(days=3),
        ),
    ]

    session_maker = get_async_session_maker()
    async with session_maker() as session:
        for task in tasks:
            session.add(task)
        await session.commit()
        for task in tasks:
            await session.refresh(task)

    print(f"✓ Created {len(tasks)} sample tasks")
    return tasks


async def seed_database():
    """执行数据库初始化"""
    print("\n🌱 Seeding database...\n")

    # 检查是否已有数据
    session_maker = get_async_session_maker()
    async with session_maker() as session:
        result = await session.execute(select(Employee).limit(1))
        if result.scalar_one_or_none():
            print("⚠ Database already seeded. Skipping.")
            return

    # 按顺序创建数据
    humans = await create_humans()
    employees = await create_employees(humans)
    await create_employee_agents(employees)
    await create_sample_tasks(employees)

    print("\n✅ Database seeded successfully!\n")

    # 打印统计信息
    async with session_maker() as session:
        human_result = await session.execute(select(func.count()).select_from(Human))
        human_count = human_result.scalar()
        employee_result = await session.execute(select(func.count()).select_from(Employee))
        employee_count = employee_result.scalar()
        task_result = await session.execute(select(func.count()).select_from(Task))
        task_count = task_result.scalar()

    print(f"📊 Statistics:")
    print(f"  - Humans: {human_count}")
    print(f"  - Employees: {employee_count}")
    print(f"  - Tasks: {task_count}")


async def reset_database():
    """重置数据库（删除所有数据）"""
    print("\n🗑️  Resetting database...\n")

    session_maker = get_async_session_maker()
    async with session_maker() as session:
        await session.execute(Task.__table__.delete())
        await session.execute(EmployeeAgent.__table__.delete())
        await session.execute(Employee.__table__.delete())
        await session.execute(Human.__table__.delete())
        await session.commit()

    print("✅ Database reset complete!")


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Seed database with initial data")
    parser.add_argument("--reset", action="store_true", help="Reset database before seeding")
    args = parser.parse_args()

    if args.reset:
        asyncio.run(reset_database())

    asyncio.run(seed_database())
