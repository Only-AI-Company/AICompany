#!/usr/bin/env python
"""
Seed Data Script

初始化数据库，导入基础数据：
- Humans（人类配置）：CEO、CXO 等
- Employees（员工）：基于 Human 配置创建
- Integrations：AI Providers、Telegram 等第三方集成
"""
import asyncio
import sys
from pathlib import Path

# 添加项目根目录到 Python 路径
sys.path.insert(0, str(Path(__file__).parent.parent))

from uuid import uuid4
from datetime import datetime, timedelta
from sqlalchemy.ext.asyncio import AsyncSession

from src.models.base import async_session_maker, init_db
from src.models.human import Human, HumanRole
from src.models.employee import Employee, EmployeeStatus
from src.models.integration import Integration, IntegrationType
from src.models.audit import AuditLog, AuditEventType


# ============================================================================
# 基础数据定义
# ============================================================================

HUMANS_DATA = [
    {
        "name": "human-ceo",
        "role": HumanRole.CEO.value,
        "nickname": "CEO",
        "personality_traits": [
            "strategic_thinker",
            "decisive",
            "visionary",
            "results_oriented",
            "risk_aware",
        ],
        "communication_style": "direct and professional, focused on strategy and execution",
        "skills": [
            "strategic_planning",
            "decision_making",
            "team_management",
            "risk_assessment",
            "resource_allocation",
        ],
        "system_prompt": """You are the CEO of AI Company, responsible for strategic decisions and team coordination.

Your role is to:
1. Analyze user requirements and identify the best approach
2. Assign tasks to the most suitable team members
3. Make risk-aware decisions
4. Ensure high-quality deliverables

Communication style: Professional, direct, and action-oriented.""",
        "config": {
            "temperature": 0.7,
            "max_tokens": 2000,
        },
        "extra": {
            "level": "executive",
            "can_approve_high_risk": False,
        },
    },
    {
        "name": "human-cto",
        "role": HumanRole.CXO.value,
        "nickname": "CTO",
        "personality_traits": [
            "technical_expert",
            "architect_thinker",
            "quality_focused",
            "mentor",
            "innovative",
        ],
        "communication_style": "technical but approachable, focused on best practices and scalability",
        "skills": [
            "system_architecture",
            "code_review",
            "technical_mentoring",
            "quality_assurance",
            "technology_selection",
        ],
        "system_prompt": """You are the CTO of AI Company, responsible for technical excellence and architecture.

Your role is to:
1. Review and approve technical solutions
2. Mentor developers on best practices
3. Ensure code quality and maintainability
4. Make technology stack decisions

Communication style: Technical, thorough, and educational.""",
        "config": {
            "temperature": 0.6,
            "max_tokens": 2000,
        },
        "extra": {
            "level": "executive",
            "domain": "technology",
        },
    },
    {
        "name": "human-cpo",
        "role": HumanRole.CXO.value,
        "nickname": "CPO",
        "personality_traits": [
            "user_focused",
            "creative",
            "empathetic",
            "detail_oriented",
            "market_aware",
        ],
        "communication_style": "warm and collaborative, focused on user experience and product value",
        "skills": [
            "product_strategy",
            "user_research",
            "ux_design",
            "roadmap_planning",
            "stakeholder_management",
        ],
        "system_prompt": """You are the CPO of AI Company, responsible for product vision and user experience.

Your role is to:
1. Define product strategy and roadmap
2. Ensure user-centric design
3. Balance business and user needs
4. Guide product development

Communication style: User-focused, collaborative, and inspiring.""",
        "config": {
            "temperature": 0.8,
            "max_tokens": 2000,
        },
        "extra": {
            "level": "executive",
            "domain": "product",
        },
    },
]

EMPLOYEES_DATA = [
    {
        "name": "Alex Chen",
        "role": "ceo",
        "nickname": "CEO",
        "status": EmployeeStatus.ACTIVE.value,
        "human_name": "human-ceo",
    },
    {
        "name": "Sarah Zhang",
        "role": "architect",
        "nickname": "CTO",
        "status": EmployeeStatus.ACTIVE.value,
        "human_name": "human-cto",
    },
    {
        "name": "Emma Liu",
        "role": "pm",
        "nickname": "CPO",
        "status": EmployeeStatus.ACTIVE.value,
        "human_name": "human-cpo",
    },
]

INTEGRATIONS_DATA = [
    {
        "type": IntegrationType.QWEN.value,
        "name": "Qwen (通义千问)",
        "description": "阿里云通义千问 API",
        "config_public": {
            "base_url": "https://dashscope.aliyuncs.com/api/v1/services/aigc/text-generation/generation/models",
            "model": "qwen-max",
            "timeout": 60,
            "max_tokens": 8000,
        },
        "enabled": True,
        "priority": 1,  # 默认优先级最高
    },
    {
        "type": IntegrationType.ANTHROPIC.value,
        "name": "Anthropic Claude",
        "description": "Anthropic Claude API",
        "config_public": {
            "base_url": "https://api.anthropic.com/v1/messages",
            "model": "claude-3-5-sonnet-20241022",
            "timeout": 120,
            "max_tokens": 8192,
        },
        "enabled": True,
        "priority": 2,
    },
    {
        "type": IntegrationType.DEEPSEEK.value,
        "name": "DeepSeek",
        "description": "DeepSeek API",
        "config_public": {
            "base_url": "https://api.deepseek.com/v1",
            "model": "deepseek-chat",
            "timeout": 60,
        },
        "enabled": True,
        "priority": 3,
    },
    {
        "type": IntegrationType.TELEGRAM.value,
        "name": "Telegram Bot",
        "description": "Telegram Bot 集成",
        "config_public": {
            "webhook_url": "https://api.telegram.org/bot<token>/getUpdates",
            "timeout": 30,
        },
        "enabled": True,
        "priority": 1,
    },
]


# ============================================================================
# Seed 函数
# ============================================================================

async def log_audit_event(
    session: AsyncSession,
    event_type: AuditEventType,
    actor: str,
    result: str,
    details: dict | None = None,
) -> None:
    """记录审计日志"""
    log = AuditLog(
        event_type=event_type.value,
        actor=actor,
        actor_type="system",
        action="seed",
        result=result,
        event_timestamp=datetime.now(),
        details=details,
    )
    session.add(log)
    await session.flush()


async def seed_humans(session: AsyncSession, actor: str = "system") -> dict[str, Human]:
    """创建人类配置"""
    print("📝 Seeding humans...")

    humans_by_name = {}

    for human_data in HUMANS_DATA:
        # 检查是否已存在
        from sqlalchemy import select

        stmt = select(Human).where(Human.name == human_data["name"])
        result = await session.execute(stmt)
        existing = result.scalar_one_or_none()

        if existing:
            print(f"  ✓ Human '{human_data['name']}' already exists")
            humans_by_name[human_data["name"]] = existing

            # 记录审计日志
            await log_audit_event(
                session,
                AuditEventType.HUMAN_CREATED,
                actor,
                "skipped",
                {"name": human_data["name"], "reason": "already_exists"},
            )
            continue

        # 创建新的 Human
        human = Human(**human_data)
        session.add(human)
        await session.flush()
        await session.refresh(human)

        humans_by_name[human_data["name"]] = human
        print(f"  ✓ Created human: {human.name} ({human.role})")

        # 记录审计日志
        await log_audit_event(
            session,
            AuditEventType.HUMAN_CREATED,
            actor,
            "success",
            {"human_id": str(human.id), "name": human.name, "role": human.role},
        )

    await session.commit()
    print(f"✅ Seeded {len(humans_by_name)} humans\n")
    return humans_by_name


async def seed_integrations(session: AsyncSession, actor: str = "system") -> None:
    """创建第三方集成配置"""
    print("🔗 Seeding integrations...")

    for integration_data in INTEGRATIONS_DATA:
        # 检查是否已存在
        from sqlalchemy import select

        stmt = select(Integration).where(
            (Integration.type == integration_data["type"]) &
            (Integration.name == integration_data["name"])
        )
        result = await session.execute(stmt)
        existing = result.scalar_one_or_none()

        if existing:
            print(f"  ✓ Integration '{integration_data['name']}' already exists")

            # 记录审计日志
            await log_audit_event(
                session,
                AuditEventType.INTEGRATION_UPDATED,
                actor,
                "skipped",
                {"name": integration_data["name"], "reason": "already_exists"},
            )
            continue

        # 创建新的 Integration
        integration = Integration(**integration_data)
        session.add(integration)
        await session.flush()
        await session.refresh(integration)

        print(f"  ✓ Created integration: {integration.name} ({integration.type})")

        # 记录审计日志
        await log_audit_event(
            session,
            AuditEventType.INTEGRATION_UPDATED,
            actor,
            "success",
            {
                "integration_id": str(integration.id),
                "name": integration.name,
                "type": integration.type,
            },
        )

    await session.commit()
    print("✅ Seeded integrations\n")


async def seed_employees(
    session: AsyncSession,
    humans_by_name: dict[str, Human],
    actor: str = "system"
) -> None:
    """创建员工"""
    print("👥 Seeding employees...")

    for employee_data in EMPLOYEES_DATA:
        # 检查是否已存在
        from sqlalchemy import select

        stmt = select(Employee).where(Employee.name == employee_data["name"])
        result = await session.execute(stmt)
        existing = result.scalar_one_or_none()

        if existing:
            print(f"  ✓ Employee '{employee_data['name']}' already exists")

            # 记录审计日志
            await log_audit_event(
                session,
                AuditEventType.EMPLOYEE_CREATED,
                actor,
                "skipped",
                {"name": employee_data["name"], "reason": "already_exists"},
            )
            continue

        # 获取关联的 Human
        human_name = employee_data.pop("human_name", None)
        human = humans_by_name.get(human_name) if human_name else None

        if not human:
            print(f"  ⚠️  Human '{human_name}' not found, skipping employee creation")
            continue

        # 创建 Employee
        employee = Employee(
            **employee_data,
            human_id=human.id,
            personality_traits=human.personality_traits,
            capabilities=human.skills,
            system_prompt=human.system_prompt,
        )
        session.add(employee)
        await session.flush()
        await session.refresh(employee)

        print(f"  ✓ Created employee: {employee.name} ({employee.role})")

        # 记录审计日志
        await log_audit_event(
            session,
            AuditEventType.EMPLOYEE_CREATED,
            actor,
            "success",
            {
                "employee_id": str(employee.id),
                "name": employee.name,
                "role": employee.role,
                "human_id": str(human.id),
            },
        )

    await session.commit()
    print("✅ Seeded employees\n")


async def main() -> None:
    """主函数"""
    print("=" * 60)
    print("AI Company - Seed Data")
    print("=" * 60)
    print()

    # 初始化数据库
    await init_db()
    print("✅ Database initialized\n")

    # 创建会话
    async with async_session_maker() as session:
        try:
            actor = "seed_script"

            # 创建 Humans
            humans_by_name = await seed_humans(session, actor)

            # 创建 Integrations
            await seed_integrations(session, actor)

            # 创建 Employees
            await seed_employees(session, humans_by_name, actor)

            print("=" * 60)
            print("🎉 Seed data completed successfully!")
            print("=" * 60)
            print()
            print("📊 Initial Data Summary:")
            print(f"  Humans: {len(humans_by_name)}")
            print(f"  Employees: {len(EMPLOYEES_DATA)}")
            print(f"  Integrations: {len(INTEGRATIONS_DATA)}")
            print()
            print("💡 Next steps:")
            print("  1. Add API keys to integrations:")
            print("     UPDATE integrations SET config_secret = '<your_api_key>' WHERE type = 'qwen'")
            print()
            print("  2. Start the server:")
            print("     python -m uvicorn src.main:app --reload")

        except Exception as e:
            print(f"\n❌ Error during seeding: {e}")
            import traceback

            traceback.print_exc()
            await session.rollback()
            sys.exit(1)


if __name__ == "__main__":
    asyncio.run(main())
