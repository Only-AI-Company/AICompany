"""
AI Company - Main Application

FastAPI 应用入口
"""
import uuid
from contextlib import asynccontextmanager
from typing import Callable

from fastapi import FastAPI, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from prometheus_client import generate_latest, CONTENT_TYPE_LATEST
from starlette.middleware.base import BaseHTTPMiddleware

from src.config import settings
from src.models import init_db, close_db
from src.utils.logging import get_logger, setup_logging

logger = get_logger(__name__)


class TraceIDMiddleware(BaseHTTPMiddleware):
    """追踪 ID 中间件"""

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        # 生成或获取追踪 ID
        trace_id = request.headers.get("X-Trace-ID") or str(uuid.uuid4())
        request.state.trace_id = trace_id

        # 处理请求
        response = await call_next(request)

        # 添加追踪 ID 到响应头
        response.headers["X-Trace-ID"] = trace_id
        return response


class LoggingMiddleware(BaseHTTPMiddleware):
    """日志中间件"""

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        logger.info(
            "Request started",
            extra={
                "method": request.method,
                "url": str(request.url),
                "path": request.url.path,
                "client": request.client.host if request.client else None,
            },
        )

        response = await call_next(request)

        logger.info(
            "Request completed",
            extra={
                "method": request.method,
                "path": request.url.path,
                "status_code": response.status_code,
            },
        )

        return response


@asynccontextmanager
async def lifespan(app: FastAPI):
    """应用生命周期管理"""
    # 启动时
    logger.info("Starting AI Company API", extra={"version": settings.APP_VERSION})

    # 初始化数据库
    await init_db()
    logger.info("Database initialized")

    yield

    # 关闭时
    logger.info("Shutting down AI Company API")
    await close_db()
    logger.info("Database connection closed")


# 创建 FastAPI 应用
app = FastAPI(
    title=settings.APP_NAME,
    version=settings.APP_VERSION,
    description="AI-powered autonomous company with multi-agent system",
    docs_url="/docs" if settings.is_development else None,
    redoc_url="/redoc" if settings.is_development else None,
    lifespan=lifespan,
)

# 添加中间件
app.add_middleware(TraceIDMiddleware)
app.add_middleware(LoggingMiddleware)

# CORS 配置
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"] if settings.is_development else ["https://yourdomain.com"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# 健康检查
@app.get("/health")
async def health_check():
    """健康检查端点"""
    return {
        "status": "healthy",
        "service": settings.APP_NAME,
        "version": settings.APP_VERSION,
        "environment": settings.ENVIRONMENT,
    }


# Prometheus 指标
@app.get("/metrics")
async def metrics():
    """Prometheus 指标端点"""
    return Response(generate_latest(), media_type=CONTENT_TYPE_LATEST)


# 根路径
@app.get("/")
async def root():
    """根路径"""
    return {
        "service": settings.APP_NAME,
        "version": settings.APP_VERSION,
        "status": "running",
        "docs": "/docs" if settings.is_development else None,
    }


# API 路由将在后续添加
# app.include_router(api_router, prefix="/api/v1")


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        "src.main:app",
        host=settings.API_HOST,
        port=settings.API_PORT,
        reload=settings.is_development,
        log_level=settings.LOG_LEVEL.lower(),
    )
