"""
AI Company Configuration

使用 Pydantic Settings 管理配置，支持环境变量和 .env 文件
"""
from functools import lru_cache
from typing import Literal
from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """应用配置"""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=True,
        extra="ignore",
    )

    # 应用配置
    APP_NAME: str = "AI Company"
    APP_VERSION: str = "0.1.0"
    DEBUG: bool = False
    ENVIRONMENT: Literal["development", "staging", "production"] = "development"

    # 数据库
    DATABASE_URL: str = Field(
        default="sqlite+aiosqlite://./data.db",
        description="数据库连接 URL"
    )

    # Redis
    REDIS_URL: str = "redis://localhost:6379/0"

    # LLM Providers
    ANTHROPIC_API_KEY: str | None = None
    QWEN_API_KEY: str | None = None
    DEEPSEEK_API_KEY: str | None = None
    KIMI_API_KEY: str | None = None
    MINIMAX_API_KEY: str | None = None
    ZAI_API_KEY: str | None = None

    # LLM 默认配置
    DEFAULT_LLM_PROVIDER: Literal["anthropic", "qwen", "deepseek", "kimi", "minimax", "zai"] = "qwen"
    DEFAULT_LLM_MODEL: str = "qwen-max"

    # Celery
    CELERY_BROKER_URL: str = "redis://localhost:6379/1"
    CELERY_RESULT_BACKEND: str = "redis://localhost:6379/2"

    # 日志
    LOG_LEVEL: Literal["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"] = "INFO"

    # API 服务
    API_HOST: str = "0.0.0.0"
    API_PORT: int = 8000

    # 外部集成
    TELEGRAM_BOT_TOKEN: str | None = None
    TELEGRAM_CHAT_ID: str | None = None
    XIAOHONGSHU_COOKIE: str | None = None
    TWITTER_API_KEY: str | None = None
    TWITTER_API_SECRET: str | None = None
    TWITTER_ACCESS_TOKEN: str | None = None
    TWITTER_ACCESS_SECRET: str | None = None

    @field_validator("DATABASE_URL")
    @classmethod
    def validate_database_url(cls, v: str) -> str:
        """验证数据库 URL 格式"""
        if not v:
            raise ValueError("DATABASE_URL 不能为空")
        return v

    @property
    def is_development(self) -> bool:
        """是否为开发环境"""
        return self.ENVIRONMENT == "development"

    @property
    def is_production(self) -> bool:
        """是否为生产环境"""
        return self.ENVIRONMENT == "production"

    @property
    def database_url_sync(self) -> str:
        """同步数据库 URL（用于 Alembic）"""
        return self.DATABASE_URL.replace("+aiosqlite", "").replace(
            "+asyncpg", ""
        )


@lru_cache
def get_settings() -> Settings:
    """获取配置单例"""
    return Settings()


# 导出配置实例
settings = get_settings()
