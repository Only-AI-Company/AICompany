"""
Base Repository

提供通用的数据访问接口（Repository 模式）
"""
from typing import Generic, TypeVar, Type, Optional, List, Any
from uuid import UUID

from pydantic import BaseModel
from sqlalchemy import select, update, delete
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import DeclarativeBase

from src.models.base import Base, UUIDMixin

ModelType = TypeVar("ModelType", bound=Base)
CreateSchemaType = TypeVar("CreateSchemaType", bound=BaseModel)
UpdateSchemaType = TypeVar("UpdateSchemaType", bound=BaseModel)


class BaseRepository(Generic[ModelType]):
    """
    基础 Repository

    提供标准的 CRUD 操作
    """

    def __init__(self, model: Type[ModelType], session: AsyncSession):
        self.model = model
        self.session = session

    async def get(self, id: UUID | str) -> Optional[ModelType]:
        """
        根据 ID 获取单个对象

        Args:
            id: 对象 ID

        Returns:
            找到的对象，不存在则返回 None
        """
        stmt = select(self.model).where(self.model.id == id)
        result = await self.session.execute(stmt)
        return result.scalar_one_or_none()

    async def get_by(
        self, **filters: Any
    ) -> Optional[ModelType]:
        """
        根据条件获取单个对象

        Args:
            **filters: 过滤条件

        Returns:
            找到的对象，不存在则返回 None
        """
        stmt = select(self.model).filter_by(**filters)
        result = await self.session.execute(stmt)
        return result.scalar_one_or_none()

    async def get_all(
        self,
        skip: int = 0,
        limit: int = 100,
        **filters: Any,
    ) -> List[ModelType]:
        """
        获取所有对象（支持分页和过滤）

        Args:
            skip: 跳过记录数
            limit: 返回记录数
            **filters: 过滤条件

        Returns:
            对象列表
        """
        stmt = select(self.model).filter_by(**filters).offset(skip).limit(limit)
        result = await self.session.execute(stmt)
        return list(result.scalars().all())

    async def create(
        self, obj: ModelType
    ) -> ModelType:
        """
        创建新对象

        Args:
            obj: 要创建的对象

        Returns:
            创建的对象（包含生成的 ID）
        """
        self.session.add(obj)
        await self.session.flush()
        await self.session.refresh(obj)
        return obj

    async def update(
        self,
        id: UUID | str,
        **kwargs: Any,
    ) -> Optional[ModelType]:
        """
        更新对象

        Args:
            id: 对象 ID
            **kwargs: 要更新的字段

        Returns:
            更新后的对象，不存在则返回 None
        """
        stmt = (
            update(self.model)
            .where(self.model.id == id)
            .values(**kwargs)
            .returning(self.model)
        )
        result = await self.session.execute(stmt)
        return result.scalar_one_or_none()

    async def delete(self, id: UUID | str) -> bool:
        """
        删除对象

        Args:
            id: 对象 ID

        Returns:
            是否删除成功
        """
        stmt = delete(self.model).where(self.model.id == id)
        result = await self.session.execute(stmt)
        return result.rowcount > 0

    async def count(self, **filters: Any) -> int:
        """
        统计对象数量

        Args:
            **filters: 过滤条件

        Returns:
            对象数量
        """
        from sqlalchemy import func

        stmt = select(func.count(self.model.id)).filter_by(**filters)
        result = await self.session.execute(stmt)
        return result.scalar() or 0

    async def exists(self, **filters: Any) -> bool:
        """
        检查对象是否存在

        Args:
            **filters: 过滤条件

        Returns:
            是否存在
        """
        return await self.count(**filters) > 0
