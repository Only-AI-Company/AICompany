"""
Employee Repository

Employee 数据访问层
"""
from typing import Optional
from uuid import UUID

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from src.models.employee import Employee, EmployeeStatus, EmployeeRole
from src.repositories.base import BaseRepository


class EmployeeRepository(BaseRepository[Employee]):
    """Employee Repository"""

    def __init__(self, session: AsyncSession):
        super().__init__(Employee, session)

    async def find_by_status(self, status: EmployeeStatus | str) -> list[Employee]:
        """根据状态查找"""
        stmt = select(Employee).where(
            Employee.status == (status.value if isinstance(status, EmployeeStatus) else status)
        )
        result = await self.session.execute(stmt)
        return list(result.scalars().all())

    async def find_by_role(self, role: str) -> list[Employee]:
        """根据角色查找"""
        stmt = select(Employee).where(Employee.role == role)
        result = await self.session.execute(stmt)
        return list(result.scalars().all())

    async def find_active_by_role(self, role: str) -> list[Employee]:
        """查找指定角色的活跃员工"""
        stmt = select(Employee).where(
            (Employee.role == role) &
            (Employee.status == EmployeeStatus.ACTIVE.value)
        )
        result = await self.session.execute(stmt)
        return list(result.scalars().all())

    async def find_by_role_and_skills(
        self,
        role: str,
        skills: list[str],
    ) -> Optional[Employee]:
        """根据角色和技能查找"""
        # 使用 JSON 包含查询
        stmt = select(Employee).where(
            (Employee.role == role) &
            (Employee.status == EmployeeStatus.ACTIVE.value)
        )
        result = await self.session.execute(stmt)
        employees = list(result.scalars().all())

        # 过滤有匹配技能的员工
        for emp in employees:
            if emp.capabilities:
                emp_skills = emp.capabilities if isinstance(emp.capabilities, list) else []
                if any(skill in emp_skills for skill in skills):
                    return emp

        return None


__all__ = ["EmployeeRepository"]
