"""
Task Repository

Task 数据访问层
"""
from typing import Optional
from uuid import UUID
from datetime import datetime

from sqlalchemy import select, and_, or_
from sqlalchemy.ext.asyncio import AsyncSession

from src.models.task import Task, TaskStatus, TaskPriority, TaskType
from src.repositories.base import BaseRepository


class TaskRepository(BaseRepository[Task]):
    """Task Repository"""

    def __init__(self, session: AsyncSession):
        super().__init__(Task, session)

    async def find_by_status(self, status: TaskStatus | str) -> list[Task]:
        """根据状态查找任务"""
        stmt = select(Task).where(
            Task.status == (status.value if isinstance(status, TaskStatus) else status)
        ).order_by(Task.created_at.desc())
        result = await self.session.execute(stmt)
        return list(result.scalars().all())

    async def find_by_owner(self, owner_id: UUID | str) -> list[Task]:
        """根据拥有者查找任务"""
        stmt = select(Task).where(Task.owner_id == str(owner_id)).order_by(
            Task.created_at.desc()
        )
        result = await self.session.execute(stmt)
        return list(result.scalars().all())

    async def find_by_type(self, task_type: TaskType | str) -> list[Task]:
        """根据类型查找任务"""
        stmt = select(Task).where(
            Task.type == (task_type.value if isinstance(task_type, TaskType) else task_type)
        ).order_by(Task.created_at.desc())
        result = await self.session.execute(stmt)
        return list(result.scalars().all())

    async def find_pending_tasks(self, limit: int = 50) -> list[Task]:
        """查找待处理的任务（按优先级排序）"""
        priority_order = {
            TaskPriority.URGENT.value: 0,
            TaskPriority.HIGH.value: 1,
            TaskPriority.MEDIUM.value: 2,
            TaskPriority.LOW.value: 3,
        }

        stmt = select(Task).where(
            Task.status.in_([
                TaskStatus.PENDING.value,
                TaskStatus.PENDING_OWNER.value,
            ])
        ).order_by(Task.created_at.asc())
        result = await self.session.execute(stmt)
        tasks = list(result.scalars().all())

        # 按优先级排序
        tasks.sort(key=lambda t: (priority_order.get(t.priority, 99), t.created_at))
        return tasks[:limit]

    async def find_active_tasks(self, owner_id: UUID | str | None = None) -> list[Task]:
        """查找进行中的任务"""
        stmt = select(Task).where(
            Task.status == TaskStatus.IN_PROGRESS.value
        )
        if owner_id:
            stmt = stmt.where(Task.owner_id == str(owner_id))
        stmt = stmt.order_by(Task.started_at.asc())
        result = await self.session.execute(stmt)
        return list(result.scalars().all())

    async def find_overdue_tasks(self) -> list[Task]:
        """查找逾期任务"""
        stmt = select(Task).where(
            and_(
                Task.due_date < datetime.now(),
                Task.status.notin_([
                    TaskStatus.COMPLETED.value,
                    TaskStatus.CANCELLED.value,
                ])
            )
        ).order_by(Task.due_date.asc())
        result = await self.session.execute(stmt)
        return list(result.scalars().all())

    async def update_status(
        self,
        task_id: UUID | str,
        status: TaskStatus | str,
    ) -> Optional[Task]:
        """更新任务状态"""
        status_value = status.value if isinstance(status, TaskStatus) else status
        return await self.update(task_id, status=status_value)

    async def assign_to(
        self,
        task_id: UUID | str,
        employee_id: UUID | str,
    ) -> Optional[Task]:
        """分配任务给员工"""
        return await self.update(
            task_id,
            assigned_to=str(employee_id),
            assigned_at=datetime.now(),
            status=TaskStatus.ASSIGNED.value,
        )


__all__ = ["TaskRepository"]
