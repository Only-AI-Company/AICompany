"""
Task Execution Repository

TaskExecution 数据访问层
"""
from typing import Optional
from uuid import UUID

from sqlalchemy import select, and_
from sqlalchemy.ext.asyncio import AsyncSession

from src.models.task import TaskExecution
from src.repositories.base import BaseRepository


class TaskExecutionRepository(BaseRepository[TaskExecution]):
    """TaskExecution Repository"""

    def __init__(self, session: AsyncSession):
        super().__init__(TaskExecution, session)

    async def find_by_task(self, task_id: UUID | str) -> list[TaskExecution]:
        """根据任务 ID 查找执行记录"""
        stmt = select(TaskExecution).where(
            TaskExecution.task_id == str(task_id)
        ).order_by(TaskExecution.started_at.desc())
        result = await self.session.execute(stmt)
        return list(result.scalars().all())

    async def find_by_employee(self, employee_id: UUID | str) -> list[TaskExecution]:
        """根据员工 ID 查找执行记录"""
        stmt = select(TaskExecution).where(
            TaskExecution.employee_id == str(employee_id)
        ).order_by(TaskExecution.started_at.desc())
        result = await self.session.execute(stmt)
        return list(result.scalars().all())

    async def find_recent(
        self,
        limit: int = 50,
        task_id: UUID | str | None = None,
        employee_id: UUID | str | None = None,
    ) -> list[TaskExecution]:
        """查找最近的执行记录"""
        stmt = select(TaskExecution)
        if task_id:
            stmt = stmt.where(TaskExecution.task_id == str(task_id))
        if employee_id:
            stmt = stmt.where(TaskExecution.employee_id == str(employee_id))
        stmt = stmt.order_by(TaskExecution.started_at.desc()).limit(limit)
        result = await self.session.execute(stmt)
        return list(result.scalars().all())

    async def get_latest_by_task(self, task_id: UUID | str) -> Optional[TaskExecution]:
        """获取任务最新的执行记录"""
        stmt = select(TaskExecution).where(
            TaskExecution.task_id == str(task_id)
        ).order_by(TaskExecution.started_at.desc()).limit(1)
        result = await self.session.execute(stmt)
        return result.scalar_one_or_none()


__all__ = ["TaskExecutionRepository"]
