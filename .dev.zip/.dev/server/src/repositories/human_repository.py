"""
Human Repository

Human 数据访问层
"""
from typing import Optional
from uuid import UUID

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from src.models.human import Human, HumanRole
from src.repositories.base import BaseRepository


class HumanRepository(BaseRepository[Human]):
    """Human Repository"""

    def __init__(self, session: AsyncSession):
        super().__init__(Human, session)

    async def find_by_name(self, name: str) -> Optional[Human]:
        """根据名称查找"""
        stmt = select(Human).where(Human.name == name)
        result = await self.session.execute(stmt)
        return result.scalar_one_or_none()

    async def find_by_role(self, role: HumanRole | str) -> list[Human]:
        """根据角色查找"""
        stmt = select(Human).where(Human.role == role.value if isinstance(role, HumanRole) else role)
        result = await self.session.execute(stmt)
        return list(result.scalars().all())

    async def find_or_create(
        self,
        name: str,
        role: HumanRole | str,
        skills: list[str] | None = None,
        system_prompt: str | None = None,
    ) -> Human:
        """查找或创建"""
        existing = await self.find_by_name(name)
        if existing:
            return existing

        human = Human(
            name=name,
            role=role.value if isinstance(role, HumanRole) else role,
            skills=skills or [],
            system_prompt=system_prompt,
        )
        self.session.add(human)
        await self.session.flush()
        await self.session.refresh(human)
        return human


__all__ = ["HumanRepository"]
