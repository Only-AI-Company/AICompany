"""
Task Service

Task 业务逻辑层
"""
from typing import Optional
from uuid import UUID

from sqlalchemy.ext.asyncio import AsyncSession

from src.models.task import Task, TaskStatus, TaskPriority
from src.repositories.task_repository import TaskRepository
from src.repositories.task_execution_repository import TaskExecutionRepository


class TaskService:
    """Task 业务逻辑服务"""

    def __init__(self, session: AsyncSession):
        self.session = session
        self.repository = TaskRepository(session)
        self.execution_repo = TaskExecutionRepository(session)

    async def get_task(self, task_id: UUID | str) -> Optional[Task]:
        """获取任务"""
        return await self.repository.get(task_id)

    async def get_pending_tasks(self, limit: int = 50) -> list[Task]:
        """获取待处理任务"""
        return await self.repository.find_pending_tasks(limit)

    async def get_active_tasks(self, owner_id: UUID | str | None = None) -> list[Task]:
        """获取进行中的任务"""
        return await self.repository.find_active_tasks(owner_id)

    async def get_overdue_tasks(self) -> list[Task]:
        """获取逾期任务"""
        return await self.repository.find_overdue_tasks()

    async def create_task(
        self,
        type: str,
        title: str,
        description: str,
        priority: TaskPriority | str = TaskPriority.MEDIUM,
        requested_by: str = "user",
        owner_id: UUID | str | None = None,
        due_date: Optional["datetime"] = None,
    ) -> Task:
        """创建新任务"""
        from datetime import datetime
        from uuid import uuid4

        task = Task(
            id=uuid4(),
            type=type,
            title=title,
            description=description,
            status=TaskStatus.PENDING.value,
            priority=priority.value if isinstance(priority, TaskPriority) else priority,
            requested_by=requested_by,
            owner_id=str(owner_id) if owner_id else None,
            due_date=due_date,
        )
        return await self.repository.create(task)

    async def assign_task(
        self,
        task_id: UUID | str,
        employee_id: UUID | str,
    ) -> Optional[Task]:
        """分配任务给员工"""
        return await self.repository.assign_to(task_id, employee_id)

    async def start_task(
        self,
        task_id: UUID | str,
    ) -> Optional[Task]:
        """开始任务"""
        from datetime import datetime
        return await self.repository.update(
            task_id,
            status=TaskStatus.IN_PROGRESS.value,
            started_at=datetime.now(),
        )

    async def complete_task(
        self,
        task_id: UUID | str,
        output_data: str | None = None,
    ) -> Optional[Task]:
        """完成任务"""
        from datetime import datetime
        return await self.repository.update(
            task_id,
            status=TaskStatus.COMPLETED.value,
            completed_at=datetime.now(),
            output_data=output_data,
        )

    async def fail_task(
        self,
        task_id: UUID | str,
        error_message: str,
    ) -> Optional[Task]:
        """标记任务失败"""
        from datetime import datetime
        return await self.repository.update(
            task_id,
            status=TaskStatus.FAILED.value,
            completed_at=datetime.now(),
            last_error=error_message,
        )

    async def get_task_executions(self, task_id: UUID | str) -> list:
        """获取任务的执行记录"""
        return await self.execution_repo.find_by_task(task_id)


__all__ = ["TaskService"]
