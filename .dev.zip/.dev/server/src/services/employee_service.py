"""
Employee Service

Employee 业务逻辑层
"""
from typing import Optional
from uuid import UUID

from sqlalchemy.ext.asyncio import AsyncSession

from src.models.employee import Employee, EmployeeStatus, EmployeeRole
from src.repositories.employee_repository import EmployeeRepository


class EmployeeService:
    """Employee 业务逻辑服务"""

    def __init__(self, session: AsyncSession):
        self.session = session
        self.repository = EmployeeRepository(session)

    async def get_employee(self, employee_id: UUID | str) -> Optional[Employee]:
        """获取员工"""
        return await self.repository.get(employee_id)

    async def get_active_employees(self) -> list[Employee]:
        """获取所有活跃员工"""
        return await self.repository.find_by_status(EmployeeStatus.ACTIVE)

    async def get_by_role(self, role: str) -> list[Employee]:
        """根据角色获取员工"""
        return await self.repository.find_by_role(role)

    async def get_ceo(self) -> Optional[Employee]:
        """获取 CEO"""
        ceos = await self.repository.find_active_by_role(EmployeeRole.CEO.value)
        return ceos[0] if ceos else None

    async def get_cto(self) -> Optional[Employee]:
        """获取 CTO"""
        ctos = await self.repository.find_active_by_role(EmployeeRole.CTO.value)
        return ctos[0] if ctos else None

    async def find_by_skill(
        self,
        skill: str,
        role: str | None = None,
    ) -> Optional[Employee]:
        """根据技能查找员工"""
        if role:
            return await self.repository.find_by_role_and_skills(role, [skill])

        # 搜索所有活跃员工
        active = await self.repository.find_by_status(EmployeeStatus.ACTIVE)
        for emp in active:
            if emp.capabilities:
                emp_skills = emp.capabilities.get("skills", [])
                if skill in emp_skills:
                    return emp
        return None

    async def update_status(
        self,
        employee_id: UUID | str,
        status: EmployeeStatus | str,
    ) -> Optional[Employee]:
        """更新员工状态"""
        status_value = status.value if isinstance(status, EmployeeStatus) else status
        return await self.repository.update(employee_id, status=status_value)

    async def update_last_active(self, employee_id: UUID | str) -> Optional[Employee]:
        """更新最后活跃时间"""
        from datetime import datetime
        return await self.repository.update(
            employee_id,
            last_active=datetime.now(),
        )

    async def increment_completed_tasks(self, employee_id: UUID | str) -> Optional[Employee]:
        """增加已完成任务计数"""
        emp = await self.repository.get(employee_id)
        if emp:
            new_count = (emp.completed_tasks or 0) + 1
            return await self.repository.update(employee_id, completed_tasks=new_count)
        return None


__all__ = ["EmployeeService"]
