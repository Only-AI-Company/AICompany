"""
Logging Configuration

配置结构化日志系统
"""
import logging
import sys
from typing import Any
from pythonjsonlogger import jsonlogger

from src.config import get_settings

settings = get_settings()


class CustomJsonFormatter(jsonlogger.JsonFormatter):
    """自定义 JSON 日志格式化器"""

    def add_fields(
        self,
        log_record: dict,
        record: logging.LogRecord,
        message_dict: dict,
    ) -> None:
        super().add_fields(log_record, record, message_dict)
        # 添加自定义字段
        log_record["service"] = settings.APP_NAME
        log_record["environment"] = settings.ENVIRONMENT
        log_record["version"] = settings.APP_VERSION


def setup_logging(service_name: str | None = None, log_level: str | None = None) -> None:
    """
    设置日志系统

    Args:
        service_name: 服务名称
        log_level: 日志级别
    """
    name = service_name or settings.APP_NAME
    level = log_level or settings.LOG_LEVEL

    # 创建处理器
    handler = logging.StreamHandler(sys.stdout)

    # 设置格式
    formatter = CustomJsonFormatter(
        "%(asctime)s %(name)s %(levelname)s %(message)s"
    )
    handler.setFormatter(formatter)

    # 配置根日志器
    root_logger = logging.getLogger()
    root_logger.setLevel(getattr(logging, level.upper()))
    root_logger.addHandler(handler)

    # 清除现有处理器，避免重复
    for existing_handler in root_logger.handlers[:]:
        if existing_handler != handler:
            root_logger.removeHandler(existing_handler)

    # 添加服务名称到所有日志记录
    old_factory = logging.getLogRecordFactory()

    def record_factory(*args: Any, **kwargs: Any) -> logging.LogRecord:
        record = old_factory(*args, **kwargs)
        record.service = name
        record.environment = settings.ENVIRONMENT
        return record

    logging.setLogRecordFactory(record_factory)


def get_logger(name: str) -> logging.Logger:
    """
    获取日志记录器

    Args:
        name: 日志记录器名称

    Returns:
        配置好的日志记录器
    """
    return logging.getLogger(name)


# 初始化日志系统
setup_logging()

# 导出默认日志记录器
logger = get_logger("ai-company")
