"""
Employee Agent Mapping Model

员工与 Claude Code Agent 的映射关系
"""
from typing import Optional
from enum import Enum

from sqlalchemy import String, Text, JSON, ForeignKey, Index
from sqlalchemy.orm import Mapped, mapped_column

from src.models.base import Base, TimestampMixin, TextIDMixin


class AgentScope(str, Enum):
    """Agent 作用域"""
    USER = "user"
    PROJECT = "project"


class AgentMappingStatus(str, Enum):
    """Agent 映射状态"""
    ACTIVE = "active"
    ARCHIVED = "archived"


class EmployeeAgent(Base, TextIDMixin, TimestampMixin):
    """
    员工与 Claude Code Agent 映射表

    记录哪个员工对应哪个 Claude Code Agent
    """

    __tablename__ = "employee_agents"

    # 关联
    employee_id: Mapped[str] = mapped_column(
        String(50),
        ForeignKey("employees.id", ondelete="CASCADE"),
        nullable=False,
        unique=True,
        index=True,
    )

    # Agent 信息
    agent_name: Mapped[str] = mapped_column(String(255), nullable=False)
    scope: Mapped[str] = mapped_column(String(50), nullable=False)  # user | project
    config_path: Mapped[Optional[str]] = mapped_column(String(500))
    status: Mapped[str] = mapped_column(
        String(50),
        default=AgentMappingStatus.ACTIVE.value,
        nullable=False,
        index=True,
    )

    # 元数据（JSON）
    meta: Mapped[dict | None] = mapped_column(JSON)

    __table_args__ = (
        Index("idx_employee_agents_employee", "employee_id"),
        Index("idx_employee_agents_status", "status"),
    )

    def __repr__(self) -> str:
        return f"<EmployeeAgent(id={self.id}, employee_id={self.employee_id}, agent_name={self.agent_name})>"


# 导出
__all__ = [
    "EmployeeAgent",
    "AgentScope",
    "AgentMappingStatus",
]
