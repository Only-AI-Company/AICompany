"""
Employee Models

定义员工（Agent）相关的数据模型

Employee 表存储公司员工属性，与 Human 表是 N:1 关系
多个 Employee 可以对应一个 Human（但现实中通常是 1:1）
"""
from datetime import datetime
from typing import Optional
from uuid import UUID
from enum import Enum

from sqlalchemy import String, Text, Integer, Float, JSON, ForeignKey, Index, DateTime
from sqlalchemy.orm import Mapped, mapped_column

from src.models.base import Base, TimestampMixin, TextIDMixin


class EmployeeStatus(str, Enum):
    """员工状态枚举"""
    ACTIVE = "active"
    BUSY = "busy"
    OFFLINE = "offline"
    UNAVAILABLE = "unavailable"
    ARCHIVED = "archived"


class EmployeeRole(str, Enum):
    """员工角色枚举"""
    # 管理层
    CEO = "ceo"
    CTO = "cto"
    CPO = "cpo"
    COO = "coo"
    CFO = "cfo"
    CMO = "cmo"

    # 内容创作
    NOVELIST = "novelist"
    WRITER = "writer"
    COPYWRITER = "copywriter"
    SCRIPTWRITER = "scriptwriter"

    # 社交媒体运营
    XIAOHONGSHU = "xiaohongshu"
    TWITTER = "twitter"

    # 技术开发
    ARCHITECT = "architect"
    DEVELOPER = "developer"
    REVIEWER = "reviewer"

    # 分析管理
    ANALYST = "analyst"
    PM = "pm"
    BRAINSTORMER = "brainstormer"
    DESIGNER = "designer"


class Employee(Base, TextIDMixin, TimestampMixin):
    """
    员工（Agent）模型

    代表一个 AI 员工，具有特定的角色和能力
    只存储公司相关属性，个人属性通过 human_id 关联
    """

    __tablename__ = "employees"

    # 基本信息
    name: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    role: Mapped[str] = mapped_column(String(100), nullable=False, index=True)
    nickname: Mapped[Optional[str]] = mapped_column(String(100))
    avatar: Mapped[Optional[str]] = mapped_column(String(500))

    # 状态
    status: Mapped[str] = mapped_column(
        String(50),
        default=EmployeeStatus.ACTIVE.value,
        nullable=False,
        index=True,
    )

    # AI 配置
    model: Mapped[str] = mapped_column(String(100), default="claude-sonnet-4-20250514", nullable=False)
    system_prompt: Mapped[Optional[str]] = mapped_column(Text)
    base_personality: Mapped[Optional[str]] = mapped_column(String(100))  # 预设人格名称
    temperature: Mapped[Optional[float]] = mapped_column(Float)

    # 背景故事（公司相关背景，如"52岁，20年企业管理经验"）
    backstory: Mapped[Optional[str]] = mapped_column(Text)

    # 统计数据
    completed_tasks: Mapped[int] = mapped_column(Integer, default=0)
    failed_tasks: Mapped[int] = mapped_column(Integer, default=0)
    average_quality: Mapped[Optional[float]] = mapped_column(Float)
    score: Mapped[int] = mapped_column(Integer, default=50)
    level: Mapped[int] = mapped_column(Integer, default=1)
    total_hours: Mapped[float] = mapped_column(Float, default=0.0)
    total_earnings: Mapped[float] = mapped_column(Float, default=0.0)

    # 关联
    human_id: Mapped[Optional[str]] = mapped_column(
        String(50),
        ForeignKey("humans.id"),
        nullable=True,
        index=True,
    )

    # 当前工作状态
    current_task: Mapped[Optional[str]] = mapped_column(String(100))  # TEXT 类型存储任务 ID
    current_mood: Mapped[Optional[str]] = mapped_column(String(50))

    # 时间相关
    hire_date: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))  # 入职时间
    birth_date: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))  # 出生日期（冗余）
    last_active: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, index=True)
    unavailable_until: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))

    # 工作相关 strengths 和 weaknesses（JSON 字符串数组）
    strengths: Mapped[Optional[str]] = mapped_column(Text)  # JSON: ["战略规划", "商业决策"]
    weaknesses: Mapped[Optional[str]] = mapped_column(Text)  # JSON: ["有时过于强势", "对细节容忍度低"]
    favorite_tasks: Mapped[Optional[str]] = mapped_column(Text)  # JSON: 喜欢的任务类型

    # 显示名称
    display_name: Mapped[Optional[str]] = mapped_column(String(255))

    # 能力配置（JSON）- 这是员工特有的，不是 Human 的属性
    capabilities: Mapped[dict | None] = mapped_column(JSON)  # 技能、工具等

    # 元数据（JSON）
    extra: Mapped[dict | None] = mapped_column(JSON)

    __table_args__ = (
        Index("idx_employees_status", "status"),
        Index("idx_employees_role", "role"),
        Index("idx_employees_last_active", "last_active"),
        Index("idx_employees_human_id", "human_id"),
    )

    def __repr__(self) -> str:
        return f"<Employee(id={self.id}, name={self.name}, role={self.role}, status={self.status})>"


# 导出
__all__ = [
    "Employee",
    "EmployeeStatus",
    "EmployeeRole",
]
