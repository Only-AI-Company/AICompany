"""
Audit Log Models

审计日志模型 - 追踪敏感操作
"""
from datetime import datetime
from typing import Optional
from uuid import UUID
from enum import Enum

from sqlalchemy import String, Text, Integer, JSON, DateTime, Uuid
from sqlalchemy.orm import Mapped, mapped_column

from src.models.base import Base, TimestampMixin, UUIDMixin


class AuditEventType(str, Enum):
    """审计事件类型"""
    # 用户管理
    USER_LOGIN = "user_login"
    USER_LOGOUT = "user_logout"
    USER_CREATED = "user_created"
    USER_UPDATED = "user_updated"
    USER_DELETED = "user_deleted"

    # 员工管理
    EMPLOYEE_CREATED = "employee_created"
    EMPLOYEE_UPDATED = "employee_updated"
    EMPLOYEE_DELETED = "employee_deleted"
    EMPLOYEE_ASSIGNED = "employee_assigned"
    EMPLOYEE_STATUS_CHANGED = "employee_status_changed"

    # 任务管理
    TASK_CREATED = "task_created"
    TASK_UPDATED = "task_updated"
    TASK_DELETED = "task_deleted"
    TASK_ASSIGNED = "task_assigned"
    TASK_STATUS_CHANGED = "task_status_changed"
    TASK_COMPLETED = "task_completed"
    TASK_FAILED = "task_failed"

    # 系统配置
    CONFIG_UPDATED = "config_updated"
    CONFIG_DELETED = "config_deleted"
    INTEGRATION_UPDATED = "integration_updated"
    INTEGRATION_ENABLED = "integration_enabled"
    INTEGRATION_DISABLED = "integration_disabled"

    # 安全相关
    SECURITY_KEY_ACCESS = "security_key_access"
    SECURITY_KEY_ROTATED = "security_key_rotated"
    UNAUTHORIZED_ACCESS = "unauthorized_access"

    # CEO 决策
    CEO_DECISION = "ceo_decision"
    CEO_APPROVAL = "ceo_approval"
    CEO_REJECTION = "ceo_rejection"


class AuditLog(Base, UUIDMixin, TimestampMixin):
    """
    审计日志表

    记录系统中的敏感操作，用于安全审计和问题追踪
    """

    __tablename__ = "audit_logs"

    # 事件信息
    event_type: Mapped[str] = mapped_column(
        String(50),
        nullable=False,
        index=True,
    )
    event_id: Mapped[Optional[str]] = mapped_column(
        String(100),
        index=True,
    )  # 事件的唯一标识（如 task ID）

    # 操作者
    actor: Mapped[str] = mapped_column(
        String(100),
        nullable=False,
        index=True,
    )  # user_id, system, employee_id
    actor_type: Mapped[str] = mapped_column(
        String(50),
        nullable=False,
    )  # user, system, employee

    # 操作目标
    resource_type: Mapped[Optional[str]] = mapped_column(
        String(50),
        index=True,
    )  # task, employee, config, etc.
    resource_id: Mapped[Optional[str]] = mapped_column(
        String(100),
        index=True,
    )

    # 操作结果
    action: Mapped[Optional[str]] = mapped_column(String(100))
    result: Mapped[str] = mapped_column(
        String(50),
        nullable=False,
    )  # success, failure, partial
    result_message: Mapped[Optional[str]] = mapped_column(Text)

    # 详细信息
    details: Mapped[dict | None] = mapped_column(JSON)

    # IP 地址和 User Agent（用于安全审计）
    ip_address: Mapped[Optional[str]] = mapped_column(String(45))  # IPv6 support
    user_agent: Mapped[Optional[str]] = mapped_column(Text)

    # 关联会话
    session_id: Mapped[Optional[str]] = mapped_column(String(100))

    # 时间戳（事件发生时间，可能与 created_at 不同）
    event_timestamp: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        index=True,
    )

    def __repr__(self) -> str:
        return f"<AuditLog(id={self.id}, event_type={self.event_type}, actor={self.actor}, result={self.result})>"
