"""
Integration Models

第三方集成配置模型（独立管理 API keys 等敏感信息）
"""
from datetime import datetime
from typing import Optional
from uuid import UUID
from enum import Enum

from sqlalchemy import String, Text, Integer, JSON, Boolean, DateTime
from sqlalchemy.orm import Mapped, mapped_column

from src.models.base import Base, TimestampMixin, UUIDMixin


class IntegrationType(str, Enum):
    """集成类型枚举"""
    # AI Providers
    ANTHROPIC = "anthropic"
    QWEN = "qwen"
    DEEPSEEK = "deepseek"
    KIMI = "kimi"
    MINIMAX = "minimax"
    ZAI = "zai"
    OPENAI = "openai"

    # 社交媒体
    TELEGRAM = "telegram"
    TWITTER = "twitter"
    XIAOHONGSHU = "xiaohongshu"
    WECHAT = "wechat"

    # 开发工具
    GITHUB = "github"
    GITLAB = "gitlab"
    JIRA = "jira"


class Integration(Base, UUIDMixin, TimestampMixin):
    """
    第三方集成配置

    独立管理各种外部系统的 API keys 和配置
    支持加密存储敏感信息
    """

    __tablename__ = "integrations"

    # 基本信息
    type: Mapped[str] = mapped_column(
        String(50),
        nullable=False,
        index=True,
    )
    name: Mapped[str] = mapped_column(
        String(100),
        nullable=False,
    )
    description: Mapped[Optional[str]] = mapped_column(Text)

    # 配置 (加密存储)
    # 实际的 API key、token 等敏感信息
    config_secret: Mapped[Optional[str]] = mapped_column(Text)  # 加密存储

    # 公开配置 (不加密)
    config_public: Mapped[dict] = mapped_column(JSON, nullable=False, default=dict)
    # 例如: endpoint_url, timeout, retry_count 等

    # 状态
    enabled: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    verified: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)

    # 优先级 (用于选择默认 provider)
    priority: Mapped[int] = mapped_column(Integer, default=0, nullable=False)

    # 使用统计
    last_used_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    total_calls: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    failed_calls: Mapped[int] = mapped_column(Integer, default=0, nullable=False)

    # 元数据
    extra: Mapped[dict | None] = mapped_column(JSON)

    def __repr__(self) -> str:
        return f"<Integration(id={self.id}, type={self.type}, name={self.name}, enabled={self.enabled})>"


class IntegrationConfig(Base, UUIDMixin, TimestampMixin):
    """
    集成配置历史版本

    记录配置变更历史，支持回滚
    """

    __tablename__ = "integration_config_history"

    integration_id: Mapped[UUID] = mapped_column(
        String(36),
        nullable=False,
        index=True,
    )

    # 配置变更
    old_config_public: Mapped[dict] = mapped_column(JSON, nullable=False)
    new_config_public: Mapped[dict] = mapped_column(JSON, nullable=False)

    # 变更信息
    changed_by: Mapped[Optional[str]] = mapped_column(String(100))  # user 或 system
    change_reason: Mapped[Optional[str]] = mapped_column(Text)

    # 版本
    version: Mapped[int] = mapped_column(Integer, nullable=False)

    def __repr__(self) -> str:
        return f"<IntegrationConfig(id={self.id}, integration_id={self.integration_id}, version={self.version})>"
