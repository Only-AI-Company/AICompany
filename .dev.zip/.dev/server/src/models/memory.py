"""
Memory Models

定义员工记忆相关的数据模型
"""
from typing import Optional
from datetime import datetime
from uuid import UUID
from enum import Enum

from sqlalchemy import String, Text, Integer, Float, JSON, Uuid, ForeignKey, Index, DateTime
from sqlalchemy.orm import Mapped, mapped_column

from src.models.base import Base


class MemoryType(str, Enum):
    """记忆类型枚举"""
    EPISODIC = "episodic"   # 情景记忆 - 具体事件
    SEMANTIC = "semantic"   # 语义记忆 - 通用知识
    PROCEDURAL = "procedural"  # 程序记忆 - 技能和方法


class Memory(Base):
    """
    员工记忆模型

    记录员工的记忆，用于上下文保留和学习
    """

    __tablename__ = "memories"

    # 主键（自增整数）
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)

    # 关联
    employee_id: Mapped[str] = mapped_column(  # TEXT 类型存储 UUID
        String(50),
        ForeignKey("employees.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    task_id: Mapped[Optional[str]] = mapped_column(  # TEXT 类型存储 UUID
        String(50),
        ForeignKey("tasks.id", ondelete="SET NULL"),
        nullable=True,
        index=True,
    )

    # 记忆内容
    type: Mapped[str] = mapped_column(String(50), nullable=False)  # episodic, semantic, procedural
    content: Mapped[str] = mapped_column(Text, nullable=False)

    # 时间戳（DateTime，带时区）
    timestamp: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, index=True)

    # 重要性
    importance: Mapped[float] = mapped_column(Float, default=0.5, index=True)

    # 访问统计
    access_count: Mapped[int] = mapped_column(Integer, default=0)

    # 向量嵌入（用于语义搜索）
    embedding: Mapped[Optional[str]] = mapped_column(Text)

    __table_args__ = (
        Index("idx_memories_employee_type", "employee_id", "type"),
        Index("idx_memories_task", "task_id"),
        Index("idx_memories_importance", "importance"),
    )

    def __repr__(self) -> str:
        return f"<Memory(id={self.id}, employee_id={self.employee_id}, type={self.type})>"


# 导出
__all__ = [
    "Memory",
    "MemoryType",
]
