"""
Base Models and Database Configuration

定义 SQLAlchemy 基类和数据库会话管理
"""
from datetime import datetime
from typing import AsyncGenerator
from uuid import UUID, uuid4

from sqlalchemy import String, DateTime, func
from sqlalchemy.ext.asyncio import (
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)
from sqlalchemy.orm import DeclarativeBase, Mapped, declared_attr, mapped_column

from src.config import get_settings

settings = get_settings()

# 延迟初始化的全局变量
_engine = None
_async_session_maker = None


def get_engine():
    """获取或创建数据库引擎"""
    global _engine, _async_session_maker
    if _engine is None:
        _engine = create_async_engine(
            settings.DATABASE_URL,
            echo=settings.DEBUG,
            pool_pre_ping=True,
        )
        _async_session_maker = async_sessionmaker(
            _engine,
            class_=AsyncSession,
            expire_on_commit=False,
        )
    return _engine


def get_async_session_maker():
    """获取会话工厂"""
    global _async_session_maker
    if _async_session_maker is None:
        get_engine()
    return _async_session_maker


# 导出函数（兼容旧代码）
def _get_engine_sync():
    """同步获取引擎（用于兼容）"""
    return get_engine()


# 将函数作为模块属性导出
engine = property(lambda self: get_engine())
async_session_maker = property(lambda self: get_async_session_maker())


class Base(DeclarativeBase):
    """所有模型的基类"""

    @declared_attr.directive
    def __tablename__(cls) -> str:
        """自动生成表名（类名转小写 + 下划线）"""
        name = cls.__name__
        # 将 CamelCase 转换为 snake_case
        result = [name[0].lower()]
        for char in name[1:]:
            if char.isupper():
                result.extend(["_", char.lower()])
            else:
                result.append(char)
        return "".join(result) + "s"  # 复数形式


class TimestampMixin:
    """时间戳混入类"""

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        nullable=False,
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False,
    )


class UUIDMixin:
    """UUID 主键混入类"""

    id: Mapped[UUID] = mapped_column(
        primary_key=True,
        default=uuid4,
    )


class TextIDMixin:
    """TEXT 主键混入类（与 TS 版本兼容）"""

    id: Mapped[str] = mapped_column(
        String(50),
        primary_key=True,
    )


async def get_db() -> AsyncGenerator[AsyncSession, None]:
    """获取数据库会话（依赖注入）"""
    session_maker = get_async_session_maker()
    async with session_maker() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()


async def init_db() -> None:
    """初始化数据库（创建所有表）"""
    eng = get_engine()
    async with eng.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)


async def close_db() -> None:
    """关闭数据库连接"""
    eng = get_engine()
    await eng.dispose()
