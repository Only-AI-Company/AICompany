"""
Task Models

定义任务相关的数据模型
"""
from typing import Optional
from datetime import datetime
from uuid import UUID
from enum import Enum

from sqlalchemy import String, Text, Integer, Float, JSON, Uuid, ForeignKey, Index, DateTime
from sqlalchemy.orm import Mapped, mapped_column

from src.models.base import Base, TimestampMixin, TextIDMixin


class TaskStatus(str, Enum):
    """任务状态枚举"""
    PENDING_OWNER = "pending_owner"  # 等待认领
    PENDING = "pending"              # 待处理
    ASSIGNED = "assigned"            # 已分配
    IN_PROGRESS = "in_progress"      # 进行中
    PLANNING = "planning"            # 规划中
    DISPATCHED = "dispatched"        # 已分发
    EXECUTING = "executing"          # 执行中
    WAIT_HUMAN = "wait_human"        # 等待人工
    AUDITING = "auditing"            # 审核中
    COMPLETED = "completed"          # 已完成
    FAILED = "failed"                # 失败
    CANCELLED = "cancelled"          # 已取消


class TaskPriority(str, Enum):
    """任务优先级枚举"""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    URGENT = "urgent"


class TaskRequestedBy(str, Enum):
    """任务来源"""
    USER = "user"
    EMPLOYEE = "employee"


class TaskType(str, Enum):
    """任务类型枚举"""
    GENERAL = "general"
    DEVELOPMENT = "development"
    WRITING = "writing"
    SOCIAL_MEDIA = "social_media"
    ANALYSIS = "analysis"
    AUTOMATION = "automation"
    CODE_REVIEW = "code_review"
    BUG_FIX = "bug_fix"


class Task(Base, TextIDMixin, TimestampMixin):
    """
    任务模型

    代表一个需要执行的任务
    """

    __tablename__ = "tasks"

    # 基本信息
    type: Mapped[str] = mapped_column(String(100), nullable=False)
    title: Mapped[str] = mapped_column(String(500), nullable=False)
    description: Mapped[str] = mapped_column(Text, nullable=False)

    # 状态与优先级
    status: Mapped[str] = mapped_column(String(50), nullable=False, index=True)
    priority: Mapped[str] = mapped_column(String(50), nullable=False)

    # 物理环境
    work_dir: Mapped[Optional[str]] = mapped_column(String(500), index=True)
    plan_file_path: Mapped[Optional[str]] = mapped_column(String(500))
    branch_name: Mapped[Optional[str]] = mapped_column(String(255))
    session_id: Mapped[Optional[str]] = mapped_column(String(255), index=True)

    # 分配信息
    requested_by: Mapped[str] = mapped_column(String(100), nullable=False)  # user | employee_id
    owner_id: Mapped[Optional[UUID]] = mapped_column(
        Uuid,
        ForeignKey("employees.id"),
        nullable=True,
        index=True,
    )
    assigned_to: Mapped[Optional[UUID]] = mapped_column(
        Uuid,
        ForeignKey("employees.id"),
        nullable=True,
        index=True,
    )
    assigned_at: Mapped[Optional["datetime"]] = mapped_column(DateTime(timezone=True))

    # 层级关系
    parent_task_id: Mapped[Optional[UUID]] = mapped_column(
        Uuid,
        ForeignKey("tasks.id"),
        nullable=True,
        index=True,
    )

    # 时间信息（DateTime，带时区）
    started_at: Mapped[Optional["datetime"]] = mapped_column(DateTime(timezone=True))
    completed_at: Mapped[Optional["datetime"]] = mapped_column(DateTime(timezone=True))
    estimated_duration: Mapped[Optional[int]] = mapped_column(Integer)  # 秒（持续时间）
    due_date: Mapped[Optional["datetime"]] = mapped_column(DateTime(timezone=True))

    # 数据（JSON 存储 TEXT）
    input_data: Mapped[Optional[str]] = mapped_column(Text)  # JSON
    output_data: Mapped[Optional[str]] = mapped_column(Text)  # JSON
    context: Mapped[Optional[str]] = mapped_column(Text)  # JSON
    context_checkpoint_id: Mapped[Optional[str]] = mapped_column(String(255))

    # 产出物
    artifacts: Mapped[Optional[str]] = mapped_column(Text)  # JSON
    result_signal: Mapped[Optional[str]] = mapped_column(String(255))

    # 反馈与验收
    acceptance_criteria: Mapped[Optional[str]] = mapped_column(Text)
    owner_feedback: Mapped[Optional[str]] = mapped_column(Text)

    # 错误
    last_error: Mapped[Optional[str]] = mapped_column(Text)

    # 指标
    token_usage: Mapped[Optional[int]] = mapped_column(Integer)
    quality: Mapped[Optional[int]] = mapped_column(Integer)

    __table_args__ = (
        Index("idx_tasks_status", "status"),
        Index("idx_tasks_work_dir", "work_dir"),
        Index("idx_tasks_assigned_to", "assigned_to"),
        Index("idx_tasks_owner_id", "owner_id"),
        Index("idx_tasks_parent", "parent_task_id"),
        Index("idx_tasks_session_id", "session_id"),
    )

    def __repr__(self) -> str:
        return f"<Task(id={self.id}, type={self.type}, title={self.title}, status={self.status})>"


class TaskEmployee(Base):
    """
    任务-员工多对多关系表

    记录哪些员工参与了哪些任务
    """

    __tablename__ = "task_employees"

    task_id: Mapped[UUID] = mapped_column(
        Uuid,
        ForeignKey("tasks.id", ondelete="CASCADE"),
        nullable=False,
        primary_key=True,
    )
    employee_id: Mapped[UUID] = mapped_column(
        Uuid,
        ForeignKey("employees.id", ondelete="CASCADE"),
        nullable=False,
        primary_key=True,
    )
    assigned_part: Mapped[Optional[str]] = mapped_column(Text)  # 在任务中的分工
    assigned_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)

    __table_args__ = (
        Index("idx_task_employees_task", "task_id"),
        Index("idx_task_employees_employee", "employee_id"),
    )

    def __repr__(self) -> str:
        return f"<TaskEmployee(task_id={self.task_id}, employee_id={self.employee_id})>"


class TaskExecution(Base, TextIDMixin):
    """
    任务执行记录

    记录每次任务执行的详细信息
    """

    __tablename__ = "task_executions"

    task_id: Mapped[UUID] = mapped_column(
        Uuid,
        ForeignKey("tasks.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )

    employee_id: Mapped[UUID] = mapped_column(
        Uuid,
        ForeignKey("employees.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )

    # Agent 信息
    agent_name: Mapped[Optional[str]] = mapped_column(String(255))

    # 执行状态
    status: Mapped[str] = mapped_column(String(50), nullable=False)
    success: Mapped[bool] = mapped_column(nullable=False)
    exit_code: Mapped[Optional[int]] = mapped_column(Integer)

    # 时间信息（DateTime，带时区）
    started_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, index=True)
    completed_at: Mapped[Optional["datetime"]] = mapped_column(DateTime(timezone=True))
    duration: Mapped[Optional[int]] = mapped_column(Integer)  # 毫秒（持续时间）

    # 输入输出
    input_prompt: Mapped[str] = mapped_column(Text, nullable=False)
    input_context: Mapped[Optional[str]] = mapped_column(Text)
    output_raw: Mapped[str] = mapped_column(Text, nullable=False)
    output_parsed: Mapped[Optional[str]] = mapped_column(Text)

    # 资源
    tokens_used: Mapped[Optional[int]] = mapped_column(Integer)
    model_used: Mapped[Optional[str]] = mapped_column(String(100))

    # 质量
    quality: Mapped[Optional[int]] = mapped_column(Integer)

    __table_args__ = (
        Index("idx_executions_task", "task_id"),
        Index("idx_executions_employee", "employee_id"),
        Index("idx_executions_started", "started_at"),
    )

    def __repr__(self) -> str:
        return f"<TaskExecution(id={self.id}, task_id={self.task_id}, status={self.status})>"


# 导出
__all__ = [
    "Task",
    "TaskEmployee",
    "TaskExecution",
    "TaskStatus",
    "TaskPriority",
    "TaskRequestedBy",
    "TaskType",
]
