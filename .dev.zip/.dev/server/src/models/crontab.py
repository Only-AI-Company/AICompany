"""
Crontab Models

定义定时任务相关的数据模型
"""
from typing import Optional
from datetime import datetime
from uuid import UUID
from enum import Enum

from sqlalchemy import String, Text, Integer, Boolean, JSON, Uuid, ForeignKey, Index, DateTime
from sqlalchemy.orm import Mapped, mapped_column

from src.models.base import Base, TextIDMixin, TimestampMixin


class CronStatus(str, Enum):
    """定时任务状态"""
    ENABLED = "enabled"
    DISABLED = "disabled"
    PAUSED = "paused"


class Crontab(Base, TextIDMixin, TimestampMixin):
    """
    定时任务模型

    记录需要周期性执行的任务
    """

    __tablename__ = "crontab"

    # 基本信息
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text)

    # 关联任务
    task_id: Mapped[Optional[UUID]] = mapped_column(
        Uuid,
        ForeignKey("tasks.id", ondelete="SET NULL"),
        nullable=True,
        index=True,
    )

    # 执行命令
    command: Mapped[str] = mapped_column(Text, nullable=False)
    args: Mapped[Optional[dict]] = mapped_column(JSON)  # 参数

    # 定时规则
    cron_rule: Mapped[Optional[str]] = mapped_column(String(100), index=True)

    # 状态
    enabled: Mapped[bool] = mapped_column(Boolean, default=True, index=True)

    # 调度信息（DateTime，带时区）
    next_run: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), index=True)
    last_run: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    last_running_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))

    # 统计
    run_count: Mapped[int] = mapped_column(Integer, default=0)
    fail_count: Mapped[int] = mapped_column(Integer, default=0)

    # 执行结果
    last_output: Mapped[Optional[str]] = mapped_column(Text)
    last_error: Mapped[Optional[str]] = mapped_column(Text)

    # 配置
    timeout: Mapped[int] = mapped_column(Integer, default=300)  # 秒
    working_dir: Mapped[Optional[str]] = mapped_column(String(500))
    env: Mapped[Optional[dict]] = mapped_column(JSON)

    __table_args__ = (
        Index("idx_crontab_enabled", "enabled"),
        Index("idx_crontab_next_run", "next_run"),
        Index("idx_crontab_name", "name"),
        Index("idx_crontab_task_id", "task_id"),
        Index("idx_crontab_cron_rule", "cron_rule"),
    )

    def __repr__(self) -> str:
        return f"<Crontab(id={self.id}, name={self.name}, enabled={self.enabled})>"


class CronExecution(Base, TextIDMixin):
    """
    定时任务执行记录

    记录每次定时任务执行的详细信息
    """

    __tablename__ = "cron_executions"

    # 关联
    cron_id: Mapped[str] = mapped_column(
        String(50),  # crontab 使用 TEXT 主键
        nullable=False,
        index=True,
    )

    # 执行时间（DateTime，带时区）
    started_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, index=True)
    completed_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))

    # 结果
    exit_code: Mapped[Optional[int]] = mapped_column(Integer)
    signal: Mapped[Optional[int]] = mapped_column(Integer)

    # 输出
    output: Mapped[Optional[str]] = mapped_column(Text)
    error: Mapped[Optional[str]] = mapped_column(Text)

    # 超时
    timeout: Mapped[int] = mapped_column(Integer, default=0)

    __table_args__ = (
        Index("idx_cron_executions_cron", "cron_id"),
        Index("idx_cron_executions_started", "started_at"),
    )

    def __repr__(self) -> str:
        return f"<CronExecution(id={self.id}, cron_id={self.cron_id}, exit_code={self.exit_code})>"


# 导出
__all__ = [
    "Crontab",
    "CronExecution",
    "CronStatus",
]
