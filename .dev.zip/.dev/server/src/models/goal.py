"""
Goal Models

定义目标相关的数据模型
"""
from typing import Optional
from datetime import datetime
from uuid import UUID
from enum import Enum

from sqlalchemy import String, Text, Integer, JSON, Uuid, ForeignKey, Index, DateTime
from sqlalchemy.orm import Mapped, mapped_column

from src.models.base import Base, TextIDMixin, TimestampMixin


class GoalStatus(str, Enum):
    """目标状态枚举"""
    PENDING_OWNER = "pending_owner"  # 等待认领
    PLANNING = "planning"            # 规划中
    IN_PROGRESS = "in_progress"      # 进行中
    COMPLETED = "completed"          # 已完成
    REJECTED = "rejected"            # 已拒绝


class GoalPlanStatus(str, Enum):
    """目标计划状态枚举"""
    PENDING_OWNER = "pending_owner"  # 等待认领
    APPROVED = "approved"            # 已批准
    REJECTED = "rejected"            # 已拒绝


class Goal(Base, TextIDMixin, TimestampMixin):
    """
    目标模型

    代表一个长期目标，可以包含多个任务
    """

    __tablename__ = "goals"

    # 基本信息
    type: Mapped[str] = mapped_column(String(100), nullable=False)
    title: Mapped[str] = mapped_column(String(500), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text)

    # 状态
    status: Mapped[str] = mapped_column(String(50), nullable=False, index=True)

    # 分配
    owner_id: Mapped[Optional[UUID]] = mapped_column(
        Uuid,
        ForeignKey("employees.id"),
        nullable=True,
        index=True,
    )

    # 层级关系
    parent_goal_id: Mapped[Optional[UUID]] = mapped_column(
        Uuid,
        ForeignKey("goals.id"),
        nullable=True,
        index=True,
    )

    # 时间（DateTime，带时区）
    due_date: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))

    # 反馈与验收
    acceptance_criteria: Mapped[Optional[str]] = mapped_column(Text)
    owner_feedback: Mapped[Optional[str]] = mapped_column(Text)

    __table_args__ = (
        Index("idx_goals_status", "status"),
        Index("idx_goals_owner", "owner_id"),
        Index("idx_goals_parent", "parent_goal_id"),
    )

    def __repr__(self) -> str:
        return f"<Goal(id={self.id}, type={self.type}, title={self.title}, status={self.status})>"


class GoalPlan(Base, TextIDMixin, TimestampMixin):
    """
    目标计划模型

    记录目标的实现计划
    """

    __tablename__ = "goal_plans"

    # 关联
    goal_id: Mapped[UUID] = mapped_column(
        Uuid,
        ForeignKey("goals.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )

    # 版本
    version: Mapped[int] = mapped_column(Integer, nullable=False)

    # 计划内容
    content: Mapped[str] = mapped_column(Text, nullable=False)

    # 状态
    status: Mapped[str] = mapped_column(String(50), nullable=False, index=True)

    # 反馈
    owner_feedback: Mapped[Optional[str]] = mapped_column(Text)

    __table_args__ = (
        Index("idx_goal_plans_goal", "goal_id"),
        Index("idx_goal_plans_status", "status"),
    )

    def __repr__(self) -> str:
        return f"<GoalPlan(id={self.id}, goal_id={self.goal_id}, version={self.version}, status={self.status})>"


# 导出
__all__ = [
    "Goal",
    "GoalPlan",
    "GoalStatus",
    "GoalPlanStatus",
]
