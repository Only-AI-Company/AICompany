"""
Human Models

定义人类配置相关的数据模型

Human 表存储人类档案的属性，与 Employee 表是 1:N 关系
一个 Human 可以对应多个 Employee（不同公司、不同职位）
"""
from datetime import datetime
from typing import Optional
from uuid import UUID
from enum import Enum

from sqlalchemy import String, Text, Integer, JSON
from sqlalchemy.orm import Mapped, mapped_column

from src.models.base import Base, TimestampMixin, TextIDMixin


class Human(Base, TextIDMixin, TimestampMixin):
    """
    人类档案模型

    定义作为 Agent 基础的人类属性，包括外貌、性格、技能等
    这些是"个人属性"，不是"公司属性"
    """

    __tablename__ = "humans"

    # 基本信息
    name: Mapped[str] = mapped_column(String(255), nullable=False, unique=True, index=True)
    gender: Mapped[Optional[str]] = mapped_column(String(50))  # male, female, other
    location: Mapped[Optional[str]] = mapped_column(String(255))  # 地理位置
    birthday: Mapped[Optional[str]] = mapped_column(String(50))  # 出生日期 YYYY-MM-DD
    age: Mapped[Optional[int]] = mapped_column(Integer)  # 年龄（计算字段）

    # 外貌描述
    appearance: Mapped[Optional[str]] = mapped_column(Text)  # 外貌描述

    # 性格特征（JSON 数组）
    personality_traits: Mapped[list[str]] = mapped_column(JSON, nullable=False, default=list)

    # 兴趣爱好（JSON 数组）
    hobbies: Mapped[list[str]] = mapped_column(JSON, nullable=False, default=list)

    # 工作偏好（JSON 对象）
    work_preferences: Mapped[dict | None] = mapped_column(JSON)

    # 技能列表（JSON 数组）
    skills: Mapped[list[str]] = mapped_column(JSON, nullable=False, default=list)

    # 弱点（JSON 数组）- 个人性格弱点
    weaknesses: Mapped[list[str]] = mapped_column(JSON, nullable=False, default=list)

    # 备注（详细背景介绍）
    notes: Mapped[Optional[str]] = mapped_column(Text)

    def __repr__(self) -> str:
        return f"<Human(id={self.id}, name={self.name}, gender={self.gender})>"


# 导出
__all__ = [
    "Human",
]
