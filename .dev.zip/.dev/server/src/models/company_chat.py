"""
Company Chat Models

用户与公司（任意员工）的聊天记录
"""
from typing import Optional
from datetime import datetime
from uuid import UUID
from enum import Enum

from sqlalchemy import String, Text, JSON, Uuid, ForeignKey, Index, Integer, DateTime
from sqlalchemy.orm import Mapped, mapped_column

from src.models.base import Base, TimestampMixin, TextIDMixin


class ChatSource(str, Enum):
    """聊天来源"""
    TELEGRAM = "telegram"
    CLI = "cli"
    WEB = "web"
    API = "api"
    OTHER = "other"


class ChatDirection(str, Enum):
    """聊天方向"""
    INBOUND = "inbound"   # 用户 → 公司
    OUTBOUND = "outbound" # 公司 → 用户


class ChatRole(str, Enum):
    """聊天角色"""
    USER = "user"
    EMPLOYEE = "employee"


class CompanyChat(Base):
    """
    公司聊天记录表

    记录用户与公司（任意员工）的对话
    """

    __tablename__ = "company_chats"

    # 主键（自增整数）
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)

    # 会话信息
    session_id: Mapped[str] = mapped_column(String(255), nullable=False, index=True)

    # 员工信息（可为空，表示公司整体）
    employee_id: Mapped[Optional[UUID]] = mapped_column(
        Uuid,
        ForeignKey("employees.id", ondelete="SET NULL"),
        nullable=True,
        index=True,
    )
    employee_name: Mapped[Optional[str]] = mapped_column(String(255))  # 冗余，方便查询

    # 消息内容
    role: Mapped[str] = mapped_column(String(50), nullable=False)  # user | employee
    content: Mapped[str] = mapped_column(Text, nullable=False)

    # 来源信息
    source: Mapped[str] = mapped_column(String(50), nullable=False, index=True)  # telegram, cli, web, api
    direction: Mapped[str] = mapped_column(String(50), nullable=False)  # inbound | outbound
    message_type: Mapped[Optional[str]] = mapped_column(String(100))

    # 外部平台关联（Telegram 等）
    external_message_id: Mapped[Optional[str]] = mapped_column(String(255), index=True)
    external_chat_id: Mapped[Optional[str]] = mapped_column(String(255), index=True)
    external_user_id: Mapped[Optional[str]] = mapped_column(String(255))
    username: Mapped[Optional[str]] = mapped_column(String(255))
    first_name: Mapped[Optional[str]] = mapped_column(String(100))
    last_name: Mapped[Optional[str]] = mapped_column(String(100))

    # 时间戳（DateTime，带时区）
    timestamp: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, index=True)

    # 额外数据（JSON）
    payload: Mapped[dict | None] = mapped_column(JSON)
    meta: Mapped[dict | None] = mapped_column(JSON)

    __table_args__ = (
        Index("idx_company_chats_session", "session_id"),
        Index("idx_company_chats_employee", "employee_id"),
        Index("idx_company_chats_source", "source"),
        Index("idx_company_chats_timestamp", "timestamp"),
        Index("idx_company_chats_external_msg", "external_message_id"),
        Index("idx_company_chats_external_chat", "external_chat_id"),
    )

    def __repr__(self) -> str:
        return f"<CompanyChat(id={self.id}, session_id={self.session_id}, role={self.role})>"


# 导出
__all__ = [
    "CompanyChat",
    "ChatSource",
    "ChatDirection",
    "ChatRole",
]
