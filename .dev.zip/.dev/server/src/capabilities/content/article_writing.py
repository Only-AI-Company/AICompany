"""
Article Writing Capability

文章写作能力 - 示例实现
"""
import asyncio
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Optional

from src.core.engine.capability import (
    BaseCapability,
    CapabilityInput,
    CapabilityOutput,
    CapabilityType,
    ExecutionContext,
    ExecutionEstimate,
    ValidationResult,
)


@dataclass
class ArticleWritingInput(CapabilityInput):
    """文章写作输入"""
    title: str
    topic: str
    style: str = "professional"  # professional, casual, academic, etc.
    word_count: int = 1000
    keywords: list[str] | None = None
    tone: str = "informative"
    target_audience: str = "general"


@dataclass
class ArticleWritingOutput(CapabilityOutput):
    """文章写作输出"""
    article_content: str  # 生成的文章内容
    word_count: int  # 实际字数
    file_path: str  # 保存的 file_path
    reading_time_minutes: int  # 预估阅读时间


class ArticleWritingCapability(BaseCapability):
    """
    文章写作能力

    能根据主题、风格、目标受众等参数生成高质量文章
    """

    capability_type = CapabilityType.ARTICLE_WRITING
    name = "article_writing"
    description = "根据要求生成高质量文章"

    def __init__(self, llm_provider=None):
        self.llm_provider = llm_provider

    async def validate(self, input: ArticleWritingInput) -> ValidationResult:
        """验证输入"""
        errors = []

        if not input.title or len(input.title.strip()) == 0:
            errors.append("标题不能为空")

        if not input.topic or len(input.topic.strip()) == 0:
            errors.append("主题不能为空")

        if input.word_count < 100:
            errors.append("字数不能少于 100")

        if input.word_count > 50000:
            errors.append("字数不能超过 50000")

        return ValidationResult(
            valid=len(errors) == 0,
            errors=errors if errors else None,
        )

    async def estimate(self, input: ArticleWritingInput) -> ExecutionEstimate:
        """预估执行时间"""
        # 根据字数预估时间
        words_per_minute = 500  # 每分钟 500 字
        estimated_minutes = max(1, input.word_count // words_per_minute)

        return ExecutionEstimate(
            can_execute=True,
            estimated_duration_minutes=estimated_minutes,
            required_resources=["llm_provider"],
            risk_level="low",
        )

    async def before_execute(
        self,
        input: ArticleWritingInput,
        context: ExecutionContext
    ) -> None:
        """执行前准备"""
        context.logger.info(f"开始写作文章: {input.title}")
        context.logger.info(f"目标字数: {input.word_count}")
        context.logger.info(f"工作空间: {context.workspace_path}")

        # 确保输出目录存在
        output_dir = Path(context.workspace_path) / "articles"
        output_dir.mkdir(parents=True, exist_ok=True)
        context.logger.info(f"创建输出目录: {output_dir}")

    async def execute(
        self,
        input: ArticleWritingInput,
        context: ExecutionContext
    ) -> CapabilityOutput:
        """执行文章写作"""

        # 构建写作提示
        prompt = self._build_writing_prompt(input)

        # 调用 LLM 生成文章
        # 这里简化处理，实际应该调用 LLM Provider
        article_content = await self._generate_article(prompt)

        # 计算实际字数
        actual_word_count = len(article_content.split())
        reading_time = max(1, actual_word_count // 200)

        # 生成文件名
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        safe_title = input.title[:50].replace(" ", "_").replace("/", "-")
        file_name = f"{timestamp}_{safe_title}.md"
        file_path = Path(context.workspace_path) / "articles" / file_name

        # 保存文章
        with open(file_path, "w", encoding="utf-8") as f:
            f.write(f"# {input.title}\n\n")
            f.write(f"生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write(f"字数: {actual_word_count}\n")
            f.write(f"阅读时间: {reading_time} 分钟\n\n")
            f.write("---\n\n")
            f.write(article_content)

        return CapabilityOutput(
            success=True,
            message=f"文章《{input.title}》已生成，共 {actual_word_count} 字",
            data={
                "title": input.title,
                "word_count": actual_word_count,
                "reading_time_minutes": reading_time,
            },
            artifacts=[str(file_path)],
            execution_time_seconds=0,
        )

    async def after_execute(
        self,
        input: ArticleWritingInput,
        context: ExecutionContext,
        output: CapabilityOutput
    ) -> None:
        """执行后清理"""
        context.logger.info(f"文章写作完成: {output.message}")
        context.logger.info(f"保存位置: {output.artifacts}")

    def _build_writing_prompt(self, input: ArticleWritingInput) -> str:
        """构建写作提示"""
        prompt = f"""请根据以下要求写一篇文章：

标题：{input.title}

主题：{input.topic}

风格：{input.style}
语气：{input.tone}
目标受众：{input.target_audience}

字数要求：约 {input.word_count} 字

"""

        if input.keywords:
            prompt += f"\n\n关键词（请自然融入）：{', '.join(input.keywords)}"

        prompt += f"""

要求：
1. 内容原创，逻辑清晰
2. 结构完整，有引言、正文、结尾
3. 语言流畅，符合{input.style}风格
4. 符合{input.tone}语气
5. 适合{input.target_audience}阅读

请直接输出文章内容，不需要任何额外说明。
"""
        return prompt

    async def _generate_article(self, prompt: str) -> str:
        """生成文章内容（简化版）"""
        # 这里应该调用实际的 LLM Provider
        # 暂时返回示例内容
        return f"""# {prompt.split('标题：')[1].split('\n')[0]}

这是一篇基于给定主题的文章。在开篇，我们将简要介绍核心概念，为读者建立基础理解。随后的章节将深入探讨各个方面，并提供具体案例和实践指导。

## 引言

在当今快速发展的数字时代，{prompt.split('主题：')[1].split('\n')[0]}已成为一个不可忽视的话题。本文将全面解析其内涵、特点及应用价值。

## 正文

### 主要特点

第一个核心特点是简洁直观。对于初学者来说，上手门槛低，学习曲线平缓。这使得它能够在短时间内被广泛接受和使用。

第二个特点是扩展性强。通过丰富的插件生态系统，用户可以根据自身需求定制功能，实现个性化配置。

### 应用场景

在实际应用中，{prompt.split('主题：')[1].split('\n')[0]}展现出强大的适应性。无论是个人项目、团队协作，还是企业级应用，都能找到合适的解决方案。

## 结论

综上所述，{prompt.split('主题：')[1].split('\n')[0]}作为一种现代化工具，具有广阔的应用前景。掌握它不仅能提高工作效率，更能为未来技术发展奠定基础。

---
*本文由 AI 公司自动生成，字数约 {prompt.split('字数要求：')[1].split('\n')[0] if '字数要求' in prompt else 1000} 字*
"""


# 导出
ArticleWritingCapability = ArticleWritingCapability
