"""
Persistent Workflow

持久化工作流 - Agent 尽量保持活跃，持续处理任务
"""
import asyncio
import subprocess
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Optional
from uuid import UUID

from pydantic import BaseModel


class AgentStatus(str, Enum):
    """Agent 状态"""
    IDLE = "idle"  # 空闲，可接受任务
    WORKING = "working"  # 执行中
    WAITING = "waiting"  # 等待反馈
    THINKING = "thinking"  # 主动思考中


class TaskResult(BaseModel):
    """任务执行结果"""
    success: bool
    task_id: UUID
    agent_name: str
    message: str
    output: str | None = None
    artifacts: list[str] = []
    execution_time_seconds: float = 0
    error: str | None = None


class PersistentWorkflow:
    """
    持久化工作流

    负责：
    - 管理核心 Agent 的生命周期
    - 持续处理任务队列
    - 执行任务并返回结果
    """

    def __init__(
        self,
        agent_factory,
        agent_manager,
        employee_repo,
        task_repo,
        workspace_manager,
    ):
        self.agent_factory = agent_factory
        self.agent_manager = agent_manager
        self.employee_repo = employee_repo
        self.task_repo = task_repo
        self.workspace_manager = workspace_manager

        self.running = False
        self._task_queue: asyncio.Queue = asyncio.Queue()
        self._core_employees: list = []

    async def start(self):
        """启动持久化工作流"""
        if self.running:
            return

        self.running = True

        # 1. 加载核心员工
        self._core_employees = await self._load_core_employees()

        # 2. 确保所有核心员工都有对应的 Agent
        for employee in self._core_employees:
            agent_name = await self.agent_factory.ensure_agent_for_employee(employee)
            print(f"✅ Agent ready: {agent_name} ({employee.name})")

        # 3. 启动任务处理循环
        asyncio.create_task(self._task_loop())

        print(f"🚀 Persistent workflow started with {len(self._core_employees)} core agents")

    async def stop(self):
        """停止工作流"""
        self.running = False

    async def submit_task(
        self,
        task_id: UUID,
        employee_id: UUID,
        prompt: str,
        workspace: Optional[Path] = None,
    ) -> TaskResult:
        """
        提交任务（非阻塞）

        Args:
            task_id: 任务 ID
            employee_id: 被分配的员工 ID
            prompt: 任务描述
            workspace: 工作空间路径（可选）

        Returns:
            TaskResult: 任务结果
        """
        # 将任务加入队列
        await self._task_queue.put({
            "task_id": task_id,
            "employee_id": employee_id,
            "prompt": prompt,
            "workspace": workspace,
        })

        return TaskResult(
            success=True,
            task_id=task_id,
            agent_name="",
            message="Task queued",
        )

    async def execute_task_sync(
        self,
        task_id: UUID,
        employee_id: UUID,
        prompt: str,
        workspace: Optional[Path] = None,
    ) -> TaskResult:
        """
        同步执行任务（阻塞）

        Args:
            task_id: 任务 ID
            employee_id: 被分配的员工 ID
            prompt: 任务描述
            workspace: 工作空间路径（可选）

        Returns:
            TaskResult: 任务结果
        """
        # 获取员工
        employee = await self.employee_repo.get(employee_id)
        if not employee:
            return TaskResult(
                success=False,
                task_id=task_id,
                agent_name="",
                message=f"Employee not found: {employee_id}",
                error="EMPLOYEE_NOT_FOUND",
            )

        # 获取或创建 Agent
        agent_name = await self.agent_factory.ensure_agent_for_employee(employee)

        # 获取工作空间
        if workspace is None:
            workspace = self.workspace_manager.get_task_workspace(task_id)

        # 执行任务
        start_time = datetime.now()

        try:
            output = await self._execute_with_claude_code(
                agent_name=agent_name,
                prompt=prompt,
                workspace=workspace,
            )

            execution_time = (datetime.now() - start_time).total_seconds()

            # 收集产出物
            artifacts = self._collect_artifacts(workspace)

            return TaskResult(
                success=True,
                task_id=task_id,
                agent_name=agent_name,
                message="Task completed successfully",
                output=output,
                artifacts=artifacts,
                execution_time_seconds=execution_time,
            )

        except Exception as e:
            execution_time = (datetime.now() - start_time).total_seconds()
            return TaskResult(
                success=False,
                task_id=task_id,
                agent_name=agent_name,
                message=f"Task failed: {str(e)}",
                error=str(e),
                execution_time_seconds=execution_time,
            )

    async def _task_loop(self):
        """任务处理循环"""
        while self.running:
            try:
                # 从队列获取任务
                task_data = await asyncio.wait_for(
                    self._task_queue.get(),
                    timeout=1.0,
                )

                # 执行任务
                result = await self.execute_task_sync(
                    task_id=task_data["task_id"],
                    employee_id=task_data["employee_id"],
                    prompt=task_data["prompt"],
                    workspace=task_data.get("workspace"),
                )

                # 记录结果
                await self._record_task_result(result)

            except asyncio.TimeoutError:
                continue
            except Exception as e:
                print(f"Error in task loop: {e}")

    async def _execute_with_claude_code(
        self,
        agent_name: str,
        prompt: str,
        workspace: Path,
    ) -> str:
        """
        使用 Claude Code CLI 执行任务

        Args:
            agent_name: Agent 名称
            prompt: 任务描述
            workspace: 工作空间路径

        Returns:
            str: 执行结果
        """
        # 构建 Claude Code 命令
        cmd = [
            "claude",
            "--agent", agent_name,
            "--print",  # 非交互模式
            "--output-format", "text",
            prompt,
        ]

        # 执行命令
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            cwd=str(workspace),
            timeout=600,  # 10 分钟超时
        )

        if result.returncode != 0:
            raise RuntimeError(f"Claude Code failed: {result.stderr}")

        return result.stdout

    def _collect_artifacts(self, workspace: Path) -> list[str]:
        """
        收集工作空间中的产出物

        Args:
            workspace: 工作空间路径

        Returns:
            list[str]: 产出物文件路径列表
        """
        artifacts = []
        workspace_path = Path(workspace)

        if not workspace_path.exists():
            return artifacts

        # 收集所有生成的文件
        for item in workspace_path.rglob("*"):
            if item.is_file():
                # 排除临时文件和隐藏文件
                if not item.name.startswith(".") and not item.name.startswith("~"):
                    artifacts.append(str(item.relative_to(workspace_path)))

        return artifacts

    async def _record_task_result(self, result: TaskResult) -> None:
        """记录任务执行结果"""
        # 更新任务状态
        await self.task_repo.update_execution(
            task_id=result.task_id,
            agent_name=result.agent_name,
            success=result.success,
            output=result.output,
            artifacts=result.artifacts,
            execution_time_seconds=result.execution_time_seconds,
        )

    async def _load_core_employees(self) -> list:
        """加载核心员工列表"""
        # 获取所有状态为 active 的员工
        from src.models.employee import EmployeeStatus

        employees = await self.employee_repo.find_by_status(
            EmployeeStatus.ACTIVE
        )
        return employees

    async def get_active_agents(self) -> list:
        """获取当前活跃的 Agent 列表"""
        return self.agent_factory.get_active_agents()

    async def get_agent_status(self, agent_name: str) -> dict:
        """获取 Agent 状态"""
        agent_info = await self.agent_manager.get_agent(agent_name)
        if not agent_info:
            return {"exists": False}

        pool_info = self.agent_factory._agent_pool.get(agent_name)

        return {
            "exists": True,
            "name": agent_name,
            "config": agent_info.config.model_dump(),
            "in_pool": pool_info is not None,
            "pool_info": pool_info.model_dump() if pool_info else None,
        }


# 导出
__all__ = [
    "PersistentWorkflow",
    "TaskResult",
    "AgentStatus",
]
