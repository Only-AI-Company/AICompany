"""
Custom Exceptions

定义应用级别的自定义异常
"""
from typing import Any


class AICompanyException(Exception):
    """基础异常类"""

    def __init__(
        self,
        message: str,
        code: str | None = None,
        details: dict[str, Any] | None = None,
    ):
        self.message = message
        self.code = code or self.__class__.__name__
        self.details = details or {}
        super().__init__(self.message)


# 数据库异常
class DatabaseException(AICompanyException):
    """数据库操作异常"""


class RecordNotFoundException(AICompanyException):
    """记录未找到异常"""

    def __init__(self, resource: str, id: str | None = None):
        message = f"{resource} not found"
        if id:
            message += f" (id: {id})"
        super().__init__(message, code="RECORD_NOT_FOUND", details={"resource": resource, "id": id})


class DuplicateRecordException(AICompanyException):
    """重复记录异常"""

    def __init__(self, resource: str, field: str, value: str):
        super().__init__(
            f"{resource} with {field}='{value}' already exists",
            code="DUPLICATE_RECORD",
            details={"resource": resource, "field": field, "value": value},
        )


# 业务逻辑异常
class BusinessLogicException(AICompanyException):
    """业务逻辑异常"""


class ValidationException(AICompanyException):
    """验证异常"""

    def __init__(self, message: str, errors: list[str] | None = None):
        super().__init__(
            message,
            code="VALIDATION_ERROR",
            details={"errors": errors or []},
        )


# Agent 异常
class AgentException(AICompanyException):
    """Agent 操作异常"""


class AgentNotAvailableException(AgentException):
    """Agent 不可用异常"""

    def __init__(self, agent_id: str, reason: str | None = None):
        message = f"Agent {agent_id} is not available"
        if reason:
            message += f": {reason}"
        super().__init__(message, code="AGENT_NOT_AVAILABLE", details={"agent_id": agent_id})


class AgentExecutionException(AgentException):
    """Agent 执行异常"""

    def __init__(self, agent_id: str, task_id: str, error: str):
        super().__init__(
            f"Agent {agent_id} failed to execute task {task_id}: {error}",
            code="AGENT_EXECUTION_FAILED",
            details={"agent_id": agent_id, "task_id": task_id, "error": error},
        )


# LLM 异常
class LLMException(AICompanyException):
    """LLM 服务异常"""


class LLMProviderException(LLMException):
    """LLM Provider 异常"""

    def __init__(self, provider: str, message: str):
        super().__init__(
            f"LLM Provider '{provider}' error: {message}",
            code="LLM_PROVIDER_ERROR",
            details={"provider": provider},
        )


class LLMQuotaExceededException(LLMException):
    """LLM 配额超限异常"""

    def __init__(self, provider: str):
        super().__init__(
            f"LLM quota exceeded for provider '{provider}'",
            code="LLM_QUOTA_EXCEEDED",
            details={"provider": provider},
        )


# 任务异常
class TaskException(AICompanyException):
    """任务操作异常"""


class TaskNotFoundException(TaskException):
    """任务未找到异常"""

    def __init__(self, task_id: str):
        super().__init__(
            f"Task not found",
            code="TASK_NOT_FOUND",
            details={"task_id": task_id},
        )


class TaskExecutionException(TaskException):
    """任务执行异常"""

    def __init__(self, task_id: str, error: str):
        super().__init__(
            f"Task execution failed: {error}",
            code="TASK_EXECUTION_FAILED",
            details={"task_id": task_id, "error": error},
        )


# 配置异常
class ConfigurationException(AICompanyException):
    """配置异常"""

    def __init__(self, config_key: str, reason: str):
        super().__init__(
            f"Configuration error for '{config_key}': {reason}",
            code="CONFIGURATION_ERROR",
            details={"config_key": config_key},
        )
