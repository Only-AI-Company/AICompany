"""
Agent Factory

从 Employee 和 Human 模板创建 Claude Code Agents
"""
import asyncio
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import TYPE_CHECKING
from uuid import UUID

from pydantic import BaseModel

if TYPE_CHECKING:
    from src.core.agents.claude_code_agent_manager import (
        AgentColor,
        AgentInfo,
        ClaudeCodeAgentManager,
    )
    from src.repositories.human_repository import HumanRepository
    from src.repositories.employee_repository import EmployeeRepository

from src.models.human import Human
from src.models.employee import Employee


class AgentLifecycle(str, Enum):
    """Agent 生命周期类型"""
    CORE = "core"  # 核心，常驻
    PROJECT = "project"  # 项目级，周期性
    TASK = "task"  # 任务级，用完即焚


class AgentPoolInfo(BaseModel):
    """Agent 池信息"""
    agent_name: str
    employee_id: UUID
    lifecycle: AgentLifecycle
    created_at: datetime
    last_used_at: datetime
    task_count: int = 0
    total_duration_seconds: float = 0

    class Config:
        from_attributes = True


class AgentFactory:
    """
    Agent 工厂

    负责：
    - 从 Employee 和 Human 模板创建 Agent
    - 管理 Agent 生命周期
    - 动态添加技能到 Agent
    """

    def __init__(
        self,
        agent_manager: "ClaudeCodeAgentManager",
        human_repo: "HumanRepository",
        employee_repo: "EmployeeRepository",
    ):
        self.agent_manager = agent_manager
        self.human_repo = human_repo
        self.employee_repo = employee_repo

        # Agent 池（追踪活跃的 agent）
        self._agent_pool: dict[str, AgentPoolInfo] = {}

    async def ensure_agent_for_employee(
        self,
        employee: Employee,
        force_recreate: bool = False,
    ) -> str:
        """
        确保 Employee 有对应的 Agent（持久化）

        如果 Agent 不存在则创建，存在则复用。

        Args:
            employee: 员工对象
            force_recreate: 是否强制重新创建

        Returns:
            str: Agent 名称
        """
        # 1. 生成 agent 名称
        agent_name = self._get_agent_name(employee)

        # 2. 检查 Agent 是否已存在
        if not force_recreate:
            existing = await self.agent_manager.get_agent(agent_name)
            if existing:
                # 更新池信息
                self._update_pool_last_used(agent_name, employee.id)
                return agent_name

        # 3. 获取 Human 模板
        human = await self.human_repo.get(employee.human_id)
        if not human:
            raise ValueError(f"Human not found for employee {employee.id}: {employee.human_id}")

        # 4. 构建 Agent 配置
        description = self._build_description(employee, human)
        system_prompt = self._build_system_prompt(human, employee)
        color = self._get_color_for_role(employee.role)

        # 5. 创建 Agent
        await self.agent_manager.create_agent(
            name=agent_name,
            description=description,
            system_prompt=system_prompt,
            color=color,
            overwrite=force_recreate,
        )

        # 6. 添加到池中
        self._add_to_pool(
            agent_name=agent_name,
            employee_id=employee.id,
            lifecycle=AgentLifecycle.CORE,  # 默认为核心
        )

        return agent_name

    async def get_or_create_agent_for_task(
        self,
        employee_id: UUID,
        task_id: UUID,
        lifecycle: AgentLifecycle = AgentLifecycle.TASK,
    ) -> str:
        """
        为特定任务获取或创建 Agent

        Args:
            employee_id: 员工 ID
            task_id: 任务 ID
            lifecycle: 生命周期类型

        Returns:
            str: Agent 名称
        """
        # 1. 获取 Employee
        employee = await self.employee_repo.get(employee_id)
        if not employee:
            raise ValueError(f"Employee not found: {employee_id}")

        # 2. 对于任务级 Agent，使用任务特定的名称
        if lifecycle == AgentLifecycle.TASK:
            agent_name = self._get_task_agent_name(employee.id, task_id)
        else:
            agent_name = self._get_agent_name(employee)

        # 3. 检查是否已存在
        if not await self.agent_manager.agent_exists(agent_name):
            # 创建新的
            await self.ensure_agent_for_employee(employee)

        # 4. 更新池信息
        self._update_pool_last_used(agent_name, employee.id)

        return agent_name

    async def add_skills_to_agent(
        self,
        employee: Employee,
        new_skills: list[str],
    ) -> None:
        """
        动态添加技能到 Agent

        Args:
            employee: 员工对象
            new_skills: 要添加的技能列表
        """
        agent_name = self._get_agent_name(employee)

        # 检查 Agent 是否存在
        if not await self.agent_manager.agent_exists(agent_name):
            await self.ensure_agent_for_employee(employee)

        # 更新 Agent 配置
        await self.agent_manager.update_agent(
            name=agent_name,
            add_skills=new_skills,
        )

        # 同时更新 Human 模板
        human = await self.human_repo.get(employee.human_id)
        if human:
            existing_skills = human.skills or []
            human.skills = list(set(existing_skills + new_skills))
            await self.human_repo.update(human)

    async def release_agent(
        self,
        agent_name: str,
        force: bool = False,
    ) -> None:
        """
        释放 Agent

        核心 Agent 不释放，除非强制。临时和项目级 Agent 可以释放。

        Args:
            agent_name: Agent 名称
            force: 是否强制释放
        """
        pool_info = self._agent_pool.get(agent_name)
        if not pool_info:
            return

        # 核心员工不释放，除非强制
        if pool_info.lifecycle == AgentLifecycle.CORE and not force:
            return

        # 从池中移除
        del self._agent_pool[agent_name]

        # 注意：我们不删除 Claude Code 的 agent 文件，只是从池中移除引用
        # 这样 agent 文件可以被后续复用

    def get_active_agents(self) -> list[AgentPoolInfo]:
        """获取当前活跃的 Agent 列表"""
        return list(self._agent_pool.values())

    def _get_agent_name(self, employee: Employee) -> str:
        """
        生成 Agent 名称（基于 Employee）

        格式: employee-{employee_id}
        """
        return f"employee-{employee.id}"

    def _get_task_agent_name(self, employee_id: UUID, task_id: UUID) -> str:
        """
        生成任务级 Agent 名称

        格式: task-{employee_id}-{task_id}
        """
        return f"task-{employee_id}-{task_id}"

    def _build_description(self, employee: Employee, human: Human) -> str:
        """构建 Agent 描述"""
        nickname = human.nickname or employee.name
        skills_str = ", ".join(human.skills or []) if human.skills else "General capabilities"
        traits_str = ", ".join(human.personality_traits or []) if human.personality_traits else ""

        description = f"""**{nickname}** - {employee.role}

Skills: {skills_str}"""

        if traits_str:
            description += f"\\n\\nTraits: {traits_str}"

        description += f"\\n\\nUse this agent for {employee.role} tasks and responsibilities."

        return description

    def _build_system_prompt(self, human: Human, employee: Employee) -> str:
        """构建系统提示词"""
        # 使用 Human 的 system_prompt
        prompt = human.system_prompt or f"""You are {employee.name}, a {employee.role} at AI Company.

Your role is to assist with tasks related to your expertise.
"""

        # 添加技能信息
        if human.skills:
            prompt += f"\\n\\nYour skills include: {', '.join(human.skills)}."

        # 添加性格特征
        if human.personality_traits:
            prompt += f"\\n\\nYour personality traits: {', '.join(human.personality_traits)}."

        # 添加沟通风格
        if human.communication_style:
            prompt += f"\\n\\nCommunication style: {human.communication_style}."

        return prompt

    def _get_color_for_role(self, role: str) -> "AgentColor":
        """根据角色返回颜色"""
        from src.core.agents.claude_code_agent_manager import AgentColor

        color_map = {
            "ceo": AgentColor.RED,
            "cto": AgentColor.BLUE,
            "cpo": AgentColor.GREEN,
            "cfo": AgentColor.YELLOW,
            "coo": AgentColor.PURPLE,
            "architect": AgentColor.CYAN,
            "developer": AgentColor.BLUE,
            "writer": AgentColor.PINK,
            "analyst": AgentColor.YELLOW,
            "pm": AgentColor.GREEN,
            "designer": AgentColor.PINK,
            "qa": AgentColor.ORANGE,
            "devops": AgentColor.GRAY,
        }
        return color_map.get(role.lower(), AgentColor.GRAY)

    def _add_to_pool(
        self,
        agent_name: str,
        employee_id: UUID,
        lifecycle: AgentLifecycle,
    ) -> None:
        """添加 Agent 到池中"""
        self._agent_pool[agent_name] = AgentPoolInfo(
            agent_name=agent_name,
            employee_id=employee_id,
            lifecycle=lifecycle,
            created_at=datetime.now(),
            last_used_at=datetime.now(),
        )

    def _update_pool_last_used(self, agent_name: str, employee_id: UUID) -> None:
        """更新 Agent 的最后使用时间"""
        if agent_name not in self._agent_pool:
            # 如果不在池中，添加进去
            self._add_to_pool(agent_name, employee_id, AgentLifecycle.CORE)
        else:
            self._agent_pool[agent_name].last_used_at = datetime.now()


# 导出
from pydantic import BaseModel

__all__ = [
    "AgentFactory",
    "AgentLifecycle",
    "AgentPoolInfo",
]
