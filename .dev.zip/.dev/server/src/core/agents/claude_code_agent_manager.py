"""
Claude Code Agent Manager

管理 Claude Code 的 Agents（~/.claude/agents/*.md）
"""
import yaml
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any

from pydantic import BaseModel


class AgentColor(str, Enum):
    """Agent 颜色"""
    RED = "red"
    BLUE = "blue"
    GREEN = "green"
    YELLOW = "yellow"
    PINK = "pink"
    CYAN = "cyan"
    GRAY = "gray"
    PURPLE = "purple"
    ORANGE = "orange"


class AgentMemory(str, Enum):
    """Agent 记忆类型"""
    USER = "user"
    NONE = "none"


class AgentConfig(BaseModel):
    """Agent 配置"""
    name: str
    description: str
    model: str = "inherit"
    color: AgentColor = AgentColor.BLUE
    memory: AgentMemory = AgentMemory.USER


class AgentInfo(BaseModel):
    """Agent 信息"""
    name: str
    config: AgentConfig
    system_prompt: str
    file_path: Path
    created_at: datetime | None = None
    modified_at: datetime | None = None


class ClaudeCodeAgentManager:
    """
    Claude Code Agent 管理器

    负责：
    - 创建 Agent 文件（~/.claude/agents/{name}.md）
    - 更新 Agent 配置
    - 列出/查询/删除 Agent
    """

    def __init__(self, agents_dir: str | None = None):
        self.agents_dir = Path(agents_dir or "~/.claude/agents").expanduser()
        self.agents_dir.mkdir(parents=True, exist_ok=True)

    async def create_agent(
        self,
        name: str,
        description: str,
        system_prompt: str,
        color: AgentColor = AgentColor.BLUE,
        model: str = "inherit",
        memory: AgentMemory = AgentMemory.USER,
        examples: list[dict] | None = None,
        overwrite: bool = False,
    ) -> AgentInfo:
        """
        创建持久化 Agent

        Args:
            name: Agent 名称
            description: 描述（什么时候使用这个 agent）
            system_prompt: 系统提示词
            color: 显示颜色
            model: 模型设置
            memory: 记忆类型
            examples: 使用示例（可选）
            overwrite: 是否覆盖已存在的 agent

        Returns:
            AgentInfo: 创建的 Agent 信息
        """
        agent_file = self.agents_dir / f"{name}.md"

        # 检查是否已存在
        if agent_file.exists() and not overwrite:
            raise FileExistsError(f"Agent {name} already exists. Use overwrite=True to replace.")

        # 构建 frontmatter
        full_description = self._build_description(description, examples)
        frontmatter = {
            "name": name,
            "description": full_description,
            "model": model,
            "color": color.value,
            "memory": memory.value,
        }

        # 写入文件
        content = self._format_agent_file(frontmatter, system_prompt)
        agent_file.write_text(content, encoding="utf-8")

        return AgentInfo(
            name=name,
            config=AgentConfig(**frontmatter),
            system_prompt=system_prompt,
            file_path=agent_file,
            created_at=datetime.now(),
            modified_at=datetime.now(),
        )

    async def update_agent(
        self,
        name: str,
        system_prompt: str | None = None,
        description: str | None = None,
        add_skills: list[str] | None = None,
        color: AgentColor | None = None,
    ) -> AgentInfo:
        """
        更新 Agent

        Args:
            name: Agent 名称
            system_prompt: 新的系统提示词（可选）
            description: 新的描述（可选）
            add_skills: 要添加的技能（可选）
            color: 新的颜色（可选）

        Returns:
            AgentInfo: 更新后的 Agent 信息
        """
        agent_file = self.agents_dir / f"{name}.md"
        if not agent_file.exists():
            raise FileNotFoundError(f"Agent {name} not found")

        content = agent_file.read_text(encoding="utf-8")

        # 解析 frontmatter 和正文
        parts = content.split("---", 2)
        if len(parts) < 3:
            raise ValueError(f"Invalid agent file format: {name}")

        frontmatter = yaml.safe_load(parts[1])
        body = parts[2]

        # 更新字段
        if system_prompt:
            body = system_prompt

        if description:
            frontmatter["description"] = description

        if color:
            frontmatter["color"] = color.value

        if add_skills:
            # 添加技能到描述中
            if "skills" not in frontmatter:
                frontmatter["skills"] = []
            frontmatter["skills"].extend(add_skills)

            # 同时更新描述
            skills_text = f"\\n\\nSkills: {', '.join(frontmatter['skills'])}"
            if "Skills:" not in frontmatter.get("description", ""):
                frontmatter["description"] = frontmatter.get("description", "") + skills_text

        # 写回文件
        new_content = self._format_agent_file(frontmatter, body)
        agent_file.write_text(new_content, encoding="utf-8")

        return AgentInfo(
            name=name,
            config=AgentConfig(**frontmatter),
            system_prompt=body,
            file_path=agent_file,
            modified_at=datetime.now(),
        )

    async def get_agent(self, name: str) -> AgentInfo | None:
        """
        获取 Agent 配置

        Args:
            name: Agent 名称

        Returns:
            AgentInfo | None: Agent 信息，不存在时返回 None
        """
        agent_file = self.agents_dir / f"{name}.md"
        if not agent_file.exists():
            return None

        content = agent_file.read_text(encoding="utf-8")
        parts = content.split("---", 2)

        if len(parts) < 3:
            return None

        frontmatter = yaml.safe_load(parts[1])
        body = parts[2]

        # 获取文件时间
        stat = agent_file.stat()

        return AgentInfo(
            name=name,
            config=AgentConfig(**frontmatter),
            system_prompt=body,
            file_path=agent_file,
            created_at=datetime.fromtimestamp(stat.st_ctime),
            modified_at=datetime.fromtimestamp(stat.st_mtime),
        )

    async def list_agents(self) -> list[AgentInfo]:
        """
        列出所有 Agent

        Returns:
            list[AgentInfo]: 所有 Agent 的信息列表
        """
        agents = []
        for agent_file in self.agents_dir.glob("*.md"):
            agent_info = await self.get_agent(agent_file.stem)
            if agent_info:
                agents.append(agent_info)
        return sorted(agents, key=lambda x: x.name)

    async def delete_agent(self, name: str) -> bool:
        """
        删除 Agent

        Args:
            name: Agent 名称

        Returns:
            bool: 是否成功删除
        """
        agent_file = self.agents_dir / f"{name}.md"
        if not agent_file.exists():
            return False

        agent_file.unlink()
        return True

    async def agent_exists(self, name: str) -> bool:
        """
        检查 Agent 是否存在

        Args:
            name: Agent 名称

        Returns:
            bool: 是否存在
        """
        return (self.agents_dir / f"{name}.md").exists()

    def _build_description(
        self,
        base_description: str,
        examples: list[dict] | None = None,
    ) -> str:
        """
        构建带 examples 的描述

        Args:
            base_description: 基础描述
            examples: 使用示例列表

        Returns:
            str: 完整描述
        """
        if not examples:
            return base_description

        examples_text = "\\n\\nExamples:\\n"
        for ex in examples:
            context = ex.get("context", "")
            action = ex.get("action", "")
            examples_text += f"\\n- {context}: {action}"

        return base_description + examples_text

    def _format_agent_file(self, frontmatter: dict, system_prompt: str) -> str:
        """
        格式化 Agent 文件内容

        Args:
            frontmatter: YAML frontmatter 数据
            system_prompt: 系统提示词

        Returns:
            str: 格式化后的文件内容
        """
        yaml_content = yaml.dump(frontmatter, default_flow_style=False, allow_unicode=True)
        return f"---\\n{yaml_content}---\\n\\n{system_prompt}"


# 导出
__all__ = [
    "ClaudeCodeAgentManager",
    "AgentInfo",
    "AgentConfig",
    "AgentColor",
    "AgentMemory",
]
