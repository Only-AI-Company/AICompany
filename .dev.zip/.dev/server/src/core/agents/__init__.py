"""
Core Agents Module

Agent 管理和工厂
"""

from src.core.agents.claude_code_agent_manager import (
    AgentColor,
    AgentConfig,
    AgentInfo,
    AgentMemory,
    ClaudeCodeAgentManager,
)
from src.core.agents.agent_factory import (
    AgentFactory,
    AgentLifecycle,
    AgentPoolInfo,
)

__all__ = [
    "ClaudeCodeAgentManager",
    "AgentInfo",
    "AgentConfig",
    "AgentColor",
    "AgentMemory",
    "AgentFactory",
    "AgentLifecycle",
    "AgentPoolInfo",
]
