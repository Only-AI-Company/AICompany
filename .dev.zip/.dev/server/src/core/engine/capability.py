"""
Capability Base Interface

所有能力的基类接口
"""
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Optional
from enum import Enum


class CapabilityType(str, Enum):
    """能力类型"""
    # 开发能力
    PROJECT_CREATION = "project_creation"
    FEATURE_DEVELOPMENT = "feature_development"
    BUG_FIX = "bug_fix"
    CODE_REVIEW = "code_review"
    DEPLOYMENT = "deployment"

    # 内容创作
    NOVEL_WRITING = "novel_writing"
    ARTICLE_WRITING = "article_writing"
    COPYWRITING = "copywriting"
    SCRIPT_WRITING = "script_writing"

    # 运营能力
    XIAOHONGSHU_OPERATION = "xiaohongshu_operation"
    TWITTER_OPERATION = "twitter_operation"
    ANALYTICS = "analytics"

    # 自动化能力
    SCHEDULED_TASK = "scheduled_task"
    SCRIPT_AUTOMATION = "script_automation"
    WEB_SCRAPING = "web_scraping"
    WORKFLOW_AUTOMATION = "workflow_automation"

    # 策划能力
    PRODUCT_PLANNING = "product_planning"
    EVENT_PLANNING = "event_planning"
    BRAINSTORMING = "brainstorming"


@dataclass
class ExecutionContext:
    """执行上下文"""
    task_id: str
    workspace_path: str  # 隔离的工作空间路径
    agent_id: str
    user_id: str
    logger: Any
    interactions: Any  # 交互服务（用于需要用户输入的场景）


@dataclass
class ValidationResult:
    """验证结果"""
    valid: bool
    errors: list[str] | None = None


@dataclass
class ExecutionEstimate:
    """执行预估"""
    can_execute: bool
    estimated_duration_minutes: int
    required_resources: list[str]
    risk_level: str  # "low", "medium", "high"


@dataclass
class CapabilityOutput:
    """能力执行输出"""
    success: bool
    message: str
    data: dict | None = None
    artifacts: list[str] | None = None  # 产出物文件列表
    execution_time_seconds: float | None = None
    error: str | None = None
    metadata: dict | None = None


@dataclass
class CapabilityInput:
    """能力执行输入（基类，具体能力继承）"""
    pass


class BaseCapability(ABC):
    """能力基类 - 所有能力必须实现此接口"""

    # 能力类型
    capability_type: CapabilityType

    # 能力描述
    name: str
    description: str

    @abstractmethod
    async def validate(self, input: CapabilityInput) -> ValidationResult:
        """验证输入是否有效"""
        pass

    @abstractmethod
    async def estimate(self, input: CapabilityInput) -> ExecutionEstimate:
        """预估执行时间和资源需求"""
        pass

    @abstractmethod
    async def execute(
        self,
        input: CapabilityInput,
        context: ExecutionContext
    ) -> CapabilityOutput:
        """执行能力（核心方法）"""
        pass

    async def before_execute(
        self,
        input: CapabilityInput,
        context: ExecutionContext
    ) -> None:
        """执行前的钩子"""
        pass

    async def after_execute(
        self,
        input: CapabilityInput,
        context: ExecutionContext,
        output: CapabilityOutput
    ) -> None:
        """执行后的钩子"""
        pass
