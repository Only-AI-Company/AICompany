"""
Workspace Manager

管理任务和项目的工作空间（隔离的执行环境）
"""
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Optional
from uuid import UUID


class WorkspaceType(str, Enum):
    """工作空间类型"""
    PROJECT = "project"  # 项目级，持久化
    TASK = "task"  # 任务级，可临时或持久
    TEMP = "temp"  # 临时，用完即删


class WorkspaceManager:
    """
    工作空间管理器

    负责：
    - 创建隔离的工作空间
    - 管理工作空间的生命周期
    - 清理过期的工作空间
    """

    def __init__(
        self,
        base_path: str | Path = "outputs/workspaces",
    ):
        self.base_path = Path(base_path).expanduser().resolve()
        self.base_path.mkdir(parents=True, exist_ok=True)

    def get_project_workspace(self, project_id: UUID) -> Path:
        """
        获取项目工作空间（持久化）

        Args:
            project_id: 项目 ID

        Returns:
            Path: 工作空间路径
        """
        workspace = self.base_path / "projects" / str(project_id)
        workspace.mkdir(parents=True, exist_ok=True)
        return workspace

    def get_task_workspace(
        self,
        task_id: UUID,
        project_id: Optional[UUID] = None,
    ) -> Path:
        """
        获取任务工作空间

        Args:
            task_id: 任务 ID
            project_id: 所属项目 ID（可选）

        Returns:
            Path: 工作空间路径
        """
        if project_id:
            # 任务在项目工作空间内
            project_workspace = self.get_project_workspace(project_id)
            workspace = project_workspace / "tasks" / str(task_id)
        else:
            # 独立任务工作空间
            workspace = self.base_path / "tasks" / str(task_id)

        workspace.mkdir(parents=True, exist_ok=True)
        return workspace

    def get_temp_workspace(self, suffix: str = "") -> Path:
        """
        获取临时工作空间

        Args:
            suffix: 路径后缀

        Returns:
            Path: 临时工作空间路径
        """
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        name = f"temp_{timestamp}{suffix}"
        workspace = self.base_path / "temp" / name
        workspace.mkdir(parents=True, exist_ok=True)
        return workspace

    def cleanup_temp_workspace(self, workspace: Path) -> None:
        """
        清理临时工作空间

        Args:
            workspace: 要清理的工作空间路径
        """
        import shutil

        if workspace.exists() and workspace.is_dir():
            shutil.rmtree(workspace)

    def cleanup_old_temp_workspaces(
        self,
        max_age_hours: int = 24,
    ) -> list[Path]:
        """
        清理过期的临时工作空间

        Args:
            max_age_hours: 最大保留时间（小时）

        Returns:
            list[Path]: 被清理的工作空间列表
        """
        import shutil
        from datetime import timedelta

        temp_dir = self.base_path / "temp"
        if not temp_dir.exists():
            return []

        cleaned = []
        cutoff = datetime.now() - timedelta(hours=max_age_hours)

        for workspace in temp_dir.iterdir():
            if not workspace.is_dir():
                continue

            # 检查修改时间
            mtime = datetime.fromtimestamp(workspace.stat().st_mtime)
            if mtime < cutoff:
                shutil.rmtree(workspace)
                cleaned.append(workspace)

        return cleaned

    def get_workspace_info(self, workspace: Path) -> dict:
        """
        获取工作空间信息

        Args:
            workspace: 工作空间路径

        Returns:
            dict: 工作空间信息
        """
        if not workspace.exists():
            return {"exists": False}

        stat = workspace.stat()

        # 统计文件数量
        file_count = 0
        total_size = 0
        for item in workspace.rglob("*"):
            if item.is_file():
                file_count += 1
                total_size += item.stat().st_size

        return {
            "exists": True,
            "path": str(workspace),
            "file_count": file_count,
            "total_size_bytes": total_size,
            "total_size_mb": round(total_size / 1024 / 1024, 2),
            "created_at": datetime.fromtimestamp(stat.st_ctime),
            "modified_at": datetime.fromtimestamp(stat.st_mtime),
        }


# 导出
__all__ = [
    "WorkspaceManager",
    "WorkspaceType",
]
