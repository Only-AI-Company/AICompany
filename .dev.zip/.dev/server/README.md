# AI Company - Python Backend

AI-powered autonomous company with multi-agent system.

## 🏗️ Architecture

Clean Architecture with clear separation of concerns:

```
┌─────────────────────────────────────────────────────┐
│                    API Layer                         │
│              (FastAPI + Pydantic)                    │
└────────────────────┬────────────────────────────────┘
                     │
┌────────────────────▼────────────────────────────────┐
│                 Service Layer                        │
│           (Business Logic + Orchestration)           │
└────────────────────┬────────────────────────────────┘
                     │
┌────────────────────▼────────────────────────────────┐
│              Repository Layer                        │
│         (Data Access + SQLAlchemy ORM)               │
└────────────────────┬────────────────────────────────┘
                     │
┌────────────────────▼────────────────────────────────┐
│                 Database Layer                       │
│              (PostgreSQL / SQLite)                   │
└─────────────────────────────────────────────────────┘
```

## 📁 Directory Structure

```
server/
├── src/
│   ├── core/           # Core layer (exceptions, middleware)
│   ├── models/         # SQLAlchemy models
│   ├── schemas/        # Pydantic schemas
│   ├── repositories/   # Data access layer
│   ├── services/       # Business logic
│   │   ├── llm/        # LLM providers
│   │   └── agents/     # Agent services
│   ├── api/v1/         # API routes
│   ├── workers/        # Celery tasks
│   ├── integrations/   # External integrations
│   └── utils/          # Utilities
├── alembic/            # Database migrations
├── tests/              # Test suite
├── docs/               # Documentation
└── scripts/            # Utility scripts
```

## 🚀 Getting Started

### Prerequisites

- Python 3.11+
- pip (or poetry for dependency management)

### Quick Start (One-line initialization)

```bash
# Clone and navigate to project
cd /Users/devin/code/ai-company/server

# Initialize everything (install deps, run migrations, seed data)
./scripts/init_db.sh

# Start the server
python -m uvicorn src.main:app --reload
```

### Manual Installation

```bash
# Install dependencies
pip install -e .

# Copy environment file
cp .env.example .env

# Edit .env with your configuration
nano .env

# Run database migrations
python scripts/migrate.py up

# Seed initial data (Humans + CEO/CXO employees)
python scripts/seed_data.py

# Start the server
python -m uvicorn src.main:app --reload
```

### Development

```bash
# Run with auto-reload
python -m uvicorn src.main:app --reload --log-level debug

# Run tests
pytest

# Run tests with coverage
pytest --cov=src --cov-report=html

# Format code
black src/
ruff check src/
```

## 📊 Initial Data

The seed script creates the following initial data:

### Humans (配置模板)

| Name | Role | Description |
|------|------|-------------|
| `human-ceo` | CEO | Strategic thinking, decision making, team management |
| `human-cto` | CXO | Technical expertise, architecture, code review |
| `human-cpo` | CXO | Product strategy, user experience, stakeholder management |

### Employees (基于 Human 创建)

| Name | Role | Nickname | Based On |
|------|------|----------|----------|
| Alex Chen | ceo | CEO | human-ceo |
| Sarah Zhang | architect | CTO | human-cto |
| Emma Liu | pm | CPO | human-cpo |

### Adding More Data

```bash
# Create a new migration
python scripts/migrate.py revision "add_new_feature"

# Apply migrations
python scripts/migrate.py up

# Rollback last migration
python scripts/migrate.py down

# View current migration
python scripts/migrate.py current

# View migration history
python scripts/migrate.py history
```

## 📊 API Documentation

Once the server is running, visit:

- Swagger UI: http://localhost:8000/docs
- ReDoc: http://localhost:8000/redoc
- OpenAPI JSON: http://localhost:8000/openapi.json

## 🔧 Configuration

Configuration is managed via environment variables:

```bash
# Database
DATABASE_URL=postgresql+asyncpg://user:pass@localhost:5432/ai_company

# LLM Providers
ANTHROPIC_API_KEY=your_key_here
QWEN_API_KEY=your_key_here

# API Server
API_HOST=0.0.0.0
API_PORT=8000
```

## 📝 Database Migrations

Using the simplified migration script:

```bash
# Create a new migration
python scripts/migrate.py revision "description"

# Apply all pending migrations
python scripts/migrate.py up

# Rollback last migration
python scripts/migrate.py down

# View current migration version
python scripts/migrate.py current

# View migration history
python scripts/migrate.py history
```

Or using Alembic directly:

```bash
# Apply migrations
alembic upgrade head

# Rollback
alembic downgrade -1

# View history
alembic history
```

## 🧪 Testing

```bash
# Run all tests
poetry run pytest

# Run specific test file
poetry run pytest tests/unit/test_employee.py

# Run with coverage
poetry run pytest --cov=src --cov-report=html

# Run and show print output
poetry run pytest -s
```

## 📈 Monitoring

- Health check: `GET /health`
- Prometheus metrics: `GET /metrics`

## 🤝 Contributing

1. Create a feature branch
2. Make your changes
3. Add tests
4. Run linting and tests
5. Submit a pull request

## 📄 License

MIT License - see LICENSE file for details
