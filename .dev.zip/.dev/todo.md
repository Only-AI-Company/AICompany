# AI Company - TODO

## 支撑公司运转的核心组件

### P0 - 必须有（公司才能跑起来）

#### 1. 消息系统（Agent 之间通信）
- [x] 技术方案设计：`.dev/技术方案/消息系统.md`
- [ ] 实现核心接口（EventEmitter 版本）
  - [ ] 发送消息：A.send(B, message)
  - [ ] 接收消息：A.onMessage(handler)
  - [ ] 同步调用：A.ask(B, question) -> answer
  - [ ] 广播：A.broadcast(message)
  - [ ] 消息类型定义
  - [ ] 消息队列和路由

#### 2. 状态管理（公司大脑记忆）
- [x] 技术方案设计：`.dev/技术方案/状态管理.md`（SQLite 版本）
- [ ] 实现状态存储层（better-sqlite3）
  - [ ] CompanyState 持久化
  - [ ] AgentState 增删改查
  - [ ] TaskState 管理
  - [ ] GoalState 追踪
  - [ ] 索引优化

#### 3. LLM 接口（Agent 怎么思考）
- [x] 技术方案设计：`.dev/技术方案/LLM接口.md`
- [ ] 统一的 LLM 调用接口
- [ ] 支持提示词注入（CEO、Manager、Worker 不同 prompt）
- [ ] 支持工具调用（如果需要）
- [ ] 支持流式输出（如果需要）

#### 4. JD 库（员工能力配方）
- [x] 技术方案设计：`.dev/技术方案/JD库.md`
- [ ] JD 的存储和检索
- [ ] 预设的 JD（Writer, Analyst, Xiaohongshu...）
- [ ] 从 JD 生成 Agent 的 system prompt
- [ ] 用户添加 JD 的接口

#### 5. 组织树管理（树状结构维护）
- [x] 技术方案设计：`.dev/技术方案/组织树管理.md`
- [ ] 创建部门
- [ ] 添加员工到部门
- [ ] 查询上下级关系
- [ ] 树的遍历和查询

#### 6. 任务系统（目标的分解和执行）
- [x] 技术方案设计：`.dev/技术方案/任务系统.md`
- [ ] 目标接收
- [ ] 目标分解
- [ ] 任务分配
- [ ] 任务跟踪
- [ ] 任务完成通知

---

### P1 - 重要的（公司能好好运转）

#### 7. 用户接口（你和公司交互）
- [x] 技术方案设计：`.dev/技术方案/用户接口.md`
- [ ] CLI 命令：company.tell("...")
- [ ] CLI 命令：company.status()
- [ ] CLI 命令：company.addJD(...)
- [ ] CLI 命令：company.restructure(...)

#### 8. 持久化（公司记忆不会丢）
- [x] 技术方案设计：`.dev/技术方案/持久化.md`
- [ ] 保存组织结构
- [ ] 保存 JD 库
- [ ] 保存任务历史
- [ ] 保存公司状态
- [ ] 启动时恢复

#### 9. 日志系统（发生了什么）
- [x] 技术方案设计：`.dev/技术方案/日志系统.md`
- [ ] 结构化日志
- [ ] 日志级别
- [ ] 日志查询
- [ ] 关键事件追踪

#### 10. 复盘系统（公司自我进化）
- [x] 技术方案设计：`.dev/技术方案/复盘系统.md`
- [ ] 执行记录
- [ ] 结果评估
- [ ] 经验提取
- [ ] 模式识别
- [ ] 自动改进

---

### P2 - 增强的（更强大）

#### 11. 可视化界面
- [ ] 查看公司树状图
- [ ] 查看任务流转
- [ ] 查看各 Agent 状态
- [ ] 拖拽调整架构

#### 12. 多模态能力
- [ ] Agent 能看图
- [ ] Agent 能处理文件

#### 13. 外部集成
- [ ] 小红书 API
- [ ] Twitter API
- [ ] GitHub API

---

## 实现顺序

### 第一步：最小可用公司（MVP）

目标：能让 CEO 接收一个目标，招聘一个员工，完成一个任务

需要完成：
- [ ] P0-1: 消息系统
- [ ] P0-2: 状态管理
- [ ] P0-3: LLM 接口
- [ ] P0-4: JD 库（至少一个 JD）
- [ ] P0-5: 组织树管理（简化版）
- [ ] P0-6: 任务系统（简化版）

### 第二步：完整闭环

目标：完整的目标 → 招聘 → 分配 → 执行 → 复盘

需要完成：
- [ ] P1-8: 持久化
- [ ] P1-10: 复盘系统
- [ ] P0 的完善

### 第三步：用户友好

目标：你方便地使用和管理公司

需要完成：
- [ ] P1-7: 用户接口（CLI 完善）
- [ ] P1-9: 日志系统
- [ ] P2-11: 可视化界面

---

## 当前重点

**✅ 项目清理完成，基础结构已创建！**

### 已完成：

**目录结构：**
```
ai-company/
├── src/
│   ├── core/
│   │   ├── types.ts
│   │   ├── agents/
│   │   ├── messaging/
│   │   ├── state/
│   │   ├── llm/
│   │   ├── jds/
│   │   ├── organization/
│   │   ├── tasks/
│   │   ├── permissions/
│   │   ├── assets/
│   │   └── logger/
│   └── cli/
├── .jds/
│   │   ├── presets/
│   │   ├── custom/
│   │   └── templates/
├── state/
└── scripts/
```

**配置文件：**
- ✅ `package.json` - 项目配置和脚本
- ✅ `tsconfig.json` - TypeScript 配置

### 下一步：Phase 1 - 核心类型定义

**创建文件：**
1. `src/core/types.ts` - 核心类型定义
2. `src/core/messaging/EventBus.ts` - 消息系统
3. `src/core/state/StateStore.ts` - 状态管理
4. `src/core/llm/AnthropicProvider.ts` - LLM 接口
5. `src/core/agents/BaseAgent.ts` - 基础 Agent
6. `scripts/init.ts` - 初始化脚本

是否开始创建这些文件？
